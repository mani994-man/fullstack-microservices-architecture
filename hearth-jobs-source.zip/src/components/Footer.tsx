import { Link } from "@tanstack/react-router";

export default function Footer() {
  return (
    <footer className="border-t border-border/60 mt-24">
      <div className="max-w-7xl mx-auto px-6 md:px-8 py-12 grid gap-8 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="font-serif text-2xl font-semibold">Hearth</div>
          <p className="text-sm text-muted-foreground mt-3 max-w-sm leading-relaxed">
            A curated job portal for seekers and employers who value culture, craft, and
            purposeful work.
          </p>
        </div>
        <div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
            For seekers
          </h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/jobs" className="hover:text-accent">Browse jobs</Link></li>
            <li><Link to="/auth" className="hover:text-accent">Create account</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
            For employers
          </h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/post-job" className="hover:text-accent">Post a job</Link></li>
            <li><Link to="/about" className="hover:text-accent">Why Hearth</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60">
        <div className="max-w-7xl mx-auto px-6 md:px-8 py-6 text-xs text-muted-foreground">
          © {new Date().getFullYear()} Hearth. Made with care.
        </div>
      </div>
    </footer>
  );
}
