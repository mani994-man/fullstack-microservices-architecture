import { Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { LogOut, PenSquare } from "lucide-react";

export default function Navbar() {
  const { isAuthenticated, isEmployer, signOut, user } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 md:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <span className="font-serif text-2xl font-semibold tracking-tight">Hearth</span>
          <span className="text-xs text-muted-foreground tracking-widest uppercase hidden sm:inline">
            · Jobs
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm">
          <Link to="/jobs" className="text-foreground/80 hover:text-foreground transition-colors">
            Browse Jobs
          </Link>
          <Link to="/about" className="text-foreground/80 hover:text-foreground transition-colors">
            About
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <>
              {isEmployer && (
                <>
                  <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                    <Link to="/dashboard">My Jobs</Link>
                  </Button>
                  <Button asChild variant="default" size="sm">
                    <Link to="/post-job">
                      <PenSquare className="w-4 h-4" />
                      Post a Job
                    </Link>
                  </Button>
                </>
              )}
              <span className="hidden sm:inline text-xs text-muted-foreground max-w-[160px] truncate">
                {user?.email}
              </span>
              <Button variant="ghost" size="sm" onClick={handleSignOut}>
                <LogOut className="w-4 h-4" />
              </Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm">
                <Link to="/auth">Sign in</Link>
              </Button>
              <Button asChild size="sm">
                <Link to="/auth" search={{ mode: "signup" }}>
                  Get started
                </Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
