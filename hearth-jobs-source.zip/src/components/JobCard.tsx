import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { MapPin, Briefcase, ArrowUpRight } from "lucide-react";

export interface JobCardData {
  id: string;
  title: string;
  company: string;
  location: string;
  job_type: string;
  salary_range: string | null;
  is_remote: boolean | null;
  tags: string[] | null;
  created_at: string;
}

const typeLabel: Record<string, string> = {
  full_time: "Full-time",
  part_time: "Part-time",
  contract: "Contract",
  freelance: "Freelance",
  internship: "Internship",
};

export default function JobCard({ job }: { job: JobCardData }) {
  return (
    <Link
      to="/jobs/$jobId"
      params={{ jobId: job.id }}
      className="group block rounded-xl border border-border/70 bg-card p-6 transition-all hover:border-accent/50 hover:shadow-[var(--shadow-card)]"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-xs uppercase tracking-widest text-muted-foreground">
            {job.company}
          </div>
          <h3 className="font-serif text-2xl font-medium mt-1 leading-snug group-hover:text-accent transition-colors">
            {job.title}
          </h3>
        </div>
        <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-accent group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all shrink-0" />
      </div>

      <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5" />
          {job.location}
          {job.is_remote && " · Remote"}
        </span>
        <span className="flex items-center gap-1.5">
          <Briefcase className="w-3.5 h-3.5" />
          {typeLabel[job.job_type] ?? job.job_type}
        </span>
        {job.salary_range && <span>{job.salary_range}</span>}
      </div>

      {job.tags && job.tags.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {job.tags.slice(0, 4).map((tag) => (
            <Badge key={tag} variant="secondary" className="font-normal">
              {tag}
            </Badge>
          ))}
        </div>
      )}
    </Link>
  );
}
