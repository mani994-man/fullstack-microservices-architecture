import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import JobCard, { type JobCardData } from "@/components/JobCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Search } from "lucide-react";

export const Route = createFileRoute("/jobs/")({
  component: JobsPage,
  head: () => ({
    meta: [
      { title: "Browse Jobs — Hearth" },
      { name: "description", content: "Browse curated job openings from companies that care." },
      { property: "og:title", content: "Browse Jobs — Hearth" },
      { property: "og:description", content: "Curated openings updated daily." },
    ],
  }),
});

function JobsPage() {
  const [jobs, setJobs] = useState<JobCardData[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  useEffect(() => {
    supabase
      .from("jobs")
      .select("id, title, company, location, job_type, salary_range, is_remote, tags, created_at")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setJobs((data ?? []) as JobCardData[]);
        setLoading(false);
      });
  }, []);

  const filtered = jobs.filter((j) => {
    const q = query.toLowerCase().trim();
    if (!q) return true;
    return (
      j.title.toLowerCase().includes(q) ||
      j.company.toLowerCase().includes(q) ||
      j.location.toLowerCase().includes(q) ||
      (j.tags ?? []).some((t) => t.toLowerCase().includes(q))
    );
  });

  return (
    <Layout>
      <section className="px-6 md:px-8 pt-12 pb-8 max-w-7xl mx-auto">
        <div className="text-xs uppercase tracking-widest text-accent mb-2">All openings</div>
        <h1 className="font-serif text-5xl md:text-6xl font-light mb-6">
          Find your next chapter.
        </h1>
        <div className="relative max-w-xl">
          <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title, company, location, or skill"
            className="pl-11 h-12 bg-card"
          />
        </div>
      </section>

      <section className="px-6 md:px-8 pb-24 max-w-7xl mx-auto">
        {loading ? (
          <div className="grid md:grid-cols-2 gap-6">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-44 rounded-xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-border rounded-2xl">
            <p className="text-muted-foreground mb-4">
              {jobs.length === 0
                ? "No jobs posted yet. Be the first to post one."
                : "No jobs match your search."}
            </p>
            {jobs.length === 0 && (
              <Button asChild>
                <Link to="/post-job">Post a job</Link>
              </Button>
            )}
          </div>
        ) : (
          <>
            <div className="text-sm text-muted-foreground mb-6">
              {filtered.length} {filtered.length === 1 ? "role" : "roles"}
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {filtered.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          </>
        )}
      </section>
    </Layout>
  );
}
