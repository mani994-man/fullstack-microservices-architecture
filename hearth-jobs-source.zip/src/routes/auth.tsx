import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>) => ({
    mode: (search.mode as "signin" | "signup") ?? "signin",
  }),
  component: AuthPage,
  head: () => ({
    meta: [
      { title: "Sign in — Hearth" },
      { name: "description", content: "Sign in or create your Hearth account." },
    ],
  }),
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const { isAuthenticated, refreshRoles } = useAuth();

  const [tab, setTab] = useState<"signin" | "signup">(mode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [role, setRole] = useState<AppRole>("seeker");
  const [submitting, setSubmitting] = useState(false);

  if (isAuthenticated) {
    // Already signed in — bounce home
    navigate({ to: "/" });
  }

  const handleSignIn = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    await refreshRoles();
    toast.success("Welcome back");
    navigate({ to: "/" });
  };

  const handleSignUp = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: {
          display_name: displayName,
          company_name: role === "employer" ? companyName : null,
          role,
        },
      },
    });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    await refreshRoles();
    toast.success("Account created");
    navigate({ to: role === "employer" ? "/post-job" : "/jobs" });
  };

  return (
    <Layout>
      <section className="max-w-md mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <Link to="/" className="font-serif text-3xl font-semibold">
            Hearth
          </Link>
          <p className="text-muted-foreground text-sm mt-2">
            Welcome — let's get you in.
          </p>
        </div>

        <Tabs value={tab} onValueChange={(v) => setTab(v as "signin" | "signup")}>
          <TabsList className="grid grid-cols-2 w-full mb-8">
            <TabsTrigger value="signin">Sign in</TabsTrigger>
            <TabsTrigger value="signup">Create account</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form onSubmit={handleSignIn} className="space-y-4">
              <Field id="email" label="Email" type="email" value={email} setValue={setEmail} required />
              <Field
                id="password"
                label="Password"
                type="password"
                value={password}
                setValue={setPassword}
                required
              />
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Signing in…" : "Sign in"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label>I am a…</Label>
                <RadioGroup
                  value={role}
                  onValueChange={(v) => setRole(v as AppRole)}
                  className="grid grid-cols-2 gap-3"
                >
                  <RoleOption value="seeker" label="Job seeker" current={role} />
                  <RoleOption value="employer" label="Employer" current={role} />
                </RadioGroup>
              </div>

              <Field
                id="displayName"
                label={role === "employer" ? "Your name" : "Full name"}
                value={displayName}
                setValue={setDisplayName}
                required
              />
              {role === "employer" && (
                <Field
                  id="company"
                  label="Company name"
                  value={companyName}
                  setValue={setCompanyName}
                  required
                />
              )}
              <Field id="email2" label="Email" type="email" value={email} setValue={setEmail} required />
              <Field
                id="password2"
                label="Password (min 6 characters)"
                type="password"
                value={password}
                setValue={setPassword}
                required
              />
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Creating…" : "Create account"}
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                By signing up you agree to receive friendly emails about your account.
              </p>
            </form>
          </TabsContent>
        </Tabs>
      </section>
    </Layout>
  );
}

function Field({
  id,
  label,
  type = "text",
  value,
  setValue,
  required,
}: {
  id: string;
  label: string;
  type?: string;
  value: string;
  setValue: (v: string) => void;
  required?: boolean;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        type={type}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        required={required}
        autoComplete={type === "password" ? "current-password" : undefined}
      />
    </div>
  );
}

function RoleOption({
  value,
  label,
  current,
}: {
  value: AppRole;
  label: string;
  current: AppRole;
}) {
  const selected = current === value;
  return (
    <Label
      htmlFor={`role-${value}`}
      className={`cursor-pointer rounded-lg border p-4 text-center transition-colors ${
        selected
          ? "border-accent bg-accent/5 text-accent"
          : "border-border hover:border-foreground/30"
      }`}
    >
      <RadioGroupItem id={`role-${value}`} value={value} className="sr-only" />
      <span className="block font-medium">{label}</span>
    </Label>
  );
}
