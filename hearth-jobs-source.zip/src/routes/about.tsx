import { createFileRoute, Link } from "@tanstack/react-router";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About — Hearth" },
      {
        name: "description",
        content:
          "Hearth is a curated job portal connecting hearts with meaningful craft. Our story.",
      },
      { property: "og:title", content: "About — Hearth" },
      { property: "og:description", content: "Why we built a calmer place to find work." },
    ],
  }),
});

function AboutPage() {
  return (
    <Layout>
      <article className="max-w-3xl mx-auto px-6 md:px-8 py-16 md:py-24">
        <div className="text-xs uppercase tracking-widest text-accent mb-2">Our story</div>
        <h1 className="font-serif text-5xl md:text-6xl font-light mb-8 leading-tight">
          A calmer place to find <span className="italic text-accent">work</span>.
        </h1>

        <div className="prose prose-stone text-lg leading-relaxed text-foreground/85 space-y-6">
          <p>
            Hearth was born from a simple frustration: most job boards optimize for volume, not
            care. We wanted a place where openings feel hand-picked, where companies tell the
            truth about their teams, and where candidates can browse without the noise.
          </p>
          <p>
            We believe the best matches happen when both sides share what matters — the kind of
            craft they care about, the cadence they want to work in, the people they want around
            them. That's the conversation Hearth tries to start.
          </p>
          <h2 className="font-serif text-3xl font-medium mt-12">What we value</h2>
          <ul className="space-y-2">
            <li>Craft over churn.</li>
            <li>Honesty over hype.</li>
            <li>People over pipelines.</li>
          </ul>
        </div>

        <div className="mt-14 flex flex-wrap gap-3">
          <Button asChild size="lg">
            <Link to="/jobs">Browse openings</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/post-job">Post a job</Link>
          </Button>
        </div>
      </article>
    </Layout>
  );
}
