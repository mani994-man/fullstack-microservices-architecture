import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";

const JOB_TYPES = [
  { value: "full_time", label: "Full-time" },
  { value: "part_time", label: "Part-time" },
  { value: "contract", label: "Contract" },
  { value: "freelance", label: "Freelance" },
  { value: "internship", label: "Internship" },
];

export const Route = createFileRoute("/post-job")({
  component: PostJobPage,
  head: () => ({
    meta: [
      { title: "Post a Job — Hearth" },
      { name: "description", content: "Reach candidates who care about culture and craft." },
    ],
  }),
});

function PostJobPage() {
  const { isAuthenticated, isEmployer, loading } = useAuth();
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [company, setCompany] = useState("");
  const [location, setLocation] = useState("");
  const [jobType, setJobType] = useState("full_time");
  const [salaryRange, setSalaryRange] = useState("");
  const [isRemote, setIsRemote] = useState(false);
  const [tagsInput, setTagsInput] = useState("");
  const [description, setDescription] = useState("");
  const [requirements, setRequirements] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (loading) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto py-20 px-6">
          <div className="h-10 w-2/3 bg-muted rounded animate-pulse" />
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-24 px-6">
          <h1 className="font-serif text-4xl mb-3">Sign in to post a job</h1>
          <p className="text-muted-foreground mb-8">
            You need an employer account to publish openings on Hearth.
          </p>
          <div className="flex justify-center gap-3">
            <Button asChild>
              <Link to="/auth" search={{ mode: "signup" }}>
                Create employer account
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/auth">Sign in</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  if (!isEmployer) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-24 px-6">
          <h1 className="font-serif text-4xl mb-3">Employer access required</h1>
          <p className="text-muted-foreground mb-8">
            Your account is registered as a job seeker. Create an employer account to post jobs.
          </p>
          <Button asChild>
            <Link to="/auth" search={{ mode: "signup" }}>
              Create employer account
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const { data: userData } = await supabase.auth.getUser();
    const userId = userData.user?.id;
    if (!userId) {
      toast.error("Session expired. Please sign in again.");
      setSubmitting(false);
      return;
    }

    const tags = tagsInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    const { data, error } = await supabase
      .from("jobs")
      .insert({
        employer_id: userId,
        title: title.trim(),
        company: company.trim(),
        location: location.trim(),
        job_type: jobType as "full_time" | "part_time" | "contract" | "freelance" | "internship",
        salary_range: salaryRange.trim() || null,
        is_remote: isRemote,
        tags,
        description: description.trim(),
        requirements: requirements.trim() || null,
      })
      .select("id")
      .single();

    setSubmitting(false);

    if (error) {
      toast.error(error.message);
      return;
    }

    toast.success("Job posted");
    if (data) navigate({ to: "/jobs/$jobId", params: { jobId: data.id } });
  };

  return (
    <Layout>
      <section className="max-w-2xl mx-auto px-6 md:px-8 py-12">
        <div className="text-xs uppercase tracking-widest text-accent mb-2">New posting</div>
        <h1 className="font-serif text-4xl md:text-5xl font-light mb-3">Post a job</h1>
        <p className="text-muted-foreground mb-10">
          Tell candidates what makes this role special. Be honest, be warm.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="title">Job title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Senior Product Designer"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company">Company *</Label>
              <Input
                id="company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location *</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Berlin, Germany"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobType">Job type</Label>
              <Select value={jobType} onValueChange={setJobType}>
                <SelectTrigger id="jobType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {JOB_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="salary">Salary range</Label>
              <Input
                id="salary"
                value={salaryRange}
                onChange={(e) => setSalaryRange(e.target.value)}
                placeholder="€60,000 – €80,000"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="tags">Skills / tags (comma separated)</Label>
              <Input
                id="tags"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Figma, Design Systems, B2B"
              />
            </div>
            <div className="flex items-center gap-3 sm:col-span-2 rounded-lg border border-border p-4">
              <Switch id="remote" checked={isRemote} onCheckedChange={setIsRemote} />
              <Label htmlFor="remote" className="cursor-pointer">
                This role is remote-friendly
              </Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">About the role *</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              placeholder="What you'll do, the team, the impact…"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="requirements">What you're looking for</Label>
            <Textarea
              id="requirements"
              value={requirements}
              onChange={(e) => setRequirements(e.target.value)}
              rows={5}
              placeholder="Skills, experience, mindset…"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" size="lg" disabled={submitting}>
              {submitting ? "Publishing…" : "Publish job"}
            </Button>
            <Button asChild variant="ghost" type="button">
              <Link to="/jobs">Cancel</Link>
            </Button>
          </div>
        </form>
      </section>
    </Layout>
  );
}
