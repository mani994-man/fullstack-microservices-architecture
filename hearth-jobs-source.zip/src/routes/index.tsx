import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import JobCard, { type JobCardData } from "@/components/JobCard";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Hearth — Meaningful work, beautifully matched" },
      {
        name: "description",
        content:
          "Discover roles at companies that care about craft and culture. Browse curated openings or post your own.",
      },
      { property: "og:title", content: "Hearth — Meaningful work, beautifully matched" },
      { property: "og:description", content: "A curated job portal for seekers and employers." },
    ],
  }),
});

function Index() {
  const [jobs, setJobs] = useState<JobCardData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("jobs")
      .select("id, title, company, location, job_type, salary_range, is_remote, tags, created_at")
      .order("created_at", { ascending: false })
      .limit(3)
      .then(({ data }) => {
        setJobs((data ?? []) as JobCardData[]);
        setLoading(false);
      });
  }, []);

  return (
    <Layout>
      {/* Hero */}
      <section className="px-6 md:px-8 pt-12 md:pt-20 pb-16 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 items-center">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 px-3 py-1 bg-accent/10 text-accent rounded-full text-xs font-semibold tracking-wider uppercase mb-6 animate-fade-in">
              <Sparkles className="w-3 h-3" />
              Work that feels like home
            </span>
            <h1
              className="font-serif text-5xl md:text-6xl lg:text-7xl font-light leading-[1.05] tracking-tight mb-6 animate-fade-in"
              style={{ animationDelay: "0.1s" }}
            >
              Connecting hearts with{" "}
              <span className="italic text-accent">meaningful</span> craft.
            </h1>
            <p
              className="text-lg text-muted-foreground leading-relaxed max-w-[45ch] mb-10 animate-fade-in"
              style={{ animationDelay: "0.2s" }}
            >
              A curated job portal for seekers and employers who value culture, growth, and
              purposeful work.
            </p>
            <div
              className="flex flex-wrap gap-3 animate-fade-in"
              style={{ animationDelay: "0.3s" }}
            >
              <Button asChild size="lg">
                <Link to="/jobs">
                  Browse openings
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/post-job">Post a job</Link>
              </Button>
            </div>

            <div
              className="grid grid-cols-3 gap-6 max-w-md mt-14 animate-fade-in"
              style={{ animationDelay: "0.4s" }}
            >
              <Stat n="1.2K" label="Active roles" />
              <Stat n="400+" label="Companies" />
              <Stat n="15K" label="Job seekers" />
            </div>
          </div>

          <div className="relative animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <img
              src={heroImage}
              alt="Calm sunlit workspace with a journal and ceramic mug"
              width={1536}
              height={1024}
              className="rounded-2xl shadow-[var(--shadow-card)] object-cover w-full aspect-[4/3]"
            />
            <div className="absolute -bottom-6 -left-6 bg-card border border-border rounded-xl p-4 shadow-[var(--shadow-soft)] hidden md:block">
              <div className="text-xs uppercase tracking-widest text-muted-foreground">
                New this week
              </div>
              <div className="font-serif text-xl font-medium">28 roles</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs */}
      <section className="px-6 md:px-8 py-16 md:py-24 bg-card/50 border-y border-border/60">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="text-xs uppercase tracking-widest text-accent mb-2">
                Hand-picked
              </div>
              <h2 className="font-serif text-4xl md:text-5xl font-light">Featured roles</h2>
            </div>
            <Link
              to="/jobs"
              className="hidden md:inline-flex items-center gap-1 text-sm hover:text-accent"
            >
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-44 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <div className="text-center py-16 border border-dashed border-border rounded-2xl">
              <p className="text-muted-foreground mb-4">
                No jobs posted yet. Be the first.
              </p>
              <Button asChild>
                <Link to="/post-job">Post a job</Link>
              </Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {jobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 md:px-8 py-20 md:py-28 max-w-4xl mx-auto text-center">
        <h2 className="font-serif text-4xl md:text-5xl font-light leading-tight">
          Hire with <span className="italic text-accent">intention</span>.
        </h2>
        <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
          Reach candidates who care about more than a paycheck. Posting takes two minutes.
        </p>
        <Button asChild size="lg" className="mt-8">
          <Link to="/post-job">Post your first job</Link>
        </Button>
      </section>
    </Layout>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div>
      <div className="text-3xl font-serif font-semibold text-primary">{n}</div>
      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{label}</div>
    </div>
  );
}
