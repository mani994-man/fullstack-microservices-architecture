import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { Pencil, Trash2, MapPin, PenSquare, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  component: DashboardPage,
  head: () => ({
    meta: [
      { title: "My Jobs — Hearth" },
      { name: "description", content: "Manage the jobs you've posted on Hearth." },
    ],
  }),
});

type Job = {
  id: string;
  title: string;
  company: string;
  location: string;
  job_type: string;
  is_remote: boolean | null;
  created_at: string;
  tags: string[] | null;
};

function DashboardPage() {
  const { isAuthenticated, isEmployer, loading, user } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[] | null>(null);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!user?.id || !isEmployer) return;
    let cancelled = false;
    (async () => {
      setLoadingJobs(true);
      const { data, error } = await supabase
        .from("jobs")
        .select("id, title, company, location, job_type, is_remote, created_at, tags")
        .eq("employer_id", user.id)
        .order("created_at", { ascending: false });
      if (cancelled) return;
      if (error) toast.error(error.message);
      setJobs(data ?? []);
      setLoadingJobs(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id, isEmployer]);

  if (loading) {
    return (
      <Layout>
        <div className="max-w-5xl mx-auto py-20 px-6">
          <div className="h-10 w-1/3 bg-muted rounded animate-pulse" />
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-24 px-6">
          <h1 className="font-serif text-4xl mb-3">Sign in to view your dashboard</h1>
          <p className="text-muted-foreground mb-8">
            Manage your job postings from one place.
          </p>
          <div className="flex justify-center gap-3">
            <Button asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  if (!isEmployer) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-24 px-6">
          <h1 className="font-serif text-4xl mb-3">Employer access required</h1>
          <p className="text-muted-foreground mb-8">
            Only employer accounts can manage job postings.
          </p>
          <Button asChild>
            <Link to="/jobs">Browse jobs</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    const { error } = await supabase.from("jobs").delete().eq("id", deleteId);
    setDeleting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setJobs((prev) => (prev ? prev.filter((j) => j.id !== deleteId) : prev));
    setDeleteId(null);
    toast.success("Job deleted");
  };

  return (
    <Layout>
      <section className="max-w-5xl mx-auto px-6 md:px-8 py-12">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
          <div>
            <div className="text-xs uppercase tracking-widest text-accent mb-2">
              Employer dashboard
            </div>
            <h1 className="font-serif text-4xl md:text-5xl font-light">My jobs</h1>
            <p className="text-muted-foreground mt-2">
              Edit or remove the openings you've published.
            </p>
          </div>
          <Button asChild>
            <Link to="/post-job">
              <PenSquare className="w-4 h-4" />
              Post a Job
            </Link>
          </Button>
        </div>

        {loadingJobs ? (
          <div className="space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-28 bg-muted/40 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : !jobs || jobs.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-border rounded-xl">
            <h2 className="font-serif text-2xl mb-2">No jobs yet</h2>
            <p className="text-muted-foreground mb-6">
              Publish your first opening to start receiving candidates.
            </p>
            <Button asChild>
              <Link to="/post-job">
                <PenSquare className="w-4 h-4" />
                Post your first job
              </Link>
            </Button>
          </div>
        ) : (
          <ul className="space-y-3">
            {jobs.map((job) => (
              <li
                key={job.id}
                className="border border-border rounded-xl p-5 hover:border-foreground/20 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-serif text-xl truncate">{job.title}</h3>
                      {job.is_remote && (
                        <Badge variant="secondary" className="text-xs">
                          Remote
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-3 flex-wrap">
                      <span>{job.company}</span>
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {job.location}
                      </span>
                      <span className="capitalize">{job.job_type.replace("_", "-")}</span>
                      <span>· Posted {new Date(job.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to="/jobs/$jobId" params={{ jobId: job.id }}>
                        <ExternalLink className="w-4 h-4" />
                        View
                      </Link>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        navigate({ to: "/dashboard/edit/$jobId", params: { jobId: job.id } })
                      }
                    >
                      <Pencil className="w-4 h-4" />
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(job.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this job posting?</AlertDialogTitle>
            <AlertDialogDescription>
              This action can't be undone. The listing will no longer be visible to candidates.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                handleDelete();
              }}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
