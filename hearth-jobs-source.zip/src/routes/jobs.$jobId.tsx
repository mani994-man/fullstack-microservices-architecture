import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, MapPin, Briefcase, Calendar } from "lucide-react";

interface JobDetail {
  id: string;
  title: string;
  company: string;
  location: string;
  job_type: string;
  salary_range: string | null;
  is_remote: boolean | null;
  description: string;
  requirements: string | null;
  tags: string[] | null;
  created_at: string;
}

const typeLabel: Record<string, string> = {
  full_time: "Full-time",
  part_time: "Part-time",
  contract: "Contract",
  freelance: "Freelance",
  internship: "Internship",
};

export const Route = createFileRoute("/jobs/$jobId")({
  component: JobDetailPage,
  notFoundComponent: () => (
    <Layout>
      <div className="max-w-2xl mx-auto text-center py-32 px-6">
        <h1 className="font-serif text-4xl mb-4">Job not found</h1>
        <Button asChild>
          <Link to="/jobs">Back to jobs</Link>
        </Button>
      </div>
    </Layout>
  ),
});

function JobDetailPage() {
  const { jobId } = useParams({ from: "/jobs/$jobId" });
  const [job, setJob] = useState<JobDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("jobs")
      .select("*")
      .eq("id", jobId)
      .maybeSingle()
      .then(({ data }) => {
        setJob(data as JobDetail | null);
        setLoading(false);
      });
  }, [jobId]);

  if (loading) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto px-6 py-16">
          <div className="h-10 w-2/3 bg-muted rounded animate-pulse mb-4" />
          <div className="h-4 w-1/3 bg-muted rounded animate-pulse" />
        </div>
      </Layout>
    );
  }

  if (!job) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto text-center py-32 px-6">
          <h1 className="font-serif text-4xl mb-4">Job not found</h1>
          <Button asChild>
            <Link to="/jobs">Back to jobs</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <article className="max-w-3xl mx-auto px-6 md:px-8 py-12">
        <Link
          to="/jobs"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent mb-8"
        >
          <ArrowLeft className="w-4 h-4" /> All jobs
        </Link>

        <div className="text-xs uppercase tracking-widest text-accent">{job.company}</div>
        <h1 className="font-serif text-4xl md:text-5xl font-light mt-2 mb-6">{job.title}</h1>

        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground mb-8">
          <span className="flex items-center gap-1.5">
            <MapPin className="w-4 h-4" />
            {job.location}
            {job.is_remote && " · Remote"}
          </span>
          <span className="flex items-center gap-1.5">
            <Briefcase className="w-4 h-4" />
            {typeLabel[job.job_type] ?? job.job_type}
          </span>
          {job.salary_range && <span>{job.salary_range}</span>}
          <span className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            Posted {new Date(job.created_at).toLocaleDateString()}
          </span>
        </div>

        {job.tags && job.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-10">
            {job.tags.map((t) => (
              <Badge key={t} variant="secondary" className="font-normal">
                {t}
              </Badge>
            ))}
          </div>
        )}

        <div className="prose prose-stone max-w-none">
          <h2 className="font-serif text-2xl font-medium mt-10 mb-3">About the role</h2>
          <p className="whitespace-pre-wrap text-foreground/90 leading-relaxed">
            {job.description}
          </p>

          {job.requirements && (
            <>
              <h2 className="font-serif text-2xl font-medium mt-10 mb-3">What we're looking for</h2>
              <p className="whitespace-pre-wrap text-foreground/90 leading-relaxed">
                {job.requirements}
              </p>
            </>
          )}
        </div>

        <div className="mt-12 p-6 bg-card border border-border rounded-xl">
          <p className="text-sm text-muted-foreground">
            Interested? Reach out to <span className="font-medium text-foreground">{job.company}</span>{" "}
            to apply.
          </p>
        </div>
      </article>
    </Layout>
  );
}
