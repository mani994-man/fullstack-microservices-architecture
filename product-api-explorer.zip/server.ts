import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
}

// In-memory product storage
let products: Product[] = [
  {
    id: "1",
    name: "Quantum Speaker",
    description: "High-fidelity audio with spatial sound technology.",
    price: 299.99,
    category: "Electronics",
  },
  {
    id: "2",
    name: "Eco-Friendly Bottle",
    description: "Vacuum insulated stainless steel bottle.",
    price: 34.50,
    category: "Lifestyle",
  },
  {
    id: "3",
    name: "Minimalist Watch",
    description: "Sleek analog timepiece with leather strap.",
    price: 150.00,
    category: "Accessories",
  },
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // REST API Routes
  
  // GET all products
  app.get("/api/products", (req, res) => {
    res.json(products);
  });

  // GET product by ID
  app.get("/api/products/:id", (req, res) => {
    const product = products.find((p) => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  // POST create a new product
  app.post("/api/products", (req, res) => {
    const { name, description, price, category } = req.body;
    
    if (!name || !price) {
      return res.status(400).json({ message: "Name and price are required" });
    }

    const newProduct: Product = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      description: description || "",
      price,
      category: category || "General",
    };

    products.push(newProduct);
    res.status(201).json(newProduct);
  });

  // PUT update a product
  app.put("/api/products/:id", (req, res) => {
    const { id } = req.params;
    const { name, description, price, category } = req.body;

    const index = products.findIndex((p) => p.id === id);
    if (index === -1) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Update only provided fields
    products[index] = {
      ...products[index],
      name: name !== undefined ? name : products[index].name,
      description: description !== undefined ? description : products[index].description,
      price: price !== undefined ? price : products[index].price,
      category: category !== undefined ? category : products[index].category,
    };

    res.json(products[index]);
  });

  // DELETE a product
  app.delete("/api/products/:id", (req, res) => {
    const { id } = req.params;
    const index = products.findIndex((p) => p.id === id);
    if (index === -1) {
      return res.status(404).json({ message: "Product not found" });
    }

    const deletedProduct = products.splice(index, 1);
    res.json({ message: "Product deleted", product: deletedProduct[0] });
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Product API available at http://localhost:${PORT}/api/products`);
  });
}

startServer();
