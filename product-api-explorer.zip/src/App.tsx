/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Package, 
  Search, 
  Code, 
  RefreshCcw,
  CheckCircle2,
  AlertCircle,
  X
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
}

interface LastResponse {
  method: string;
  url: string;
  status: number;
  data: any;
  timestamp: string;
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [lastResponse, setLastResponse] = useState<LastResponse | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "Electronics"
  });

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/products");
      const data = await response.json();
      setProducts(data);
      logResponse("GET", "/api/products", response.status, data);
    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const logResponse = (method: string, url: string, status: number, data: any) => {
    setLastResponse({
      method,
      url,
      status,
      data,
      timestamp: new Date().toLocaleTimeString()
    });
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          price: parseFloat(formData.price)
        }),
      });
      const data = await response.json();
      logResponse("POST", "/api/products", response.status, data);
      
      if (response.ok) {
        setProducts([...products, data]);
        closeForm();
      }
    } catch (error) {
      console.error("Error creating product:", error);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    try {
      const response = await fetch(`/api/products/${editingProduct.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          price: parseFloat(formData.price)
        }),
      });
      const data = await response.json();
      logResponse("PUT", `/api/products/${editingProduct.id}`, response.status, data);

      if (response.ok) {
        setProducts(products.map(p => p.id === editingProduct.id ? data : p));
        closeForm();
      }
    } catch (error) {
      console.error("Error updating product:", error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return;

    try {
      const response = await fetch(`/api/products/${id}`, {
        method: "DELETE",
      });
      const data = await response.json();
      logResponse("DELETE", `/api/products/${id}`, response.status, data);

      if (response.ok) {
        setProducts(products.filter(p => p.id !== id));
      }
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  const openForm = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        description: product.description,
        price: product.price.toString(),
        category: product.category
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        description: "",
        price: "",
        category: "Electronics"
      });
    }
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setEditingProduct(null);
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-editorial-bg font-sans text-editorial-ink flex">
      {/* Editorial Rail */}
      <aside className="w-20 border-r border-editorial-line flex flex-col items-center justify-between py-10 sticky top-0 h-screen hidden md:flex">
        <div className="writing-vertical-rl rotate-180 text-[11px] tracking-[0.2em] uppercase text-editorial-accent">
          Product Lifecycle Management
        </div>
        <div className="writing-vertical-rl rotate-180 text-[11px] tracking-[0.2em] uppercase text-editorial-accent">
          EST. 2026
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 md:p-16 flex flex-col min-h-screen relative overflow-hidden">
        {/* Background Task Number */}
        <span className="absolute top-10 left-10 font-serif text-[180px] italic leading-none text-editorial-accent opacity-5 pointer-events-none select-none z-0">
          12
        </span>

        <div className="relative z-10 flex-1 flex flex-col">
          <header className="mb-12">
            <h1 className="font-serif text-5xl md:text-7xl font-light leading-[1.1] mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
              Product<br />
              <span className="italic text-editorial-accent">Management API</span>
            </h1>
            
            <div className="flex flex-wrap gap-10 border-t border-editorial-line pt-6 text-[11px] uppercase tracking-[0.15em] text-editorial-accent">
              <div className="flex flex-col gap-1">
                <span className="opacity-50">Status</span>
                <span className="font-bold">Active / Ver 1.0</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="opacity-50">Architecture</span>
                <span className="font-bold">RESTful / Express</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="opacity-50">Format</span>
                <span className="font-bold">Application / JSON</span>
              </div>
            </div>
          </header>

          <div className="flex-1 flex flex-col gap-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md group">
                <Search className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-editorial-accent" />
                <input 
                  type="text" 
                  placeholder="FILTER BY NAME OR CATEGORY..."
                  className="w-full pl-8 py-2 bg-transparent border-b border-editorial-line focus:border-editorial-accent outline-none transition-all uppercase text-[12px] tracking-widest placeholder:text-editorial-accent/30"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex gap-4">
                <button 
                  onClick={() => fetchProducts()}
                  className="p-2 border border-editorial-line hover:border-editorial-accent transition-colors text-editorial-accent"
                >
                  <RefreshCcw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                </button>
                <button 
                  onClick={() => openForm()}
                  className="px-6 py-2 bg-editorial-ink text-editorial-bg text-[12px] uppercase tracking-widest hover:bg-editorial-accent transition-colors flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  New Product
                </button>
              </div>
            </div>

            <div className="divide-y divide-editorial-line">
              <AnimatePresence mode="popLayout">
                {loading && products.length === 0 ? (
                  <div className="py-12 italic font-serif text-editorial-accent">Querying database...</div>
                ) : filteredProducts.length === 0 ? (
                  <div className="py-12 border-b border-editorial-line italic font-serif text-editorial-accent">
                    No results found for the current filter.
                  </div>
                ) : (
                  filteredProducts.map((product) => (
                    <motion.div 
                      key={product.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="group py-6 grid grid-cols-[1fr,auto] gap-4"
                    >
                      <div className="flex flex-col gap-1">
                        <div className="flex items-baseline gap-4">
                          <h3 className="font-serif text-2xl group-hover:text-editorial-accent transition-colors">{product.name}</h3>
                          <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 border border-editorial-accent/30 text-editorial-accent rounded-full">
                            {product.category}
                          </span>
                        </div>
                        <p className="text-sm font-serif italic text-editorial-accent/70 max-w-xl">{product.description}</p>
                        <span className="font-mono text-[13px] mt-2">${product.price.toFixed(2)}</span>
                      </div>
                      <div className="flex flex-col justify-center gap-2">
                        <button 
                          onClick={() => openForm(product)}
                          className="p-2 border border-editorial-line hover:border-editorial-accent hover:text-editorial-accent transition-all"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(product.id)}
                          className="p-2 border border-editorial-line hover:border-red-800 hover:text-red-800 transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>
          
          <footer className="mt-12 pt-8 border-t border-editorial-line flex flex-col md:flex-row justify-between text-[10px] uppercase tracking-widest text-editorial-accent/60">
            <div>&copy; 2026 Editorial Product Systems</div>
            <div className="flex gap-6">
              <span>H2 Database Persistence</span>
              <span>REST Compliant</span>
            </div>
          </footer>
        </div>
      </main>

      {/* Side Panel: Inspector */}
      <aside className="w-[450px] bg-editorial-side border-l border-editorial-line p-12 hidden lg:flex flex-col">
        <div className="flex flex-wrap gap-2 mb-8">
          <span className="px-3 py-1 border border-editorial-accent text-[10px] uppercase tracking-widest text-editorial-accent rounded-full">RESTful</span>
          <span className="px-3 py-1 border border-editorial-accent text-[10px] uppercase tracking-widest text-editorial-accent rounded-full">CRUD</span>
          <span className="px-3 py-1 border border-editorial-accent text-[10px] uppercase tracking-widest text-editorial-accent rounded-full">Node.js</span>
        </div>

        <p className="font-serif italic text-lg text-editorial-accent mb-12">
          "A robust REST architecture designed for seamless product lifecycle management and efficient data persistence."
        </p>

        <div className="mt-auto">
          <div className="bg-editorial-ink p-8 rounded shadow-2xl relative">
            <span className="absolute top-4 right-4 text-[10px] text-gray-600 font-mono italic">
              {lastResponse?.timestamp || "--:--:--"}
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 block mb-6">
              Sample Response / API Capture
            </span>

            {lastResponse ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-3">
                    <span className={`text-[11px] font-bold ${
                      lastResponse.method === 'GET' ? 'text-green-400' :
                      lastResponse.method === 'POST' ? 'text-blue-400' :
                      lastResponse.method === 'PUT' ? 'text-orange-400' :
                      'text-red-400'
                    }`}>
                      {lastResponse.method}
                    </span>
                    <span className="text-[11px] font-mono text-gray-400 truncate max-w-[150px]">
                      {lastResponse.url}
                    </span>
                  </div>
                  <span className={`text-[11px] font-mono ${lastResponse.status < 400 ? 'text-green-500' : 'text-red-500'}`}>
                    HTTP {lastResponse.status}
                  </span>
                </div>
                <pre className="font-mono text-[13px] leading-relaxed text-[#A5D6A7] overflow-auto max-h-[350px] scrollbar-hide">
                  {JSON.stringify(lastResponse.data, null, 2)}
                </pre>
              </div>
            ) : (
              <div className="py-12 border border-dashed border-white/10 rounded flex items-center justify-center">
                <p className="text-[11px] text-gray-600 uppercase tracking-widest italic">Awaiting API traffic...</p>
              </div>
            )}
          </div>
          
          <div className="mt-8 text-[11px] text-editorial-accent/60 leading-relaxed font-serif italic">
            Implementation details cover validation, exception handling, and standard HTTP response codes for industrial-grade integration.
          </div>
        </div>
      </aside>

      {/* Modal Overlay */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeForm}
              className="absolute inset-0 bg-editorial-ink/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-editorial-bg border border-editorial-line shadow-2xl"
            >
              <div className="p-10">
                <div className="flex items-center justify-between mb-10 pb-4 border-b border-editorial-line">
                  <h2 className="font-serif text-3xl italic text-editorial-accent">
                    {editingProduct ? "Revise Entry" : "New Entry"}
                  </h2>
                  <button onClick={closeForm} className="p-2 hover:text-editorial-accent transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={editingProduct ? handleUpdate : handleCreate} className="space-y-8">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-editorial-accent font-bold">Nomenclature</label>
                    <input 
                      required
                      type="text" 
                      placeholder="PRODUCT NAME"
                      className="w-full px-4 py-3 bg-editorial-side border-b border-editorial-line focus:border-editorial-accent outline-none font-serif italic"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-10">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase tracking-widest text-editorial-accent font-bold">Valuation</label>
                      <input 
                        required
                        type="number" 
                        step="0.01"
                        placeholder="0.00"
                        className="w-full px-4 py-3 bg-editorial-side border-b border-editorial-line focus:border-editorial-accent outline-none font-mono"
                        value={formData.price}
                        onChange={(e) => setFormData({...formData, price: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase tracking-widest text-editorial-accent font-bold">Classification</label>
                      <select 
                        className="w-full px-4 py-3 bg-editorial-side border-b border-editorial-line focus:border-editorial-accent outline-none appearance-none uppercase text-[12px] tracking-widest"
                        value={formData.category}
                        onChange={(e) => setFormData({...formData, category: e.target.value})}
                      >
                        <option>Electronics</option>
                        <option>Lifestyle</option>
                        <option>Accessories</option>
                        <option>Office</option>
                        <option>Home</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-editorial-accent font-bold">Contextual Details</label>
                    <textarea 
                      rows={3}
                      placeholder="DESCRIPTION..."
                      className="w-full px-4 py-3 bg-editorial-side border-b border-editorial-line focus:border-editorial-accent outline-none font-serif italic resize-none"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                    />
                  </div>

                  <div className="pt-6">
                    <button 
                      type="submit"
                      className="w-full py-4 bg-editorial-ink text-editorial-bg text-[12px] uppercase tracking-[0.2em] font-bold hover:bg-editorial-accent transition-colors"
                    >
                      {editingProduct ? "COMMIT UPDATES" : "REGISTER PRODUCT"}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
