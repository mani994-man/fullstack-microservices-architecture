/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  Activity, 
  Users, 
  History, 
  Plus, 
  Edit2, 
  Check, 
  X,
  AlertCircle,
  BarChart3,
  Calendar,
  Clock,
  Briefcase,
  Terminal
} from 'lucide-react';

interface Employee {
  id: number;
  name: string;
  position: string;
  department: string;
  status: string;
  updated_at: string;
}

interface AuditLog {
  id: number;
  table_name: string;
  operation: string;
  old_data: string | null;
  new_data: string | null;
  timestamp: string;
}

interface DailyReport {
  activity_date: string;
  operation: string;
  count: number;
  log_ids: string;
}

export default function App() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [reports, setReports] = useState<DailyReport[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'employees' | 'reports'>('employees');

  const [formData, setFormData] = useState({
    name: '',
    position: '',
    department: 'Engineering'
  });

  const fetchData = async () => {
    try {
      const [empRes, logRes, reportRes] = await Promise.all([
        fetch('/api/employees'),
        fetch('/api/audit-logs'),
        fetch('/api/reports/daily')
      ]);
      
      setEmployees(await empRes.json());
      setLogs(await logRes.json());
      setReports(await reportRes.json());
    } catch (err) {
      console.error('Failed to fetch data', err);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    setFormData({ name: '', position: '', department: 'Engineering' });
    setIsAdding(false);
    fetchData();
  };

  const handleUpdate = async (id: number, data: Partial<Employee>) => {
    await fetch(`/api/employees/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    setEditingId(null);
    fetchData();
  };

  return (
    <div className="flex h-screen w-full bg-paper overflow-hidden text-ink font-sans">
      {/* 1. Left Rail Navigation (80px) */}
      <nav className="w-20 border-r border-border flex flex-col items-center py-10 gap-10 shrink-0">
        <div className="w-8 h-8 bg-ink rounded-full mb-10 ring-4 ring-border ring-offset-2 ring-offset-paper ring-opacity-50" />
        <button 
          onClick={() => setActiveTab('employees')}
          className={`p-3 transition-colors ${activeTab === 'employees' ? 'text-accent' : 'text-muted hover:text-ink'}`}
        >
          <Users size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('reports')}
          className={`p-3 transition-colors ${activeTab === 'reports' ? 'text-accent' : 'text-muted hover:text-ink'}`}
        >
          <BarChart3 size={24} />
        </button>
        <div className="mt-auto p-3 text-muted">
          <Terminal size={20} />
        </div>
      </nav>

      {/* 2. Main Content Area */}
      <main className="flex-1 px-20 py-16 overflow-y-auto">
        <header className="mb-16">
          <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-accent mb-3 block">
            Database Audit Node // 04
          </span>
          <h1 className="font-serif text-[72px] leading-[0.9] tracking-[-2px] mb-12">
            System Intelligence &<br />Operational Logs
          </h1>
          
          <div className="grid grid-cols-3 gap-10 border-t border-ink pt-6 max-w-3xl">
            <div className="space-y-1">
              <h3 className="font-serif italic text-2xl font-normal leading-tight">
                {employees.length}
              </h3>
              <p className="text-[12px] text-muted uppercase tracking-wider">Active Records</p>
            </div>
            <div className="space-y-1">
              <h3 className="font-serif italic text-2xl font-normal leading-tight">
                0.02ms
              </h3>
              <p className="text-[12px] text-muted uppercase tracking-wider">Audit Latency</p>
            </div>
            <div className="space-y-1">
              <h3 className="font-serif italic text-2xl font-normal leading-tight">
                SECURE
              </h3>
              <p className="text-[12px] text-muted uppercase tracking-wider">System Status</p>
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'employees' ? (
            <motion.div
              key="employees"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="space-y-10"
            >
              <div className="flex justify-between items-baseline mb-6 border-b-2 border-ink pb-1">
                <h2 className="font-serif text-2xl italic">Personnel Index</h2>
                <button 
                  onClick={() => setIsAdding(!isAdding)}
                  className="text-[11px] uppercase font-bold tracking-widest text-accent hover:underline flex items-center gap-2"
                >
                  {isAdding ? <X size={12} /> : <Plus size={12} />}
                  {isAdding ? 'Cancel Entry' : 'New Registration'}
                </button>
              </div>

              {isAdding && (
                <motion.form 
                  onSubmit={handleCreate}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="bg-aside-bg p-8 border border-border mb-12 space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-muted tracking-wider">Full Name</label>
                      <input 
                        required
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-transparent border-b border-ink p-1 outline-none font-serif italic text-lg focus:border-accent transition-colors"
                        placeholder="Employee Name"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-muted tracking-wider">Position</label>
                      <input 
                        required
                        value={formData.position}
                        onChange={e => setFormData({ ...formData, position: e.target.value })}
                        className="w-full bg-transparent border-b border-ink p-1 outline-none font-sans text-sm tracking-tight focus:border-accent transition-colors"
                        placeholder="Professional Title"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-muted tracking-wider">Department</label>
                      <select 
                        value={formData.department}
                        onChange={e => setFormData({ ...formData, department: e.target.value })}
                        className="w-full bg-transparent border-b border-ink p-1 outline-none font-sans text-xs uppercase tracking-widest cursor-pointer"
                      >
                        <option>Engineering</option>
                        <option>Design</option>
                        <option>Operations</option>
                        <option>Legal</option>
                      </select>
                    </div>
                  </div>
                  <button type="submit" className="px-8 py-3 bg-ink text-paper text-[11px] uppercase font-bold tracking-[0.2em] hover:bg-accent transition-colors">
                    Commit to Database
                  </button>
                </motion.form>
              )}

              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-4 text-[10px] text-muted font-bold uppercase tracking-[0.1em]">UID</th>
                    <th className="text-left py-4 text-[10px] text-muted font-bold uppercase tracking-[0.1em]">Identity</th>
                    <th className="text-left py-4 text-[10px] text-muted font-bold uppercase tracking-[0.1em]">Role</th>
                    <th className="text-left py-4 text-[10px] text-muted font-bold uppercase tracking-[0.1em]">Department</th>
                    <th className="text-right py-4 text-[10px] text-muted font-bold uppercase tracking-[0.1em]">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map(emp => (
                    <tr key={emp.id} className="border-b border-border group">
                      <td className="py-5 font-mono text-[11px] opacity-40">#{emp.id}</td>
                      <td className="py-5">
                        {editingId === emp.id ? (
                          <input className="bg-transparent border-b border-accent outline-none font-serif italic" defaultValue={emp.name} id={`edit-name-${emp.id}`} />
                        ) : (
                          <span className="font-bold tracking-tight">{emp.name}</span>
                        )}
                      </td>
                      <td className="py-5">
                        {editingId === emp.id ? (
                          <input className="bg-transparent border-b border-accent outline-none text-sm" defaultValue={emp.position} id={`edit-pos-${emp.id}`} />
                        ) : (
                          <span className="font-serif italic text-muted text-sm">{emp.position}</span>
                        )}
                      </td>
                      <td className="py-5">
                        <span className="text-[9px] border border-ink px-2 py-0.5 font-bold uppercase tracking-widest">
                          {emp.department}
                        </span>
                      </td>
                      <td className="py-5 text-right">
                        {editingId === emp.id ? (
                          <div className="flex justify-end gap-3 text-accent">
                            <button onClick={() => {
                              const name = (document.getElementById(`edit-name-${emp.id}`) as HTMLInputElement).value;
                              const position = (document.getElementById(`edit-pos-${emp.id}`) as HTMLInputElement).value;
                              handleUpdate(emp.id, { name, position });
                            }}><Check size={16} /></button>
                            <button onClick={() => setEditingId(null)}><X size={16} className="text-muted" /></button>
                          </div>
                        ) : (
                          <button onClick={() => setEditingId(emp.id)} className="opacity-0 group-hover:opacity-100 transition-opacity text-muted hover:text-ink">
                            <Edit2 size={14} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </motion.div>
          ) : (
            <motion.div
              key="reports"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="space-y-12"
            >
              <div className="border-b-2 border-ink pb-1">
                <h2 className="font-serif text-2xl italic">Daily Activity Reports</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {reports.map((report, idx) => (
                  <div key={idx} className="border border-border p-8 bg-aside-bg relative">
                    <span className="absolute top-4 right-6 text-[9px] uppercase font-bold text-accent tracking-tighter">
                      Index #{idx + 1}
                    </span>
                    <div className="flex items-center gap-2 text-accent mb-4">
                      <Calendar size={14} />
                      <span className="font-mono text-[11px] font-bold">{report.activity_date}</span>
                    </div>
                    <div className="flex items-end gap-4 mb-6">
                      <span className="text-6xl font-serif italic text-ink leading-none">{report.count}</span>
                      <span className="text-[10px] uppercase font-bold text-muted tracking-widest leading-loose">
                        Automated {report.operation}s
                      </span>
                    </div>
                    <div className="border-t border-border pt-4">
                      <p className="text-[9px] uppercase font-bold text-muted mb-2">Affected Log Range</p>
                      <div className="flex flex-wrap gap-1">
                        {report.log_ids.split(',').slice(0, 10).map(id => (
                          <span key={id} className="text-[10px] font-mono opacity-50">TX{id}</span>
                        ))}
                        {report.log_ids.split(',').length > 10 && <span className="text-[10px] font-mono opacity-50">...</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-ink p-10 text-paper">
                <div className="flex items-center gap-3 mb-6">
                  <Terminal size={18} className="text-accent" />
                  <h3 className="text-xs uppercase font-bold tracking-[0.2em]">Compiled SQL View Definition</h3>
                </div>
                <pre className="font-mono text-[11px] leading-relaxed overflow-x-auto text-paper/70">
                  <span className="text-accent">CREATE VIEW</span> daily_activity_summary AS{"\n"}
                  <span className="text-accent">SELECT</span> {"\n"}
                  &nbsp;&nbsp;date(timestamp) as activity_date,{"\n"}
                  &nbsp;&nbsp;operation,{"\n"}
                  &nbsp;&nbsp;count(*) as count,{"\n"}
                  &nbsp;&nbsp;group_concat(id) as log_ids{"\n"}
                  <span className="text-accent">FROM</span> audit_logs{"\n"}
                  <span className="text-accent">GROUP BY</span> activity_date, operation;
                </pre>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* 3. Right Sidebar (Aside) - 320px */}
      <aside className="w-80 bg-aside-bg border-l border-border px-10 py-16 flex flex-col shrink-0 overflow-y-auto">
        <header className="mb-10">
          <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-accent mb-3 block">Live Trigger Stream</span>
          <p className="font-serif italic text-ink leading-snug">Real-time audit captures from automated database triggers.</p>
        </header>

        <div className="flex-1 space-y-8">
          {logs.slice(0, 15).map((log) => (
            <div key={log.id} className="border-l-2 border-accent pl-5 space-y-1">
              <time className="text-[11px] font-serif italic text-muted">
                {new Date(log.timestamp).toLocaleTimeString()}
              </time>
              <span className="block font-bold text-[13px] tracking-tight">
                {log.operation} on [employees]
              </span>
              <span className="block text-[11px] text-muted overflow-hidden text-ellipsis whitespace-nowrap">
                ID: {log.id} • TX_REF: {Math.random().toString(36).substring(7).toUpperCase()}
              </span>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-ink text-paper py-4 text-center text-[10px] font-bold tracking-[0.2em] uppercase">
          Secure Node Active
        </div>
      </aside>
    </div>
  );
}
