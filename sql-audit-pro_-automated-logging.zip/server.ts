import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database('database.db');

// Initialize Database Schema
db.exec(`
  -- Table for Employees
  CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    position TEXT NOT NULL,
    department TEXT NOT NULL,
    status TEXT DEFAULT 'active',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  -- Table for Audit Logs
  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    operation TEXT NOT NULL,
    old_data TEXT,
    new_data TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  -- Trigger for INSERT on employees
  CREATE TRIGGER IF NOT EXISTS audit_employee_insert
  AFTER INSERT ON employees
  BEGIN
    INSERT INTO audit_logs (table_name, operation, new_data)
    VALUES ('employees', 'INSERT', json_object('id', NEW.id, 'name', NEW.name, 'position', NEW.position, 'department', NEW.department));
  END;

  -- Trigger for UPDATE on employees
  CREATE TRIGGER IF NOT EXISTS audit_employee_update
  AFTER UPDATE ON employees
  BEGIN
    INSERT INTO audit_logs (table_name, operation, old_data, new_data)
    VALUES (
      'employees', 
      'UPDATE', 
      json_object('id', OLD.id, 'name', OLD.name, 'position', OLD.position, 'department', OLD.department),
      json_object('id', NEW.id, 'name', NEW.name, 'position', NEW.position, 'department', NEW.department)
    );
  END;

  -- View for Daily Activity Report
  CREATE VIEW IF NOT EXISTS daily_activity_summary AS
  SELECT 
    date(timestamp) as activity_date,
    operation,
    count(*) as count,
    group_concat(id) as log_ids
  FROM audit_logs
  GROUP BY activity_date, operation;
`);

async function startServer() {
  const app = express();
  app.use(express.json());

  const PORT = 3000;

  // API Routes
  app.get('/api/employees', (req, res) => {
    const employees = db.prepare('SELECT * FROM employees ORDER BY updated_at DESC').all();
    res.json(employees);
  });

  app.post('/api/employees', (req, res) => {
    const { name, position, department } = req.body;
    const info = db.prepare('INSERT INTO employees (name, position, department) VALUES (?, ?, ?)').run(name, position, department);
    res.json({ id: info.lastInsertRowid });
  });

  app.put('/api/employees/:id', (req, res) => {
    const { id } = req.params;
    const { name, position, department, status } = req.body;
    db.prepare('UPDATE employees SET name = ?, position = ?, department = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(name, position, department, status, id);
    res.json({ success: true });
  });

  app.get('/api/audit-logs', (req, res) => {
    const logs = db.prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 50').all();
    res.json(logs);
  });

  app.get('/api/reports/daily', (req, res) => {
    const report = db.prepare('SELECT * FROM daily_activity_summary ORDER BY activity_date DESC').all();
    res.json(report);
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
