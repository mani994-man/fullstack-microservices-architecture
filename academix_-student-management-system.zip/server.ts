import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import cors from "cors";

// Initialize Database
const db = new Database("students.db");

// Mocking JPA-like behavior with table creation
db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    major TEXT,
    gpa REAL,
    enrollment_date TEXT
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // API Routes
  
  // Create
  app.post("/api/students", (req, res) => {
    const { name, email, major, gpa, enrollment_date } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO students (name, email, major, gpa, enrollment_date) VALUES (?, ?, ?, ?, ?)");
      const info = stmt.run(name, email, major, gpa, enrollment_date);
      res.status(201).json({ id: info.lastInsertRowid, name, email, major, gpa, enrollment_date });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Read (All)
  app.get("/api/students", (req, res) => {
    try {
      const students = db.prepare("SELECT * FROM students").all();
      res.json(students);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Read (One)
  app.get("/api/students/:id", (req, res) => {
    try {
      const student = db.prepare("SELECT * FROM students WHERE id = ?").get(req.params.id);
      if (student) res.json(student);
      else res.status(404).json({ error: "Student not found" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update
  app.put("/api/students/:id", (req, res) => {
    const { name, email, major, gpa, enrollment_date } = req.body;
    try {
      const stmt = db.prepare("UPDATE students SET name = ?, email = ?, major = ?, gpa = ?, enrollment_date = ? WHERE id = ?");
      const info = stmt.run(name, email, major, gpa, enrollment_date, req.params.id);
      if (info.changes > 0) res.json({ id: req.params.id, name, email, major, gpa, enrollment_date });
      else res.status(404).json({ error: "Student not found" });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Delete
  app.delete("/api/students/:id", (req, res) => {
    try {
      const stmt = db.prepare("DELETE FROM students WHERE id = ?");
      const info = stmt.run(req.params.id);
      if (info.changes > 0) res.json({ success: true });
      else res.status(404).json({ error: "Student not found" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
