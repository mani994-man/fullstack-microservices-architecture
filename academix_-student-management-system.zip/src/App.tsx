import React, { useState, useEffect } from "react";
import axios from "axios";
import { motion, AnimatePresence } from "motion/react";
import { 
  Users, 
  Plus, 
  Search, 
  Trash2, 
  Edit2, 
  UserPlus, 
  GraduationCap, 
  Mail, 
  BookOpen, 
  Star, 
  Calendar,
  X,
  Check
} from "lucide-react";
import { Student } from "./types";

export default function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<Student>({
    name: "",
    email: "",
    major: "",
    gpa: 0,
    enrollment_date: new Date().toISOString().split("T")[0]
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const res = await axios.get("/api/students");
      setStudents(res.data);
      setError(null);
    } catch (err) {
      setError("Failed to fetch students. Is the server running?");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingStudent) {
        await axios.put(`/api/students/${editingStudent.id}`, formData);
      } else {
        await axios.post("/api/students", formData);
      }
      setShowModal(false);
      setEditingStudent(null);
      resetForm();
      fetchStudents();
    } catch (err: any) {
      alert(err.response?.data?.error || "An error occurred");
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Are you sure you want to remove this student?")) return;
    try {
      await axios.delete(`/api/students/${id}`);
      fetchStudents();
    } catch (err) {
      alert("Failed to delete student");
    }
  };

  const handleEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData(student);
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      major: "",
      gpa: 0,
      enrollment_date: new Date().toISOString().split("T")[0]
    });
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase()) ||
    s.major.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-screen w-full bg-bg text-ink font-sans overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-[220px] border-r border-line flex flex-col shrink-0">
        <div className="p-6 border-b border-line font-serif italic text-lg">
          Academix v2.0
        </div>
        
        <nav className="py-4 flex-grow overflow-y-auto">
          <button className="w-full flex items-center px-6 py-2.5 bg-ink text-bg font-medium text-xs uppercase tracking-wider">
            Students View
          </button>
          <button className="w-full flex items-center px-6 py-2.5 text-ink hover:bg-black/5 font-medium text-xs uppercase tracking-wider transition-colors">
            Enrollment Log
          </button>
          <button className="w-full flex items-center px-6 py-2.5 text-ink hover:bg-black/5 font-medium text-xs uppercase tracking-wider transition-colors">
            Course Mapping
          </button>
          <button className="w-full flex items-center px-6 py-2.5 text-ink hover:bg-black/5 font-medium text-xs uppercase tracking-wider transition-colors">
            System Config
          </button>
        </nav>

        <div className="p-4 border-t border-line bg-black/5">
          <div className="font-mono text-[10px] uppercase opacity-60 mb-1">Database</div>
          <div className="font-mono text-[11px] font-bold">SQLITE_PERSISTENT:ON</div>
          <div className="font-mono text-[10px] uppercase opacity-60 mt-3 mb-1">ORM Emulation</div>
          <div className="font-mono text-[11px] font-bold text-accent">JPA/HIBERNATE 6</div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-[64px] border-b border-line flex items-center justify-between px-6 shrink-0">
          <div className="relative">
            <input 
              type="text" 
              placeholder="FIND STUDENT BY ID OR NAME..." 
              className="w-[300px] bg-transparent border border-line px-3 py-1.5 font-mono text-xs focus:ring-1 focus:ring-ink outline-none transition-all"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <button className="btn-minimal">Export CSV</button>
            <button 
              onClick={() => { resetForm(); setEditingStudent(null); setShowModal(true); }}
              className="btn-minimal btn-minimal-primary"
            >
              + New Student
            </button>
          </div>
        </header>

        {/* Table Container */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="grid grid-cols-[60px,1.5fr,1.5fr,1fr,100px,120px] border-b border-line bg-black/5 shrink-0">
            <div className="header-cell-minimal">ID</div>
            <div className="header-cell-minimal">Full Name</div>
            <div className="header-cell-minimal">Institutional Email</div>
            <div className="header-cell-minimal">Academic Major</div>
            <div className="header-cell-minimal">GPA</div>
            <div className="header-cell-minimal border-r-0">Actions</div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-line">
            {loading ? (
              <div className="p-12 text-center font-mono text-xs animate-pulse uppercase tracking-widest opacity-50">Initializing student record sets...</div>
            ) : filteredStudents.length === 0 ? (
              <div className="p-12 text-center">
                <p className="font-mono text-xs uppercase opacity-50">No data found in current schema.</p>
              </div>
            ) : (
              <AnimatePresence>
                {filteredStudents.map((student) => (
                  <motion.div 
                    key={student.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="table-row-minimal grid grid-cols-[60px,1.5fr,1.5fr,1fr,100px,120px] group"
                  >
                    <div className="cell-minimal">{student.id}</div>
                    <div className="cell-minimal font-bold">{student.name.toUpperCase()}</div>
                    <div className="cell-minimal italic">{student.email}</div>
                    <div className="cell-minimal">{student.major.toUpperCase()}</div>
                    <div className="cell-minimal">
                      <span className={`px-2 py-0.5 border border-current text-[10px] font-bold ${
                        student.gpa >= 3.5 ? "text-accent" : "text-ink"
                      }`}>
                        {student.gpa.toFixed(2)}
                      </span>
                    </div>
                    <div className="cell-minimal border-r-0 flex justify-end gap-1">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleEdit(student); }}
                        className="px-2 py-0.5 bg-bg text-ink border border-line text-[9px] font-bold hover:bg-ink hover:text-bg transition-colors uppercase"
                      >
                        Edit
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); student.id && handleDelete(student.id); }}
                        className="px-2 py-0.5 bg-bg text-ink border border-line text-[9px] font-bold hover:bg-red-600 hover:text-white hover:border-red-600 transition-colors uppercase"
                      >
                        Del
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>
      </main>

      {/* Right Sidebar - Entity Info */}
      <aside className="w-[280px] border-l border-line p-6 hidden xl:flex flex-col gap-6 shrink-0 bg-black/2 overflow-y-auto">
        <div>
          <div className="font-mono text-[10px] uppercase opacity-60 mb-2">Entity Mapping Preview</div>
          <div className="inline-block bg-accent text-white text-[9px] px-1.5 py-0.5 rounded-sm mb-2 font-bold uppercase tracking-tight">@Entity: Student</div>
          <div className="bg-[#1e1e1e] text-[#d4d4d4] p-4 rounded border border-line font-mono text-[11px] leading-tight overflow-x-auto">
            {`@Table(name = "students")
public class Student {
  @Id
  @GeneratedValue
  private Long id;

  @Column(name = "full_name")
  private String name;

  @Column(unique = true)
  private String email;

  private Double gpa;
}`}
          </div>
        </div>

        <div className="mt-4">
          <div className="font-mono text-[10px] uppercase opacity-60 mb-3 italic">Recent SQL Operations</div>
          <ul className="space-y-4 font-mono text-[11px]">
            <li className="flex gap-2">
              <span className="text-blue-700 font-bold">[READ]</span>
              <span>FETCHED {students.length} ROWS</span>
            </li>
            <li className="flex gap-2">
              <span className="text-green-700 font-bold">[SCHEMA]</span>
              <span>VERIFIED AUTOINCREMENT</span>
            </li>
            <li className="flex gap-2">
              <span className="text-orange-700 font-bold">[STATUS]</span>
              <span>SQLITE_TRANSACTION:COMMIT</span>
            </li>
          </ul>
        </div>
      </aside>

      {/* Modal - Themed */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-ink/30 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="relative bg-bg border border-line shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="px-6 py-4 border-b border-line flex justify-between items-center bg-black/5">
                <h2 className="font-serif italic text-lg">
                  {editingStudent ? "Edit Student Entry" : "Register New Entity"}
                </h2>
                <button onClick={() => setShowModal(false)} className="hover:rotate-90 transition-transform">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-5 font-mono">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] uppercase font-bold opacity-60 mb-1">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-transparent border border-line px-3 py-2 text-xs focus:bg-white outline-none"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold opacity-60 mb-1">Institutional Email</label>
                    <input 
                      required
                      type="email" 
                      className="w-full bg-transparent border border-line px-3 py-2 text-xs focus:bg-white outline-none"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase font-bold opacity-60 mb-1">Major Code</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-transparent border border-line px-3 py-2 text-xs focus:bg-white outline-none"
                        value={formData.major}
                        onChange={(e) => setFormData({...formData, major: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase font-bold opacity-60 mb-1">GPA_VAL</label>
                      <input 
                        required
                        type="number" 
                        step="0.01"
                        min="0"
                        max="4"
                        className="w-full bg-transparent border border-line px-3 py-2 text-xs focus:bg-white outline-none"
                        value={formData.gpa}
                        onChange={(e) => setFormData({...formData, gpa: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold opacity-60 mb-1">Enrolled_At</label>
                    <input 
                      required
                      type="date" 
                      className="w-full bg-transparent border border-line px-3 py-2 text-xs focus:bg-white outline-none"
                      value={formData.enrollment_date}
                      onChange={(e) => setFormData({...formData, enrollment_date: e.target.value})}
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setShowModal(false)}
                    className="flex-1 btn-minimal"
                  >
                    ABORT
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 btn-minimal btn-minimal-primary"
                  >
                    COMMIT_DATA
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
