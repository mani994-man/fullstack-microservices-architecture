export interface Student {
  id?: number;
  name: string;
  email: string;
  major: string;
  gpa: number;
  enrollment_date: string;
}
