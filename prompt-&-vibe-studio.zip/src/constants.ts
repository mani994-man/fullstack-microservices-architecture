export interface Template {
  id: string;
  name: string;
  concept: string;
  defaultPrompt: string;
}

export const TEMPLATES: Template[] = [
  {
    id: 'cloud-config',
    name: 'Cloud Infrastructure',
    concept: 'Cloud Template',
    defaultPrompt: 'Generate a Terraform configuration for a secure AWS EKS cluster with managed node groups and a VPC across 3 availability zones.'
  },
  {
    id: 'business-logic',
    name: 'Business Application Logic',
    concept: 'Business Logic',
    defaultPrompt: 'Create a TypeScript service for processing e-commerce orders, including inventory checks, payment processing integration, and email notification logic.'
  },
  {
    id: 'code-snippet',
    name: 'Optimized Algorithm',
    concept: 'Code Snippet',
    defaultPrompt: 'Write a highly efficient, production-ready implementation of a Trie data structure for fast prefix searching in a large dictionary of strings.'
  },
  {
    id: 'prompt-optimizer',
    name: 'Prompt Engineering Meta',
    concept: 'Prompt Optimization',
    defaultPrompt: 'Evaluate this prompt: "write a python script for scraping" and optimize it using CoT (Chain of Thought), Few-Shot, and Role-Based techniques.'
  }
];
