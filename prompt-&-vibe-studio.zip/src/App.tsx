import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, 
  Cpu, 
  Zap, 
  Sparkles, 
  Send, 
  Layers, 
  CheckCircle2, 
  AlertCircle,
  Copy,
  RotateCcw,
  Settings2,
  Trash2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { cn } from './lib/utils';
import { TEMPLATES, Template } from './constants';
import { generateStudioResponse, VibeType, PromptParams } from './services/geminiService';

export default function App() {
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [prompt, setPrompt] = useState('');
  const [vibe, setVibe] = useState<VibeType>('Professional');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleTemplateSelect = (template: Template) => {
    setSelectedTemplate(template);
    setPrompt(template.defaultPrompt);
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const result = await generateStudioResponse({
        prompt,
        vibe,
        concept: selectedTemplate?.concept || 'Custom Prompt',
      });
      setOutput(result);
    } catch (error) {
      setOutput(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-bg text-ink font-sans overflow-hidden">
      {/* Top Header */}
      <header className="px-10 py-5 flex justify-between items-center bg-bg relative z-20">
        <div className="font-mono text-sm text-accent tracking-tighter">TASK_23 // AI_ENGINEERING</div>
        <div className="text-[10px] uppercase tracking-[0.2em] opacity-80">Prompt Studio v1.02</div>
      </header>

      {/* Main Grid */}
      <main className="flex-1 grid grid-cols-[80px_1fr_340px] border-t border-grey overflow-hidden relative z-10">
        {/* Left Sidebar (Action Column) */}
        <aside className="border-r border-grey flex flex-col items-center py-5">
          <div className="w-1 h-1 bg-accent mb-1" />
          <div className="w-1 h-1 bg-grey mb-10" />
          <div className="sidebar-label">PROMPT ENGINE // VIBE CORE</div>
        </aside>

        {/* Content Area */}
        <section className="flex flex-col p-10 overflow-y-auto relative border-r border-grey bg-bg">
          <h1 className="hero-text mb-5">
            VIBE<br />
            <span className="text-accent">CODING</span>
          </h1>

          <div className="sub-header mb-12">
            <span className="font-light">{selectedTemplate?.name || 'Manual Prompt Integration'}</span>
            <span className="text-[10px] font-mono opacity-50 uppercase tracking-widest">
              Prompt Level: {vibe}
            </span>
          </div>

          <div className="flex flex-col gap-8 flex-1">
            {/* Input Box */}
            <div className="flex flex-col gap-2">
              <div className="tag self-start">Prompt Input</div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter logic requirements..."
                className="w-full h-48 bg-surface border border-grey p-6 font-mono text-sm focus:outline-none focus:border-accent transition-all resize-none overflow-y-auto"
              />
            </div>

            {/* Output Box */}
            <div className="flex flex-col gap-2 flex-grow min-h-[300px]">
              <div className="flex justify-between items-center">
                <div className="tag">System Output</div>
                {output && (
                  <button onClick={handleCopy} className="text-[10px] font-mono text-accent hover:underline cursor-pointer">
                    COPY_BUFFER
                  </button>
                )}
              </div>
              <div className="flex-1 bg-surface border border-grey p-8 font-mono relative overflow-auto">
                {isLoading ? (
                  <div className="flex items-center gap-2 text-accent animate-pulse font-mono py-4">
                    <RotateCcw className="animate-spin" size={14} />
                    INFERENCE_IN_PROGRESS...
                  </div>
                ) : output ? (
                  <div className="prose prose-invert prose-sm max-w-none">
                    <ReactMarkdown
                      components={{
                        code({ node, inline, className, children, ...props }: any) {
                          const match = /language-(\w+)/.exec(className || '');
                          return !inline && match ? (
                            <SyntaxHighlighter
                              style={{ ...vscDarkPlus, 'pre[class*="language-"]': { ...vscDarkPlus['pre[class*="language-"]'], background: 'transparent', padding: 0, margin: 0 } }}
                              language={match[1]}
                              PreTag="div"
                              {...props}
                            >
                              {String(children).replace(/\n$/, '')}
                            </SyntaxHighlighter>
                          ) : (
                            <code className={cn("bg-bg px-1 rounded text-accent", className)} {...props}>
                              {children}
                            </code>
                          );
                        },
                      }}
                    >
                      {output}
                    </ReactMarkdown>
                  </div>
                ) : (
                  <div className="text-grey uppercase tracking-widest text-[10px] flex flex-col items-center justify-center h-full gap-4">
                    <Cpu size={32} />
                    Awaiting System Trigger
                  </div>
                )}
                {output && !isLoading && (
                  <div className="mt-8 pt-8 border-t border-grey/30">
                     <div className="text-accent font-mono text-[9px] mb-4">ENGINEERING_AUDIT: VALIDATED</div>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="border border-grey p-3">
                           <div className="text-[10px] text-grey uppercase tracking-wide">Efficiency</div>
                           <div className="text-xl font-bold">98.4%</div>
                        </div>
                        <div className="border border-grey p-3">
                           <div className="text-[10px] text-grey uppercase tracking-wide">Readiness</div>
                           <div className="text-xl font-bold">A+</div>
                        </div>
                     </div>
                  </div>
                )}
                <div className="absolute bottom-4 right-4 text-[9px] font-mono text-grey">
                  SYSTEM_STATUS: {isLoading ? 'BUSY' : 'IDLE'}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Sidebar (Stats & Config) */}
        <aside className="bg-stats-bg flex flex-col overflow-y-auto">
          {/* Templates Section */}
          <div className="p-8 border-b border-grey">
             <div className="text-[10px] font-mono text-grey uppercase tracking-[0.2em] mb-6">Template_Library</div>
             <div className="flex flex-col gap-2">
                {TEMPLATES.map(t => (
                  <button
                    key={t.id}
                    onClick={() => handleTemplateSelect(t)}
                    className={cn(
                      "text-left p-4 border transition-all uppercase text-[11px] font-bold tracking-tight",
                      selectedTemplate?.id === t.id 
                        ? "bg-accent text-bg border-accent" 
                        : "border-grey text-ink/60 hover:border-ink hover:text-ink"
                    )}
                  >
                    {t.name}
                  </button>
                ))}
             </div>
          </div>

          {/* Vibe Config */}
          <div className="p-8 border-b border-grey">
             <div className="text-[10px] font-mono text-grey uppercase tracking-[0.2em] mb-6">Mode_Shift</div>
             <div className="grid grid-cols-2 gap-2">
                {(['Technical', 'Creative', 'Professional', 'Minimalist'] as VibeType[]).map(v => (
                  <button
                    key={v}
                    onClick={() => setVibe(v)}
                    className={cn(
                      "p-3 border text-[10px] font-mono transition-all",
                      vibe === v ? "bg-ink text-bg border-ink" : "border-grey text-grey hover:text-ink hover:border-ink"
                    )}
                  >
                    {v}
                  </button>
                ))}
             </div>
          </div>

          {/* Action Button */}
          <button 
            onClick={handleGenerate}
            disabled={isLoading}
            className="btn-primary-bold mt-auto sticky bottom-0"
          >
            {isLoading ? 'Processing...' : 'Execute Task'}
          </button>
        </aside>
      </main>
    </div>
  );
}

