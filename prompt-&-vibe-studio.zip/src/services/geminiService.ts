import { GoogleGenAI } from "@google/genai";

let genAI: GoogleGenAI | null = null;

export function getGenAI() {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please configure it in your environment.");
    }
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
}

export type VibeType = 'Technical' | 'Creative' | 'Professional' | 'Minimalist';

export interface PromptParams {
  prompt: string;
  vibe: VibeType;
  concept: string; // e.g., "Cloud Template", "Code Snippet", "Business Logic"
  systemInstruction?: string;
}

export async function generateStudioResponse(params: PromptParams) {
  const ai = getGenAI();
  
  const systemInstruction = params.systemInstruction || `
    You are an expert software engineer and prompt engineer. 
    Your goal is to generate high-quality, professional outputs for business applications.
    The current "vibe" of the output should be: ${params.vibe}.
    The user is asking for: ${params.concept}.
    
    Guidance for Vibe:
    - Technical: Precise, detailed, includes documentation and comments.
    - Creative: Innovative, explores alternative solutions, use evocative language.
    - Professional: Concise, clear, production-ready, follows industry standards.
    - Minimalist: Simple, efficient, no boilerplate, extremely focused.
    
    Always format your output using Markdown. Use code blocks for any code or configurations.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: params.prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: params.vibe === 'Creative' ? 0.9 : 0.2,
      },
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    throw error;
  }
}
