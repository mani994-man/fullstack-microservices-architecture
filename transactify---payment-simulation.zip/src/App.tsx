/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  RotateCcw, 
  ArrowRightLeft, 
  User, 
  Store, 
  History, 
  AlertCircle, 
  CheckCircle2, 
  Loader2,
  Terminal,
  Activity,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types & Constants ---

type TransactionStatus = 'idle' | 'checking_balance' | 'debiting_account' | 'crediting_merchant' | 'committing' | 'rolling_back' | 'completed' | 'failed';

interface TransactionStep {
  id: TransactionStatus;
  label: string;
  description: string;
}

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'warning' | 'protocol';
}

const TRANSACTION_STEPS: TransactionStep[] = [
  { id: 'checking_balance', label: 'Balance Check', description: 'Verifying sufficient funds in user account...' },
  { id: 'debiting_account', label: 'Debit Account', description: 'Deducting amount from user (Pending State)...' },
  { id: 'crediting_merchant', label: 'Credit Merchant', description: 'Adding amount to merchant (Pending State)...' },
  { id: 'committing', label: 'Commit Transaction', description: 'Finalizing changes and making them persistent...' },
  { id: 'rolling_back', label: 'Rollback', description: 'Reverting all changes due to a system failure...' },
];

const INITIAL_USER_BALANCE = 4240.50;
const INITIAL_MERCHANT_BALANCE = 128492.00;

// --- Components ---

interface StatusIndicatorProps {
  status: TransactionStatus;
  current: TransactionStatus;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ status, current }) => {
  const isPast = TRANSACTION_STEPS.findIndex(s => s.id === status) < TRANSACTION_STEPS.findIndex(s => s.id === current);
  const isActive = status === current;
  const isFailed = current === 'failed' && status === 'rolling_back';
  const isCompleted = current === 'completed' && status === 'committing';

  let colorClass = "bg-zinc-50 text-zinc-400 border-zinc-200 opacity-60";
  if (isActive) colorClass = "bg-primary/5 text-primary border-primary/30 shadow-sm opacity-100 ring-1 ring-primary/20 scale-[1.02] z-10";
  if (isPast || isCompleted) colorClass = "bg-emerald-50 text-success border-success/30 opacity-100 shadow-sm";
  if (isFailed) colorClass = "bg-accent/5 text-accent border-accent/30 opacity-100 shadow-sm";

  return (
    <div className={`flex items-center gap-4 p-3.5 rounded-xl border transition-all duration-500 transform-gpu ${colorClass}`}>
      <div className="w-8 h-8 flex items-center justify-center shrink-0 rounded-full bg-white/50 border border-inherit shadow-inner">
        {(isPast || isCompleted) ? <CheckCircle2 size={18} /> : 
         isActive ? <Loader2 size={18} className="animate-spin text-primary" /> : 
         isFailed ? <RotateCcw size={18} className="text-accent" /> :
         <div className="w-1.5 h-1.5 rounded-full bg-zinc-300" />}
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-bold uppercase tracking-wider">{labelForStatus(status)}</p>
          {isActive && <span className="text-[9px] font-bold bg-primary text-white px-1.5 py-0.5 rounded uppercase tracking-tighter animate-pulse">Active</span>}
        </div>
        <p className="text-[10px] opacity-80 leading-tight mt-0.5">{descriptionForStatus(status)}</p>
      </div>
    </div>
  );
};

const labelForStatus = (status: string) => TRANSACTION_STEPS.find(s => s.id === status)?.label || status;
const descriptionForStatus = (status: string) => TRANSACTION_STEPS.find(s => s.id === status)?.description || "";

export default function App() {
  const [userBalance, setUserBalance] = useState(INITIAL_USER_BALANCE);
  const [merchantBalance, setMerchantBalance] = useState(INITIAL_MERCHANT_BALANCE);
  const [status, setStatus] = useState<TransactionStatus>('idle');
  const [amount, setAmount] = useState<string>("450.00");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [failureRate, setFailureRate] = useState<number>(0.3);
  const logEndRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((message: string, type: LogEntry['type'] = 'info') => {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    setLogs(prev => [...prev, { id: Math.random().toString(36), timestamp, message, type }]);
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const runPayment = async (forceFail = false) => {
    if (status !== 'idle' && status !== 'completed' && status !== 'failed') return;
    
    const payAmount = parseFloat(amount);
    if (isNaN(payAmount) || payAmount <= 0) {
      addLog("Invalid amount requested.", "error");
      return;
    }

    setLogs([]);
    addLog("START TRANSACTION", "protocol");
    
    // Step 1: Balance Check
    setStatus('checking_balance');
    addLog(`Checking balance for USR_01...`, "info");
    await new Promise(r => setTimeout(r, 600));
    
    if (userBalance < payAmount) {
      addLog("ROLLBACK: Insufficient funds in source account.", "error");
      setStatus('failed');
      return;
    }
    
    addLog(`Verification: Balance sufficient. New balance: $${(userBalance - payAmount).toFixed(2)}.`, "info");

    // Step 2: Debit (Pending)
    setStatus('debiting_account');
    addLog(`UPDATE accounts SET balance = balance - ${payAmount.toFixed(2)} WHERE id = 'USR_01';`, "info");
    await new Promise(r => setTimeout(r, 800));

    // Simulation of possible failure point
    const shouldFail = forceFail || Math.random() < failureRate;

    // Step 3: Credit (Pending)
    if (!shouldFail) {
      setStatus('crediting_merchant');
      addLog(`UPDATE merchants SET balance = balance + ${payAmount.toFixed(2)} WHERE id = 'MID_99';`, "info");
      await new Promise(r => setTimeout(r, 800));
      
      addLog("Awaiting final validation...", "warning");
      await new Promise(r => setTimeout(r, 600));

      // Step 4: Final Commit
      setStatus('committing');
      addLog("COMMIT TRANSACTION - Finalizing changes...", "protocol");
      await new Promise(r => setTimeout(r, 800));
      
      // Persist changes
      setUserBalance(prev => prev - payAmount);
      setMerchantBalance(prev => prev + payAmount);
      
      setStatus('completed');
      addLog("TRANSACTION SUCCESSFUL. Ledger updated.", "success");
    } else {
      // Step 5: Rollback due to failure
      addLog("SYSTEM_ERROR: Database deadlock detected.", "error");
      setStatus('rolling_back');
      addLog("Initiating ROLLBACK protocol...", "warning");
      await new Promise(r => setTimeout(r, 1200));
      
      addLog("ROLLBACK COMPLETE. Data integrity preserved. No funds were moved.", "success");
      setStatus('failed');
    }
  };

  return (
    <div className="min-h-screen bg-bg-light text-zinc-900 font-sans flex flex-col">
      {/* Header */}
      <header className="h-16 bg-primary text-white flex items-center justify-between px-6 shadow-[0_2px_4px_rgba(0,0,0,0.1)] z-10 shrink-0">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <span className="text-primary-light">◈</span> SWIFTPAY TRANSACTION ENGINE <span className="opacity-50 text-sm ml-1">v2.4</span>
        </div>
        <div className="text-sm opacity-80 font-medium">
          Operator: charan_session_772
        </div>
      </header>

      <main className="grid grid-cols-[280px_1fr] flex-1 gap-6 p-6 overflow-hidden">
        
        {/* Sidebar */}
        <aside className="bg-card-light rounded-xl border border-border-light p-5 flex flex-col gap-6 shadow-sm overflow-auto">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 mb-4">Account States</h3>
            
            <div className="space-y-3">
              <div className="p-4 bg-zinc-50 rounded-lg border-l-4 border-primary shadow-sm hover:translate-x-1 transition-transform">
                <div className="text-sm font-semibold text-zinc-800">User: Sarah Jenkins</div>
                <div className="text-lg font-mono text-success mt-1">
                  ${userBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>

              <div className="p-4 bg-zinc-50 rounded-lg border-l-4 border-accent shadow-sm hover:translate-x-1 transition-transform">
                <div className="text-sm font-semibold text-zinc-800">Merchant: Global Retail Inc.</div>
                <div className="text-lg font-mono text-success mt-1">
                  ${merchantBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 mb-4">System Health</h3>
            <div className="text-xs space-y-2 leading-relaxed font-medium">
              <div className="flex justify-between">
                <span>Database:</span>
                <span className="text-success font-bold">CONNECTED</span>
              </div>
              <div className="flex justify-between">
                <span>ACID Compliance:</span>
                <span className="text-success font-bold">ACTIVE</span>
              </div>
              <div className="flex justify-between">
                <span>Latency:</span>
                <span className="text-zinc-600">14ms</span>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-4 border-t border-border-light flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-success shadow-[0_0_8px_rgba(46,125,50,0.4)]" />
            <span className="text-xs font-semibold text-zinc-600 uppercase tracking-tighter">Transaction Controller Ready</span>
          </div>
        </aside>

        {/* Content Area */}
        <section className="grid grid-rows-[auto_1fr] gap-6 overflow-hidden">
          
          {/* Initiation Card */}
          <div className="bg-card-light rounded-xl border border-border-light p-8 flex flex-col gap-6 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Initiate Simulation</h3>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-zinc-700">Transfer Amount ($)</label>
                <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  disabled={status !== 'idle' && status !== 'completed' && status !== 'failed'}
                  className="w-full p-3 border border-zinc-300 rounded-md bg-zinc-50 font-medium focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all disabled:opacity-50"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-zinc-700">Simulation Config</label>
                <div className="flex items-center gap-4 h-[46px] px-3 bg-zinc-50 border border-zinc-300 rounded-md">
                   <span className="text-xs font-bold text-zinc-500 uppercase">Failure Risk:</span>
                   <input 
                    type="range" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    value={failureRate}
                    onChange={(e) => setFailureRate(parseFloat(e.target.value))}
                    className="flex-1 accent-primary h-1 bg-zinc-300 rounded-full cursor-pointer"
                   />
                   <span className="text-xs font-mono font-bold w-8">{(failureRate * 100).toFixed(0)}%</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => runPayment(false)}
                disabled={status !== 'idle' && status !== 'completed' && status !== 'failed'}
                className="btn-primary py-3.5 rounded-md font-bold text-sm tracking-wide shadow-md active:scale-[0.98] transition-all disabled:grayscale disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                {status !== 'idle' && status !== 'completed' && status !== 'failed' ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : <ArrowRightLeft size={16} />}
                EXECUTE TRANSACTION (COMMIT SUCCESS)
              </button>
              
              <button 
                onClick={() => runPayment(true)}
                disabled={status !== 'idle' && status !== 'completed' && status !== 'failed'}
                className="bg-secondary hover:bg-zinc-200 text-zinc-700 border border-zinc-300 py-3.5 rounded-md font-bold text-sm tracking-wide shadow-sm active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw size={16} />
                SIMULATE SYSTEM FAILURE (ROLLBACK)
              </button>
            </div>
          </div>

          {/* Ledger / Logs */}
          <div className="bg-log-bg rounded-xl text-log-text p-6 font-mono text-[13px] leading-relaxed flex flex-col shadow-2xl relative border border-log-border">
            <div className="flex justify-between items-center border-b border-log-border pb-3 mb-4 shrink-0">
               <div className="flex items-center gap-2">
                 <Terminal size={14} className="text-zinc-500" />
                 <span className="text-white font-bold tracking-tight">TRANSACTION LEDGER LOG</span>
               </div>
               <span className="text-[11px] opacity-60">TXN_ID: {status === 'idle' ? 'AWAITING' : '8829-AF'}</span>
            </div>

            <div className="flex-1 overflow-auto space-y-1.5 custom-scrollbar">
              {logs.length === 0 && (
                <div className="opacity-40 italic">-- System idle. Awaiting command --</div>
              )}
              {logs.map((log) => (
                <div key={log.id} className="flex gap-4">
                  <span className="text-zinc-500 shrink-0">[{log.timestamp}]</span>
                  <span className={`
                    ${log.type === 'error' ? 'text-rose-400' : ''}
                    ${log.type === 'success' ? 'text-emerald-400' : ''}
                    ${log.type === 'warning' ? 'text-amber-400' : ''}
                    ${log.type === 'protocol' ? 'text-primary-light font-bold' : ''}
                  `}>
                    {log.message}
                    {log.type === 'success' && log.message.includes('SUCCESS') && (
                      <span className="ml-2 inline-block px-1.5 bg-success/20 text-success text-[10px] rounded border border-success/30 font-bold uppercase">OK</span>
                    )}
                    {log.type === 'warning' && log.message.includes('Awaiting') && (
                        <span className="ml-2 inline-block px-1.5 bg-accent/20 text-accent text-[10px] rounded border border-accent/30 font-bold uppercase">PENDING</span>
                    )}
                  </span>
                </div>
              ))}
              <AnimatePresence>
                {(status !== 'idle' && status !== 'completed' && status !== 'failed') && (
                  <motion.div 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }} 
                    className="mt-2 text-primary-light flex items-center gap-2"
                  >
                    <span>PROCESSING PROTOCOL...</span>
                    <span className="inline-block w-2.5 h-4 bg-primary-light animate-pulse" />
                  </motion.div>
                )}
              </AnimatePresence>
              <div ref={logEndRef} />
            </div>
          </div>
        </section>
      </main>

      <style>{`
        .btn-primary {
          background-color: var(--color-primary);
          color: white;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #37474F;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #455A64;
        }
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 14px;
          height: 14px;
          background: var(--color-primary);
          border-radius: 60%;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}
