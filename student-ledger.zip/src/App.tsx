import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { StudentTable } from './components/StudentTable';
import { Footer } from './components/Footer';
import { Student, PaginatedResult } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [department, setDepartment] = useState<string | null>(null);

  useEffect(() => {
    fetchStudents();
  }, [page, department]);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        size: '15',
      });
      if (department) params.append('department', department);
      
      const response = await fetch(`/api/students?${params.toString()}`);
      const data: PaginatedResult<Student> = await response.json();
      
      setStudents(data.content);
      setTotalPages(data.totalPages);
      setTotalElements(data.totalElements);
    } catch (error) {
      console.error('Failed to fetch students:', error);
    } finally {
      // Simulate slight delay for "repository authenticity"
      setTimeout(() => setLoading(false), 400);
    }
  };

  const handleDeptChange = (dept: string | null) => {
    setDepartment(dept);
    setPage(0);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-bg text-text-main font-sans overflow-hidden">
      <Header />
      
      <main className="flex-1 grid grid-cols-[280px_1fr] overflow-hidden">
        <Sidebar selectedDept={department} onSelectDept={handleDeptChange} />
        
        <section className="p-10 flex flex-col gap-6 overflow-hidden">
          <div className="flex justify-between items-end border-b border-border pb-4">
            <div className="title-group">
              <h1 className="font-serif text-4xl font-normal leading-tight">Student Records</h1>
              <p className="text-xs text-text-dim mt-1">
                Displaying records filtered by <i>{department || 'All Departments'}</i>
              </p>
            </div>
            <div className="text-[11px] text-text-dim flex items-center gap-4">
              <div className="flex items-center gap-2">
                <button 
                  disabled={page === 0} 
                  onClick={() => setPage(p => p - 1)}
                  className="hover:text-text-main disabled:opacity-30 disabled:hover:text-text-dim px-2 py-1"
                >
                  PREV
                </button>
                <span>PAGE <b className="text-text-main font-mono">{(page + 1).toString().padStart(2, '0')}</b> OF <b className="text-text-main font-mono">{totalPages.toString().padStart(2, '0')}</b></span>
                <button 
                  disabled={page >= totalPages - 1} 
                  onClick={() => setPage(p => p + 1)}
                  className="hover:text-text-main disabled:opacity-30 disabled:hover:text-text-dim px-2 py-1"
                >
                  NEXT
                </button>
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={`${page}-${department}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="flex-1 overflow-hidden flex flex-col"
            >
              <StudentTable students={students} loading={loading} />
            </motion.div>
          </AnimatePresence>
        </section>
      </main>

      <Footer totalRecords={totalElements} />
    </div>
  );
}
