import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="h-20 px-10 flex items-center justify-between border-bottom border-border bg-surface shrink-0">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 border border-accent flex items-center justify-center font-serif text-accent font-bold">
          S
        </div>
        <span className="font-serif text-xl tracking-wider italic">Student Ledger</span>
      </div>
      <div className="font-mono text-[11px] text-accent bg-accent/10 px-3 py-1 rounded">
        @Repository StudentRepository
      </div>
    </header>
  );
};
