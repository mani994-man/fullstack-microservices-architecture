import React from 'react';
import { Student } from '../types';

interface StudentTableProps {
  students: Student[];
  loading: boolean;
}

export const StudentTable: React.FC<StudentTableProps> = ({ students, loading }) => {
  return (
    <div className="bg-surface border border-border rounded flex-1 overflow-auto">
      <table className="w-full border-collapse text-sm">
        <thead className="sticky top-0 bg-surface">
          <tr>
            <th className="text-left py-4 px-6 border-b border-border font-serif italic text-accent font-normal">ID</th>
            <th className="text-left py-4 px-6 border-b border-border font-serif italic text-accent font-normal">Full Name</th>
            <th className="text-left py-4 px-6 border-b border-border font-serif italic text-accent font-normal">Department</th>
            <th className="text-left py-4 px-6 border-b border-border font-serif italic text-accent font-normal">Age</th>
            <th className="text-left py-4 px-6 border-b border-border font-serif italic text-accent font-normal">Enrollment Date</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {loading ? (
            <tr>
              <td colSpan={5} className="py-20 text-center text-text-dim animate-pulse">
                Fetching records from repository...
              </td>
            </tr>
          ) : students.length === 0 ? (
            <tr>
              <td colSpan={5} className="py-20 text-center text-text-dim italic">
                No records found for current query.
              </td>
            </tr>
          ) : (
            students.map((student) => (
              <tr key={student.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-4 px-6 text-text-dim font-mono text-[13px]">{student.id}</td>
                <td className="py-4 px-6 text-text-main flex items-center">
                  <span className="status-dot"></span>
                  {student.fullName}
                </td>
                <td className="py-4 px-6 text-text-dim">{student.department}</td>
                <td className="py-4 px-6 text-text-dim">{student.age}</td>
                <td className="py-4 px-6 text-text-dim">{student.enrollmentDate}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};
