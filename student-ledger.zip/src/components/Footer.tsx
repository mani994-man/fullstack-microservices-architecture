import React from 'react';

interface FooterProps {
  totalRecords: number;
}

export const Footer: React.FC<FooterProps> = ({ totalRecords }) => {
  return (
    <footer className="h-[60px] bg-surface border-t border-border flex items-center px-10 gap-8 text-[11px] text-text-dim shrink-0">
      <div className="stat-item flex items-center">
        TOTAL RECORDS: <b className="text-text-main font-mono ml-1">{totalRecords.toLocaleString()}</b>
      </div>
      <div className="stat-item flex items-center">
        PAGE SIZE: <b className="text-text-main font-mono ml-1">15</b>
      </div>
      <div className="stat-item flex items-center">
        JPA DIALECT: <b className="text-text-main font-mono ml-1">PostgreSQL 14</b>
      </div>
      <div className="flex-1"></div>
      <div className="stat-item flex items-center">
        PERSISTENCE CONTEXT: <b className="text-text-main font-mono ml-1 uppercase">Active</b>
      </div>
    </footer>
  );
};
