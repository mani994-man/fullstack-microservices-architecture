import React from 'react';

interface SidebarProps {
  selectedDept: string | null;
  onSelectDept: (dept: string | null) => void;
}

const DEPARTMENTS = ['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Physics', 'Mathematics', 'Biology'];

export const Sidebar: React.FC<SidebarProps> = ({ selectedDept, onSelectDept }) => {
  return (
    <aside className="border-r border-border p-8 flex flex-col gap-10 overflow-y-auto">
      <div>
        <span className="aside-label">Custom Query Methods</span>
        <button 
          onClick={() => onSelectDept(DEPARTMENTS[0])}
          className={`w-full text-left query-method ${selectedDept === DEPARTMENTS[0] ? 'active' : ''}`}
        >
          findByDepartment(String dept, Pageable p)
        </button>
        <div className="query-method">findByAgeGreaterThan(int age, Sort s)</div>
        <div className="query-method">findByGpaDesc(Pageable p)</div>
        <div className="query-method">findActiveStudents(boolean status)</div>
      </div>
      
      <div>
        <span className="aside-label">Active Filters</span>
        <div className="flex flex-col gap-2">
          {selectedDept && (
            <div className="pill self-start flex items-center gap-2">
              Dept: {selectedDept}
              <button onClick={() => onSelectDept(null)} className="hover:text-white">×</button>
            </div>
          )}
          <div className="pill self-start">Sort: ID ASC</div>
        </div>
      </div>

      <div>
        <span className="aside-label">Department Selection</span>
        <div className="flex flex-col gap-1">
          {DEPARTMENTS.map(dept => (
            <button
              key={dept}
              onClick={() => onSelectDept(dept)}
              className={`text-left text-[11px] py-1 transition-colors ${selectedDept === dept ? 'text-accent' : 'text-text-dim hover:text-text-main'}`}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
};
