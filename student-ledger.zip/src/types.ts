export interface Student {
  id: string;
  fullName: string;
  department: string;
  age: number;
  enrollmentDate: string;
  status: 'active' | 'inactive';
}

export interface PaginatedResult<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  page: number;
  size: number;
}
