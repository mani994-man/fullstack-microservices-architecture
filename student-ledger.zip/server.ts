import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { Student, PaginatedResult } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Mock Data
const DEPARTMENTS = ['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Physics', 'Mathematics', 'Biology'];
const NAMES = ['Alexander Thorne', 'Elena Rodriguez', 'Marcus Vane', 'Sarah Jenkins', 'Julian Ross', 'Isabella Chen', 'David Miller', 'Sophie Taylor', 'Lucas Brown', 'Emma Wilson'];

const MOCK_STUDENTS: Student[] = Array.from({ length: 1248 }, (_, i) => ({
  id: `#${88210 + i}`,
  fullName: NAMES[i % NAMES.length],
  department: DEPARTMENTS[i % DEPARTMENTS.length],
  age: 18 + Math.floor(Math.random() * 10),
  enrollmentDate: new Date(2020 + Math.floor(Math.random() * 4), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28)).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
  status: Math.random() > 0.1 ? 'active' : 'inactive',
}));

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/students', (req, res) => {
    const page = parseInt(req.query.page as string) || 0;
    const size = parseInt(req.query.size as string) || 15;
    const department = req.query.department as string;
    const minAge = parseInt(req.query.minAge as string) || 0;
    const sortField = (req.query.sort as string)?.split(',')[0] || 'id';
    const sortDir = (req.query.sort as string)?.split(',')[1] === 'desc' ? -1 : 1;

    let filtered = [...MOCK_STUDENTS];

    if (department) {
      filtered = filtered.filter(s => s.department === department);
    }

    if (minAge) {
      filtered = filtered.filter(s => s.age >= minAge);
    }

    // Sort
    filtered.sort((a, b) => {
      const valA = (a as any)[sortField];
      const valB = (b as any)[sortField];
      if (valA < valB) return -1 * sortDir;
      if (valA > valB) return 1 * sortDir;
      return 0;
    });

    const totalElements = filtered.length;
    const totalPages = Math.ceil(totalElements / size);
    const content = filtered.slice(page * size, (page + 1) * size);

    const result: PaginatedResult<Student> = {
      content,
      totalElements,
      totalPages,
      page,
      size,
    };

    res.json(result);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
