import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Configuration for microservices and their instances
  const services = {
    'auth-service': [
      { id: 'auth-1', url: 'simulated://auth-1', weight: 1 },
      { id: 'auth-2', url: 'simulated://auth-2', weight: 1 },
    ],
    'order-service': [
      { id: 'order-1', url: 'simulated://order-1', weight: 1 },
      { id: 'order-2', url: 'simulated://order-2', weight: 1 },
      { id: 'order-3', url: 'simulated://order-3', weight: 1 },
    ],
    'inventory-service': [
      { id: 'inv-1', url: 'simulated://inv-1', weight: 1 },
    ]
  };

  // State to track Round Robin indices
  const lbIndices: Record<string, number> = {};

  // Initialize indices
  Object.keys(services).forEach(serviceName => {
    lbIndices[serviceName] = 0;
  });

  app.use(express.json());

  // API Gateway Middleware / Route
  app.all('/api/gateway/:serviceName/*', (req, res) => {
    const { serviceName } = req.params;
    const instances = services[serviceName as keyof typeof services];

    if (!instances) {
      return res.status(404).json({
        error: 'Service Not Found',
        gatewayMessage: `The requested service "${serviceName}" is not registered in the gateway.`
      });
    }

    // Load Balancing Logic (Round Robin)
    const index = lbIndices[serviceName];
    const instance = instances[index];
    
    // Update index for next request
    lbIndices[serviceName] = (index + 1) % instances.length;

    // Simulate network delay
    const delay = Math.floor(Math.random() * 200) + 50;

    setTimeout(() => {
      res.json({
        status: 'success',
        processedBy: instance.id,
        instanceUrl: instance.url,
        timestamp: new Date().toISOString(),
        requestPath: req.params[0],
        method: req.method,
        gatewayMetric: {
          latencyMs: delay,
          lbMethod: 'Round Robin',
          instanceIndex: index,
          totalInstances: instances.length
        },
        data: {
          message: `Simulated response from ${serviceName} handled by instance ${instance.id}`
        }
      });
    }, delay);
  });

  // Expose configuration for the UI
  app.get('/api/gateway-config', (req, res) => {
    res.json({
      services,
      lbIndices
    });
  });

  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Gateway running at http://0.0.0.0:${PORT}`);
    console.log(`Routes registered: /api/gateway/:serviceName/*`);
  });
}

startServer();
