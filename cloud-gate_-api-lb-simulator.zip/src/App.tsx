/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Server, 
  Activity, 
  ChevronRight, 
  Cpu, 
  Zap, 
  ShieldCheck, 
  Layers,
  History,
  Info
} from 'lucide-react';

interface Instance {
  id: string;
  url: string;
  weight: number;
}

interface ServiceConfig {
  [name: string]: Instance[];
}

interface LogEntry {
  id: string;
  service: string;
  instance: string;
  latency: number;
  timestamp: string;
  path: string;
}

export default function App() {
  const [config, setConfig] = useState<ServiceConfig | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [activeService, setActiveService] = useState<string | null>(null);
  const logContainerRef = useRef<HTMLDivElement>(null);

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/gateway-config');
      const data = await res.json();
      setConfig(data.services);
      if (!activeService && Object.keys(data.services).length > 0) {
        setActiveService(Object.keys(data.services)[0]);
      }
    } catch (err) {
      console.error('Failed to fetch gateway config', err);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  const triggerRequest = async (serviceName: string) => {
    setLoading(prev => ({ ...prev, [serviceName]: true }));
    try {
      const path = '/v1/resource';
      const res = await fetch(`/api/gateway/${serviceName}${path}`);
      const data = await res.json();

      const newLog: LogEntry = {
        id: Math.random().toString(36).substr(2, 9),
        service: serviceName,
        instance: data.processedBy,
        latency: data.gatewayMetric.latencyMs,
        timestamp: new Date().toLocaleTimeString(),
        path
      };

      setLogs(prev => [...prev.slice(-19), newLog]);
    } catch (err) {
      console.error('Request failed', err);
    } finally {
      setLoading(prev => ({ ...prev, [serviceName]: false }));
    }
  };

  const getInstanceStats = (serviceName: string) => {
    const serviceLogs = logs.filter(l => l.service === serviceName);
    const instances = config?.[serviceName] || [];
    return instances.map(inst => ({
      id: inst.id,
      count: serviceLogs.filter(l => l.instance === inst.id).length,
      total: serviceLogs.length
    }));
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#fafafa] font-sans p-6 selection:bg-blue-500/30">
      <div className="max-w-[1200px] mx-auto space-y-6">
        {/* Header */}
        <header className="flex justify-between items-end pb-2 border-b border-[#27272a]">
          <div>
            <div className="text-[12px] text-[#71717a] font-medium uppercase tracking-[0.05em]">Infrastructure / Cluster-04</div>
            <h1 className="text-2xl font-semibold mt-1 tracking-tight">API Gateway Orchestrator</h1>
          </div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#14532d20] text-[#4ade80] border border-[#4ade8020] rounded-full text-[11px] font-semibold">
            <div className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse" />
            Operational
          </div>
        </header>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 auto-rows-[180px] gap-4">
          
          {/* Throughput Card */}
          <div className="lg:col-span-2 lg:row-span-1 bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col relative group overflow-hidden">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider flex items-center gap-2 mb-3">
              <Activity className="w-3.5 h-3.5 text-blue-500" />
              Real-time Throughput
            </div>
            <div className="flex flex-col flex-1 justify-center">
              <div className="text-5xl font-bold tracking-tighter leading-none">
                {(logs.length * 1.2 + 8.4).toFixed(1)}k
              </div>
              <div className="text-[13px] text-[#71717a] mt-1">Req/Sec — Cluster Local</div>
            </div>
            <div className="mt-auto h-12 flex items-end gap-[3px] opacity-40 group-hover:opacity-100 transition-opacity">
              {[40, 60, 45, 80, 95, 85, 60, 70, 55, 90, 40, 65, 30, 85, 90].map((h, i) => (
                <div 
                  key={i} 
                  className={`flex-1 rounded-sm ${i > 10 ? 'bg-blue-500' : 'bg-[#3f3f46]'}`} 
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
          </div>

          {/* Active Services Card */}
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider mb-2">Active Services</div>
            <div className="text-5xl font-bold tracking-tighter my-auto">
              0{config ? Object.keys(config).length : 0}
            </div>
            <div className="text-[13px] text-[#71717a]">System mesh healthy</div>
          </div>

          {/* Latency Card */}
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider mb-2">Avg Latency</div>
            <div className="text-5xl font-bold tracking-tighter my-auto text-blue-500">
              {logs.length > 0 ? (logs.reduce((acc, l) => acc + l.latency, 0) / logs.length).toFixed(0) : '24'}<span className="text-2xl ml-1 font-medium">ms</span>
            </div>
            <div className="text-[13px] text-[#71717a]">P99: 42ms</div>
          </div>

          {/* Logs Card - Spans 2 Rows */}
          <div className="lg:col-span-1 lg:row-span-2 bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider flex items-center justify-between mb-4">
              <span className="flex items-center gap-2">
                <History className="w-3.5 h-3.5 text-blue-500" />
                Live Packets
              </span>
              <span className="text-[9px] font-mono text-[#71717a]">RT_STREAM</span>
            </div>
            <div 
              ref={logContainerRef}
              className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-[#27272a]"
            >
              {logs.length === 0 && (
                <div className="h-full flex items-center justify-center text-[#71717a] text-[12px] text-center italic px-4">
                  Awaiting node traffic...
                </div>
              )}
              <AnimatePresence initial={false}>
                {[...logs].reverse().map((log) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="pb-3 border-b border-[#27272a] last:border-0"
                  >
                    <div className="flex justify-between items-center text-[12px] mb-1">
                      <span className="text-blue-400 font-mono">/{log.service.split('-')[0]}</span>
                      <span className="text-[#52525b] text-[10px]">{log.timestamp}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[11px] text-[#71717a]">id: {log.instance}</span>
                      <span className="text-[11px] font-bold text-[#fafafa]">{log.latency}ms</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Upstream Services - Multi-column Spanner */}
          <div className="lg:col-span-3 lg:row-span-2 bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider flex items-center gap-2 mb-4">
              <Layers className="w-3.5 h-3.5 text-blue-500" />
              Service Cluster Orchestration
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
              {config && (Object.entries(config) as [string, Instance[]][]).map(([name, instances]) => (
                <div 
                  key={name}
                  onClick={() => setActiveService(name)}
                  className={`p-4 rounded-xl border transition-all duration-300 cursor-pointer ${
                    activeService === name 
                      ? 'bg-blue-500/5 border-blue-500/50' 
                      : 'bg-[#18181b] border-[#27272a] hover:border-[#3f3f46]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold tracking-tight capitalize truncate pr-2">{name.replace('-', ' ')}</h3>
                    {loading[name] ? (
                      <div className="w-3 h-3 border-2 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
                    ) : (
                      <div className="w-1.5 h-1.5 rounded-full bg-[#10b981]" />
                    )}
                  </div>

                  <div className="space-y-2 mb-4">
                    {instances.map((inst, idx) => {
                      const stats = getInstanceStats(name).find(s => s.id === inst.id);
                      const percentage = stats?.total ? (stats.count / stats.total) * 100 : 0;
                      return (
                        <div key={inst.id} className="h-1 bg-[#27272a] rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${percentage || 0}%` }}
                            className="h-full bg-blue-500/50"
                          />
                        </div>
                      );
                    })}
                  </div>

                  <button
                    disabled={loading[name]}
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerRequest(name);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-[#27272a] hover:bg-[#3f3f46] text-[#fafafa] text-[11px] font-semibold rounded-lg transition-colors border border-[#3f3f46]/50"
                  >
                    <Zap className="w-3 h-3 text-blue-500" />
                    Ping Mesh
                  </button>
                </div>
              ))}
            </div>

            {/* Architecture Footer */}
            <div className="mt-4 pt-4 border-t border-[#27272a] flex items-center justify-between text-[11px] text-[#71717a]">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-3 h-3" /> TLS 1.3</span>
                <span className="flex items-center gap-1.5"><Cpu className="w-3 h-3" /> AVX-512</span>
              </div>
              <div className="font-mono uppercase tracking-widest">Protocol: RoundRobin_v4</div>
            </div>
          </div>

          {/* Healthy Instances Card */}
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider mb-2">Healthy Nodes</div>
            <div className="text-5xl font-bold tracking-tighter my-auto text-[#10b981]">
              99.8<span className="text-2xl ml-1 font-medium">%</span>
            </div>
            <div className="text-[13px] text-[#71717a]">12 Up / 0 Pending</div>
          </div>

          {/* Error Rate Card */}
          <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-5 flex flex-col">
            <div className="text-[11px] font-semibold text-[#a1a1aa] uppercase tracking-wider mb-2">Error Rate</div>
            <div className="text-5xl font-bold tracking-tighter my-auto text-[#ef4444]">
              0.02<span className="text-2xl ml-1 font-medium">%</span>
            </div>
            <div className="text-[13px] text-[#71717a]">System integrity optimal</div>
          </div>

        </div>
      </div>
    </div>
  );

}

