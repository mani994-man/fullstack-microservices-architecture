export interface GitCommit {
  id: string;
  hash: string;
  message: string;
  parentId: string | null;
  timestamp: number;
  filesSnapshot: Record<string, string>;
}

export interface GitState {
  commits: GitCommit[];
  workingDirectory: Record<string, string>;
  stagingArea: Set<string>;
  branches: Record<string, string>; // branchName -> commitId
  currentBranch: string;
  head: string; // Current commit ID
}

export type Operation = 
  | { type: 'init' }
  | { type: 'add', file: string }
  | { type: 'commit', message: string }
  | { type: 'branch', name: string }
  | { type: 'checkout', target: string };
