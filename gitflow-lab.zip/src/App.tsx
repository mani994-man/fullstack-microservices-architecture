/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  GitBranch, 
  GitCommit, 
  GitPullRequest, 
  Plus, 
  Trash2, 
  Terminal as TerminalIcon, 
  Folder, 
  File, 
  Play, 
  ChevronRight, 
  Github,
  History,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GitState, GitCommit as GitCommitType } from './types.ts';

// Initial state
const INITIAL_GIT_STATE: GitState = {
  commits: [],
  workingDirectory: {
    'index.html': '<html><body>Hello World</body></html>',
    'styles.css': 'body { background: white; }',
    'main.js': 'console.log("Git is awesome!");'
  },
  stagingArea: new Set(),
  branches: { 'main': '' },
  currentBranch: 'main',
  head: ''
};

export default function App() {
  const [git, setGit] = useState<GitState>(INITIAL_GIT_STATE);
  const [history, setHistory] = useState<string[]>(['Welcome to GitFlow Lab. Type help to see available commands.']);
  const [input, setInput] = useState('');
  const [activeTab, setActiveTab] = useState<'graph' | 'files' | 'remote'>('graph');
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const generateHash = () => Math.random().toString(16).substring(2, 8);

  const executeCommand = (cmdStr: string) => {
    const parts = cmdStr.trim().split(/\s+/);
    const cmd = parts[0]?.toLowerCase();
    const args = parts.slice(1);

    setHistory(prev => [...prev, `> ${cmdStr}`]);

    if (!cmd) return;

    switch (cmd) {
      case 'help':
        setHistory(prev => [...prev, 
          'Available commands:',
          '  git init           Initialize a new git repository',
          '  git add <file>     Stage a file (or "." for all)',
          '  git commit -m "msg" Create a new commit',
          '  git branch <name>   Create a new branch',
          '  git checkout <name> Switch to a branch or commit',
          '  git status         Show working directory status',
          '  git push           Demonstrate remote sync',
          '  clear              Clear terminal',
          '  reset              Reset simulation'
        ]);
        break;

      case 'git':
        const subCmd = args[0]?.toLowerCase();
        if (subCmd === 'init') {
          if (git.commits.length > 0) {
            setHistory(prev => [...prev, 'Error: Repository already initialized.']);
          } else {
            setHistory(prev => [...prev, 'Initialized empty Git repository.']);
            // Technically we already have the state, but we could mark it as "initialized"
          }
        } else if (subCmd === 'add') {
          const file = args[1];
          if (!file) {
            setHistory(prev => [...prev, 'Error: Nothing specified, nothing added.']);
          } else if (file === '.') {
            setGit(prev => ({ ...prev, stagingArea: new Set(Object.keys(prev.workingDirectory)) }));
            setHistory(prev => [...prev, 'Staged all files.']);
          } else if (git.workingDirectory[file] !== undefined) {
            setGit(prev => {
              const newStaging = new Set(prev.stagingArea);
              newStaging.add(file);
              return { ...prev, stagingArea: newStaging };
            });
            setHistory(prev => [...prev, `Staged ${file}.`]);
          } else {
            setHistory(prev => [...prev, `Error: File ${file} not found.`]);
          }
        } else if (subCmd === 'commit') {
          const mIndex = args.indexOf('-m');
          const message = mIndex !== -1 ? args.slice(mIndex + 1).join(' ').replace(/^["']|["']$/g, '') : '';
          
          if (!message) {
            setHistory(prev => [...prev, 'Error: Aborting commit due to empty commit message.']);
          } else if (git.stagingArea.size === 0) {
            setHistory(prev => [...prev, 'On branch ' + git.currentBranch, 'nothing to commit, working tree clean']);
          } else {
            const newCommit: GitCommitType = {
              id: Math.random().toString(36).substr(2, 9),
              hash: generateHash(),
              message,
              parentId: git.head || null,
              timestamp: Date.now(),
              filesSnapshot: { ...git.workingDirectory }
            };

            setGit(prev => ({
              ...prev,
              commits: [...prev.commits, newCommit],
              head: newCommit.id,
              branches: { ...prev.branches, [prev.currentBranch]: newCommit.id },
              stagingArea: new Set()
            }));
            setHistory(prev => [...prev, `[${git.currentBranch} ${newCommit.hash}] ${message}`, ` ${git.stagingArea.size} files changed`]);
          }
        } else if (subCmd === 'branch') {
          const branchName = args[1];
          if (!branchName) {
            setHistory(prev => [...prev, ...Object.keys(git.branches).map(b => (b === git.currentBranch ? `* ${b}` : `  ${b}`))]);
          } else {
            setGit(prev => ({
              ...prev,
              branches: { ...prev.branches, [branchName]: prev.head }
            }));
            setHistory(prev => [...prev, `Created branch ${branchName}.`]);
          }
        } else if (subCmd === 'checkout') {
          const target = args[1];
          if (git.branches[target] !== undefined) {
            setGit(prev => ({
              ...prev,
              currentBranch: target,
              head: prev.branches[target]
            }));
            setHistory(prev => [...prev, `Switched to branch '${target}'.`]);
          } else if (git.commits.find(c => c.hash === target || c.id === target)) {
            const commit = git.commits.find(c => c.hash === target || c.id === target)!;
            setGit(prev => ({
              ...prev,
              currentBranch: `(HEAD detached at ${commit.hash})`,
              head: commit.id
            }));
            setHistory(prev => [...prev, `Note: switching to '${target}'.`, `You are in 'detached HEAD' state.`]);
          } else {
            setHistory(prev => [...prev, `Error: pathspec '${target}' did not match any file(s) known to git.`]);
          }
        } else if (subCmd === 'status') {
          const staged = Array.from(git.stagingArea);
          const unstaged = Object.keys(git.workingDirectory).filter(f => !git.stagingArea.has(f));
          
          setHistory(prev => [
            ...prev,
            `On branch ${git.currentBranch}`,
            staged.length > 0 ? '\nChanges to be committed:' : '',
            ...staged.map(f => `  modified: ${f}`),
            unstaged.length > 0 ? '\nChanges not staged for commit:' : '',
            ...unstaged.map(f => `  modified: ${f}`),
            staged.length === 0 && unstaged.length === 0 ? 'nothing to commit, working tree clean' : ''
          ]);
        } else if (subCmd === 'push') {
          setHistory(prev => [...prev, 'Enumerating objects: 4, done.', 'Counting objects: 100% (4/4), done.', 'Delta compression using up to 8 threads', 'Compressing objects: 100% (2/2), done.', 'Writing objects: 100% (3/3), 296 bytes | 296.00 KiB/s, done.', 'Total 3 (delta 1), reused 0 (delta 0), pack-reused 0', 'To github.com:user/sample-repo.git', `   ${git.head.substring(0, 7)}..${git.head.substring(0, 7)}  ${git.currentBranch} -> ${git.currentBranch}`]);
        } else {
          setHistory(prev => [...prev, `git: '${subCmd}' is not a git command. See 'help' or 'git --help'.`]);
        }
        break;

      case 'clear':
        setHistory([]);
        break;

      case 'reset':
        setGit(INITIAL_GIT_STATE);
        setHistory(['Simulation reset.']);
        break;

      default:
        setHistory(prev => [...prev, `Command not found: ${cmd}`]);
    }
  };

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;
    executeCommand(input);
    setInput('');
  };

  const updateFileContent = (name: string, content: string) => {
    setGit(prev => ({
      ...prev,
      workingDirectory: { ...prev.workingDirectory, [name]: content }
    }));
  };

  // Visualization helpers
  const getCommitById = (id: string) => git.commits.find(c => c.id === id);

  return (
    <div className="min-h-screen flex flex-col bg-bg text-text-main">
      {/* Header */}
      <header className="border-b border-border px-8 md:px-16 py-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="giant-heading">
            GIT CORE
          </h1>
          <p className="text-accent font-mono text-sm tracking-[0.2em] mt-4 uppercase">
            Task 019: Repository Management & Version Control
          </p>
        </div>
        <div className="flex flex-col items-end gap-2 text-right">
          <div className="flex items-center gap-2 bg-surface px-4 py-2 border border-border rounded-sm">
            <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_#22c55e]" />
            <span className="text-[10px] font-mono tracking-widest uppercase opacity-70">Simulation Link: Active</span>
          </div>
          <div className="text-[10px] font-mono tracking-widest uppercase text-text-dim">
            Branch: <span className="text-accent font-bold">{git.currentBranch}</span>
          </div>
        </div>
      </header>

      {/* Main Grid Layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12">
        
        {/* Left Sidebar: Stats & Files */}
        <aside className="lg:col-span-3 border-r border-border p-8 md:p-12 space-y-12 bg-surface/30">
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-text-dim mb-4 block font-bold">Active Repository</span>
            <div className="text-2xl font-bold tracking-tight break-all">sample-project-v1</div>
          </div>

          <div className="space-y-8">
            <div className="group">
              <div className="text-4xl font-light tracking-tighter tabular-nums">{Object.keys(git.workingDirectory).length.toString().padStart(2, '0')}</div>
              <div className="text-[10px] uppercase tracking-wider text-text-dim mt-1 font-bold group-hover:text-accent transition-colors">Total Project Files</div>
            </div>
            <div className="group">
              <div className="text-4xl font-light tracking-tighter tabular-nums">{git.commits.length.toString().padStart(2, '0')}</div>
              <div className="text-[10px] uppercase tracking-wider text-text-dim mt-1 font-bold group-hover:text-accent transition-colors">Total Version Commits</div>
            </div>
            <div className="group">
               <div className="text-4xl font-light tracking-tighter tabular-nums">{git.stagingArea.size.toString().padStart(2, '0')}</div>
               <div className="text-[10px] uppercase tracking-wider text-text-dim mt-1 font-bold group-hover:text-accent transition-colors">Files in Staging</div>
            </div>
          </div>

          {/* Local File Management */}
          <div className="pt-8 border-t border-border">
            <span className="text-[10px] uppercase tracking-[0.2em] text-text-dim mb-4 block font-bold">Working Tree</span>
            <div className="space-y-3">
              {Object.entries(git.workingDirectory).map(([name, content]) => (
                <div key={name} className="flex items-center justify-between group p-2 hover:bg-surface transition-colors rounded-sm border border-transparent hover:border-border">
                  <span className="text-sm font-mono opacity-80 flex items-center gap-2">
                    <File className="w-3 h-3 text-accent" /> {name}
                  </span>
                  <button 
                    onClick={() => executeCommand(`git add ${name}`)}
                    className={`text-[9px] uppercase font-black px-2 py-0.5 tracking-tighter transition-all ${git.stagingArea.has(name) ? 'text-green-500' : 'text-text-dim hover:text-text-main'}`}
                  >
                    {git.stagingArea.has(name) ? 'STAGED' : 'STAGE'}
                  </button>
                </div>
              ))}
              <button 
                onClick={() => {
                  const name = prompt('New filename:');
                  if (name) setGit(prev => ({ ...prev, workingDirectory: { ...prev.workingDirectory, [name]: 'New project file content' } }));
                }}
                className="w-full py-2 border border-dashed border-border flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest text-text-dim hover:text-text-main hover:border-text-dim transition-all mt-4"
              >
                <Plus className="w-3 h-3" /> New File
              </button>
            </div>
          </div>
        </aside>

        {/* Main Workspace */}
        <main className="lg:col-span-9 p-8 md:p-12 flex flex-col gap-12 overflow-hidden">
          
          {/* Top Section: Tabs & Graph */}
          <div className="flex-1 flex flex-col min-h-0">
             <div className="flex items-center gap-8 mb-8">
                <button 
                  onClick={() => setActiveTab('graph')}
                  className={`text-[10px] uppercase tracking-[0.3em] font-black pb-1 border-b-2 transition-all ${activeTab === 'graph' ? 'border-accent text-text-main' : 'border-transparent text-text-dim opacity-40 hover:opacity-100'}`}
                >
                  History Graph
                </button>
                <button 
                  onClick={() => setActiveTab('remote')}
                  className={`text-[10px] uppercase tracking-[0.3em] font-black pb-1 border-b-2 transition-all ${activeTab === 'remote' ? 'border-accent text-text-main' : 'border-transparent text-text-dim opacity-40 hover:opacity-100'}`}
                >
                  Remote Remotes
                </button>
             </div>

             <div className="flex-1 relative bg-surface border border-border rounded-sm overflow-auto p-12 custom-scrollbar">
                {activeTab === 'graph' ? (
                   <div className="flex flex-col-reverse items-center gap-16 relative">
                      {git.commits.length === 0 ? (
                        <div className="opacity-10 text-center py-20 pointer-events-none">
                          <History className="w-24 h-24 mx-auto mb-6" />
                          <div className="text-4xl font-black uppercase tracking-tighter">Repository Empty</div>
                        </div>
                      ) : (
                        git.commits.map((commit, idx) => (
                          <motion.div 
                            key={commit.id}
                            initial={{ x: -20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            className="w-full max-w-2xl flex items-center gap-8 group"
                          >
                             <div className="font-mono text-xs text-text-dim w-20 shrink-0 tabular-nums">
                               {commit.hash}
                             </div>
                             
                             <div className="relative flex-1 flex items-center gap-6 p-6 border border-border hover:border-accent group-hover:bg-accent/5 transition-all">
                                <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-bg border-4 border-accent rounded-full shadow-[0_0_10px_rgba(47,129,247,0.3)]" />
                                
                                <div className="flex-1">
                                  <div className="text-lg font-bold tracking-tight mb-1">{commit.message}</div>
                                  <div className="text-[10px] font-mono text-text-dim uppercase tracking-widest">
                                    {new Date(commit.timestamp).toLocaleString()}
                                  </div>
                                </div>

                                <div className="flex flex-col items-end gap-1">
                                  {Object.entries(git.branches)
                                    .filter(([_, headId]) => headId === commit.id)
                                    .map(([name]) => (
                                      <span key={name} className="text-[9px] font-black uppercase bg-accent text-white px-2 py-0.5 rounded-xs tracking-tighter">
                                        {name}
                                      </span>
                                    ))}
                                  {git.head === commit.id && (
                                    <span className="text-[9px] font-black uppercase border border-git-head text-git-head px-2 py-0.5 rounded-xs tracking-tighter">
                                      HEAD
                                    </span>
                                  )}
                                </div>
                             </div>

                             {idx < git.commits.length - 1 && (
                               <div className="absolute left-[108px] -top-16 w-[2px] h-16 bg-border -z-1" />
                             )}
                          </motion.div>
                        ))
                      )}
                   </div>
                ) : (
                   <div className="h-full flex flex-col items-center justify-center">
                      <div className="w-full max-w-md border border-border p-10 bg-bg space-y-8">
                         <div className="flex items-center gap-4 border-b border-border pb-6">
                            <Github className="w-8 h-8 text-accent" />
                            <div>
                               <div className="text-lg font-bold tracking-tight">origin/main</div>
                               <div className="text-[10px] font-mono text-text-dim">CONNECTED TO GITHUB.COM/USER/PROJECT</div>
                            </div>
                         </div>
                         <div className="space-y-4">
                            <button 
                              onClick={() => executeCommand('git push')}
                              className="w-full bg-text-main text-bg py-4 font-black uppercase text-xs tracking-[0.2em] hover:bg-accent hover:text-white transition-all shadow-xl shadow-accent/10"
                            >
                              Push Sync Ready
                            </button>
                            <div className="text-center text-[10px] text-text-dim uppercase tracking-widest opacity-50">
                               Last sync: 12 minutes ago
                            </div>
                         </div>
                      </div>
                   </div>
                )}
             </div>
          </div>

          {/* Bottom Area: Commit Action & Terminal */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 shrink-0">
             
             {/* Simple Commit Form */}
             <div className="space-y-4">
                <span className="text-[10px] uppercase tracking-[0.2em] text-text-dim block font-bold">New Version Snapshot</span>
                <div className="relative group">
                   <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none opacity-20 group-focus-within:opacity-100 group-focus-within:text-accent">
                      <GitCommit className="w-5 h-5" />
                   </div>
                   <input 
                      type="text"
                      id="commit-field"
                      placeholder="Commit message (e.g. Add core system initialization)"
                      className="w-full bg-surface border border-border px-12 py-4 rounded-sm text-sm focus:outline-none focus:border-accent transition-all placeholder:text-text-dim/30"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          executeCommand(`git commit -m "${(e.target as HTMLInputElement).value}"`);
                          (e.target as HTMLInputElement).value = '';
                        }
                      }}
                   />
                </div>
                <div className="flex items-center justify-between px-2">
                   <div className="text-[10px] text-text-dim uppercase tabular-nums">
                     {git.stagingArea.size} files staged
                   </div>
                   <button 
                      onClick={() => {
                        const input = document.getElementById('commit-field') as HTMLInputElement;
                        executeCommand(`git commit -m "${input.value}"`);
                        input.value = '';
                      }}
                      disabled={git.stagingArea.size === 0}
                      className="text-[10px] font-black uppercase text-accent hover:underline disabled:opacity-20 disabled:underline-none tracking-[0.2em]"
                   >
                     EXECUTE COMMIT
                   </button>
                </div>
             </div>

             {/* Terminal View */}
             <div className="bg-surface border border-border rounded-sm h-48 flex flex-col overflow-hidden relative group">
                <div className="absolute top-4 right-4 text-[10px] font-mono text-text-dim uppercase opacity-50 group-hover:opacity-100 flex items-center gap-2">
                  <TerminalIcon className="w-3 h-3" /> Terminal
                </div>
                <div className="flex-1 overflow-y-auto p-6 font-mono text-xs text-[#9ECBFF] custom-scrollbar">
                   {history.map((line, i) => (
                     <div key={i} className={`mb-1 ${line.startsWith('>') ? 'text-text-dim/60' : 'text-accent'}`}>
                       {line.startsWith('>') ? `$ ${line.substring(2)}` : line}
                     </div>
                   ))}
                   <form onSubmit={handleTerminalSubmit} className="flex">
                      <span className="text-text-dim/50 mr-2">$</span>
                      <input 
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        className="bg-transparent border-none p-0 focus:ring-0 outline-none flex-1 text-white"
                        placeholder="..."
                      />
                      <div ref={terminalEndRef} />
                   </form>
                </div>
             </div>

          </div>
        </main>
      </div>

      {/* Persistence Footer */}
      <footer className="border-t border-border px-8 md:px-16 py-6 flex items-center justify-between text-[10px] font-mono tracking-widest text-text-dim bg-surface">
        <div className="flex items-center gap-4">
           <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              SYSTEMS INITIALIZED
           </div>
           <span className="opacity-20">|</span>
           <div>ENCRYPTION: AES-256</div>
        </div>
        <div className="opacity-40 hover:opacity-100 transition-opacity cursor-help">
          GITFLOW SIMULATOR v1.02.44
        </div>
      </footer>
    </div>
  );

}
