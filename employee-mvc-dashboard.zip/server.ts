import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { Employee } from "./src/types.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock Repository / In-memory Data
  const employees: Employee[] = [
    {
      id: "1",
      firstName: "John",
      lastName: "Doe",
      email: "john.doe@example.com",
      department: "Engineering",
      designation: "Software Engineer",
      salary: 85000,
      joiningDate: "2023-01-15",
    },
    {
      id: "2",
      firstName: "Jane",
      lastName: "Smith",
      email: "jane.smith@example.com",
      department: "Human Resources",
      designation: "HR Manager",
      salary: 75000,
      joiningDate: "2022-06-20",
    },
    {
      id: "3",
      firstName: "Michael",
      lastName: "Brown",
      email: "michael.brown@example.com",
      department: "Marketing",
      designation: "Marketing Specialist",
      salary: 65000,
      joiningDate: "2024-03-10",
    },
    {
      id: "4",
      firstName: "Sarah",
      lastName: "Wilson",
      email: "sarah.wilson@example.com",
      department: "Finance",
      designation: "Financial Analyst",
      salary: 90000,
      joiningDate: "2021-11-05",
    },
  ];

  /**
   * Employee Controller (API Layer)
   * Simulated MVC flow using REST endpoints
   */

  // GET /api/employees - Index action
  app.get("/api/employees", (req, res) => {
    console.log("MVC Flow: Controller received request for all employees");
    res.json(employees);
  });

  // GET /api/employees/:id - Detail action
  app.get("/api/employees/:id", (req, res) => {
    const { id } = req.params;
    console.log(`MVC Flow: Controller received request for employee ID: ${id}`);
    const employee = employees.find((e) => e.id === id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json(employee);
  });

  // POST /api/employees - Simple create simulation
  app.post("/api/employees", (req, res) => {
    const newEmployee = { ...req.body, id: String(employees.length + 1) };
    employees.push(newEmployee);
    res.status(201).json(newEmployee);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Employee MVC Server running on http://localhost:${PORT}`);
  });
}

startServer();
