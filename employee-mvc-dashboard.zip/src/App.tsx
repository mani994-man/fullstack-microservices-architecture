import { useState, useEffect } from 'react';
import { Employee } from './types.ts';
import { motion, AnimatePresence } from 'motion/react';
import { Users, Briefcase, Mail, DollarSign, Calendar, ChevronRight, ArrowLeft, RefreshCw, Settings, LayoutGrid, FileText } from 'lucide-react';

export default function App() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'list' | 'detail'>('list');

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/employees');
      const data = await response.json();
      setEmployees(data);
    } catch (error) {
      console.error('Error fetching employees:', error);
    } finally {
      setLoading(false);
    }
  };

  const showDetail = async (id: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/employees/${id}`);
      const data = await response.json();
      setSelectedEmployee(data);
      setView('detail');
    } catch (error) {
      console.error('Error fetching employee details:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen font-sans bg-[#f0f2f5]">
      {/* Sidebar Overlay for Mobile could be here, but using design HTML fixed sidebar */}
      <aside className="sidebar hidden md:flex flex-col">
        <div className="sidebar-header">
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center text-xs">SV</div>
            SpringView
          </h1>
        </div>
        
        <ul className="py-6 flex-grow">
          <li 
            className={`nav-item flex items-center gap-3 ${view === 'list' && !selectedEmployee ? 'active' : ''}`}
            onClick={() => { setView('list'); setSelectedEmployee(null); }}
          >
            <Users size={18} /> Employee Management
          </li>
          <li className="nav-item flex items-center gap-3">
            <LayoutGrid size={18} /> Department Hierarchy
          </li>
          <li className="nav-item flex items-center gap-3">
            <DollarSign size={18} /> Payroll Processing
          </li>
          <li className="nav-item flex items-center gap-3">
            <Settings size={18} /> System Configurations
          </li>
        </ul>

        <div className="p-6 border-t border-white/10">
          <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-1">Architecture</p>
          <p className="text-[11px] text-white/60">ANNOTATION DRIVEN</p>
        </div>
      </aside>

      <main className="flex-grow flex flex-col">
        <header className="header flex items-center justify-between sticky top-0 z-50">
          <div className="flex items-center gap-4">
             {view === 'detail' && (
                <button 
                  onClick={() => setView('list')}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <ArrowLeft size={18} />
                </button>
             )}
             <h2 className="text-lg font-semibold text-slate-700">
               {view === 'list' ? 'Employee Directory' : 'Employee Profile View'}
             </h2>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={fetchEmployees}
              className={`p-2 border border-[#e2e8f0] rounded-lg bg-white hover:bg-gray-50 transition-colors flex items-center gap-2 text-sm font-medium ${loading ? 'opacity-50' : ''}`}
              disabled={loading}
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors shadow-sm">
              Export PDF
            </button>
          </div>
        </header>

        <div className="content-area overflow-y-auto">
          <AnimatePresence mode="wait">
            {view === 'list' ? (
              <motion.div
                key="list"
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                transition={{ duration: 0.2 }}
                className="table-container"
              >
                <div className="table-row header font-bold">
                  <div>ID</div>
                  <div>Full Name</div>
                  <div>Department</div>
                  <div>Designation</div>
                  <div className="text-right">Action</div>
                </div>

                {employees.map((emp) => (
                  <div 
                    key={emp.id} 
                    className="table-row cursor-pointer"
                    onClick={() => showDetail(emp.id)}
                  >
                    <div className="font-mono text-xs text-slate-400">#EMP-{emp.id.padStart(3, '0')}</div>
                    <div className="font-semibold text-slate-800">{emp.firstName} {emp.lastName}</div>
                    <div className="text-sm text-slate-600">{emp.department}</div>
                    <div className="text-sm text-slate-500 italic">{emp.designation}</div>
                    <div className="flex justify-end pr-2 text-blue-500">
                      <ChevronRight size={18} />
                    </div>
                  </div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="detail"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8"
              >
                {selectedEmployee && (
                  <>
                    <div className="detail-card">
                      <div className="card-header flex items-center gap-6 bg-slate-50/50">
                        <div className="avatar flex items-center justify-center text-3xl font-bold text-slate-400 bg-slate-200">
                          {selectedEmployee.firstName[0]}{selectedEmployee.lastName[0]}
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-slate-800">{selectedEmployee.firstName} {selectedEmployee.lastName}</h3>
                          <p className="text-slate-500 font-medium">{selectedEmployee.designation}</p>
                        </div>
                      </div>

                      <div className="info-grid">
                        <div className="info-item">
                          <label>Employee ID</label>
                          <p>#EMP-2026-{selectedEmployee.id.padStart(4, '0')}</p>
                        </div>
                        <div className="info-item">
                          <label>Department</label>
                          <p>{selectedEmployee.department}</p>
                        </div>
                        <div className="info-item">
                          <label>Email Address</label>
                          <p>{selectedEmployee.email}</p>
                        </div>
                        <div className="info-item">
                          <label>Joining Date</label>
                          <p>{selectedEmployee.joiningDate}</p>
                        </div>
                        <div className="info-item col-span-2 pt-4 border-t border-slate-100">
                          <label>Current Status</label>
                          <div className="flex items-center gap-2">
                             <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                             <p className="text-green-700 font-bold uppercase text-xs tracking-wider">Active Service</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-6">
                      <div className="stat-card">
                        <div className="stat-value">98.4%</div>
                        <div className="stat-label">Attendance Rate</div>
                        <div className="badge">Active Status</div>
                      </div>
                      <div className="stat-card">
                        <div className="stat-value">12</div>
                        <div className="stat-label">Projects Led</div>
                      </div>
                      <div className="stat-card">
                        <div className="stat-value">${(selectedEmployee.salary / 1000).toFixed(0)}k</div>
                        <div className="stat-label">Annual Compensation</div>
                      </div>
                    </div>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="mvc-tag mt-12 flex justify-between items-center opacity-30">
            <span>@Controller // @RequestMapping("/employee")</span>
            <span>Task 09 Implementation</span>
          </div>
        </div>
      </main>
    </div>
  );
}
