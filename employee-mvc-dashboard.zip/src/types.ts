/**
 * Employee domain model for the MVC application.
 */
export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  designation: string;
  salary: number;
  joiningDate: string;
}

export type OperationType = 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
