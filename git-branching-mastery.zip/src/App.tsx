/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GitGraph } from './components/GitGraph';
import { Terminal } from './components/Terminal';
import { FileEditor } from './components/FileEditor';
import { ConflictResolver } from './components/ConflictResolver';
import { useGitEngine } from './hooks/useGitEngine';
import { GitBranch, GitMerge, GitCommit, HelpCircle, Code2, PlayCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const {
    state,
    logs,
    currentBranch,
    commit,
    createBranch,
    checkout,
    merge,
    resolveConflict,
    abortMerge,
    updateFile,
    addLog
  } = useGitEngine();

  const handleCommand = (cmd: string) => {
    const parts = cmd.split(' ');
    const base = parts[0];

    if (base === 'git') {
      const sub = parts[1];
      if (sub === 'branch') {
        const name = parts[2];
        if (name) createBranch(name);
        else addLog('Usage: git branch <name>');
      } else if (sub === 'checkout') {
        const name = parts[2];
        if (name) checkout(name);
        else addLog('Usage: git checkout <name>');
      } else if (sub === 'commit') {
        const msgMatch = cmd.match(/-m ["'](.+?)["']/);
        const msg = msgMatch ? msgMatch[1] : (parts.slice(2).join(' ') || 'Manual commit');
        commit(msg);
      } else if (sub === 'merge') {
        const name = parts[2];
        if (name) merge(name);
        else addLog('Usage: git merge <branch>');
      } else if (sub === 'rebase') {
        addLog('Rebase simulation: This operation will rewrite history. (Not fully implemented in this demo, but use merge for similar flow control testing)');
      } else {
        addLog(`Unknown git command: ${sub}`);
      }
    } else if (base === 'help' || base === '?') {
       addLog('Commands: git branch <name>, git checkout <name>, git commit -m "msg", git merge <branch>');
    } else {
      addLog(`Command not recognized: ${base}. Type 'help' for options.`);
    }
  };

  const steps = [
    {
      title: 'Branching Strategy',
      description: 'Create a feature branch to work on a new component without affecting the main codebase.',
      command: 'git branch feature-login'
    },
    {
      title: 'Work & Commit',
      description: 'Switch to your branch and make some changes in the code editor, then commit.',
      command: 'git checkout feature-login'
    },
    {
      title: 'Create Conflict',
      description: 'Switch back to main, modify the same file differently, then try merging feature-login.',
      command: 'git merge feature-login'
    }
  ];

  return (
    <div className="flex flex-col h-screen p-6 max-w-[1400px] mx-auto overflow-hidden text-[#c9d1d9]">
      {/* Header Area */}
      <header className="flex justify-between items-center mb-6">
        <div className="task-info">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight text-white mb-1 uppercase">Task 20: Advanced Branching & Conflict Resolution</h1>
          </div>
          <p className="text-sm text-[#8b949e]">Simulate a collaborative workflow by merging divergent feature branches into master.</p>
        </div>
        <div className="flex items-center gap-4">
           <div className="flex items-center gap-2 px-3 py-1 bg-[#d299221a] border border-[#d2992266] rounded-full text-[#d29922] text-[10px] font-bold tracking-wider">
              <div className="w-1.5 h-1.5 rounded-full bg-[#d29922] animate-pulse" />
              IN PROGRESS
           </div>
           <div className="px-3 py-1 bg-[#58a6ff1a] border border-[#58a6ff66] rounded text-[#58a6ff] text-[10px] font-mono font-bold uppercase tracking-wider">
              {currentBranch.name}
           </div>
        </div>
      </header>

      {/* Bento Grid */}
      <main className="grid grid-cols-4 grid-rows-3 gap-4 flex-1 overflow-hidden">
        {/* Row 1-2: Git Graph */}
        <div className="col-span-3 row-span-2 bento-card relative">
          <div className="card-title">
            <span className="card-dot bg-[#58a6ff]" />
            LIVE REPOSITORY GRAPH
          </div>
          <div className="flex-1 overflow-hidden">
            <GitGraph 
              commits={state.commits} 
              branches={state.branches} 
              currentBranchId={state.currentBranchId} 
            />
          </div>
        </div>

        {/* Row 1-3: Instructions / Tutorial */}
        <div className="col-span-1 row-span-3 bento-card">
          <div className="card-title">
            <span className="card-dot bg-[#d29922]" />
            TASK STEPS
          </div>
          <div className="flex-1 p-5 overflow-y-auto space-y-6">
            <div className="space-y-4">
              {steps.map((step, i) => (
                <div key={i} className="relative pl-7">
                   <div className={`absolute left-0 top-1.5 w-3 h-3 rounded-full border-2 transition-all ${
                     i === 1 ? 'border-[#58a6ff] shadow-[0_0_8px_#58a6ff]' : 'border-[#30363d]'
                   }`} />
                  <h3 className="text-xs font-bold text-gray-200 mb-1 leading-tight">{step.title}</h3>
                  <p className="text-[11px] text-[#8b949e] leading-snug mb-2">{step.description}</p>
                  <code className="text-[10px] block py-1.5 px-2 bg-black/50 rounded text-emerald-400 font-mono border border-[#30363d]">
                    {step.command}
                  </code>
                </div>
              ))}
            </div>
            
            <div className="mt-10 p-4 bg-[#58a6ff0d] border border-dashed border-[#30363d] rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <HelpCircle size={14} className="text-[#58a6ff]" />
                <span className="text-[10px] font-bold text-[#58a6ff] uppercase tracking-wider">Pro Tip</span>
              </div>
              <p className="text-[10px] text-[#8b949e] leading-relaxed italic">
                Use <code>git rebase master</code> on your feature branch to keep history linear before merging.
              </p>
            </div>
          </div>
        </div>

        {/* Row 3: File Editor */}
        <div className="col-span-2 row-span-1 bento-card">
           <div className="card-title">
            <span className="card-dot bg-[#fff]" />
            WORKING DIRECTORY
          </div>
          <div className="flex-1 overflow-hidden">
            <FileEditor 
              files={state.workingDirectory} 
              onUpdate={updateFile} 
              onCommit={commit}
              isConflict={!!state.conflict}
            />
          </div>
        </div>

        {/* Row 3: Terminal */}
        <div className="col-span-1 row-span-1 bento-card">
          <div className="card-title">
            <span className="card-dot bg-[#3fb950]" />
            TERMINAL
          </div>
          <div className="flex-1 overflow-hidden">
            <Terminal onCommand={handleCommand} logs={logs} />
          </div>
        </div>
      </main>

      {/* Conflict Resolver Modal (Stays as Modal as per functionality) */}
      <ConflictResolver 
        conflict={state.conflict} 
        onResolve={resolveConflict}
        onAbort={abortMerge}
      />
    </div>
  );
}
