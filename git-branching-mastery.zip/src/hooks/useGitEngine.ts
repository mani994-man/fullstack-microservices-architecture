import { useState, useCallback, useMemo } from 'react';
import { Commit, Branch, GitState, Conflict } from '../types';

const COLORS = [
  '#3b82f6', // blue
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#8b5cf6', // violet
  '#ec4899', // pink
];

const INITIAL_COMMIT_ID = 'c1';
const INITIAL_BRANCH_ID = 'main';

const createInitialState = (): GitState => {
  const initialCommit: Commit = {
    id: INITIAL_COMMIT_ID,
    message: 'Initial commit',
    parentId: null,
    branchIds: [INITIAL_BRANCH_ID],
    x: 100,
    y: 200,
    author: 'git-master',
    timestamp: Date.now(),
    files: { 'readme.md': '# Project Alpha\nWelcome to the project.' },
  };

  const initialBranch: Branch = {
    id: INITIAL_BRANCH_ID,
    name: 'main',
    headCommitId: INITIAL_COMMIT_ID,
    color: COLORS[0],
  };

  return {
    commits: [initialCommit],
    branches: [initialBranch],
    currentBranchId: INITIAL_BRANCH_ID,
    workingDirectory: { ...initialCommit.files },
    stagingArea: {},
    conflict: null,
  };
};

export function useGitEngine() {
  const [state, setState] = useState<GitState>(createInitialState());
  const [logs, setLogs] = useState<string[]>(['Initialized empty repository']);

  const addLog = useCallback((msg: string) => {
    setLogs(prev => [...prev, `> ${msg}`].slice(-50));
  }, []);

  const currentBranch = useMemo(() => 
    state.branches.find(b => b.id === state.currentBranchId)!, 
    [state.branches, state.currentBranchId]
  );

  const headCommit = useMemo(() => 
    state.commits.find(c => c.id === currentBranch.headCommitId)!, 
    [state.commits, currentBranch.headCommitId]
  );

  const commit = useCallback((message: string) => {
    if (state.conflict) {
      addLog('Cannot commit during an unresolved conflict. Resolve first.');
      return;
    }

    const newCommitId = `c${state.commits.length + 1}`;
    
    // Calculate position
    // If it's the same branch, move x. If it's a new branch, might need different y.
    // Simple logic: Main branch stays on y=200. Other branches get unique y.
    const branchIndex = state.branches.findIndex(b => b.id === state.currentBranchId);
    const newY = 200 + (branchIndex * 80);
    const lastCommitOnThisBranch = state.commits.filter(c => c.branchIds.includes(state.currentBranchId)).pop();
    const newX = (lastCommitOnThisBranch?.x || 100) + 100;

    const newCommit: Commit = {
      id: newCommitId,
      message,
      parentId: currentBranch.headCommitId,
      branchIds: [state.currentBranchId],
      x: newX,
      y: newY,
      author: 'user',
      timestamp: Date.now(),
      files: { ...state.workingDirectory },
    };

    setState(prev => ({
      ...prev,
      commits: [...prev.commits, newCommit],
      branches: prev.branches.map(b => 
        b.id === state.currentBranchId ? { ...b, headCommitId: newCommitId } : b
      ),
      stagingArea: {},
    }));

    addLog(`Committed: ${message} (${newCommitId})`);
  }, [state, currentBranch, addLog]);

  const createBranch = useCallback((name: string) => {
    if (state.branches.some(b => b.name === name)) {
      addLog(`Branch ${name} already exists`);
      return;
    }

    const newBranchId = name;
    const newBranch: Branch = {
      id: newBranchId,
      name,
      headCommitId: currentBranch.headCommitId,
      color: COLORS[state.branches.length % COLORS.length],
    };

    setState(prev => ({
      ...prev,
      branches: [...prev.branches, newBranch],
    }));

    addLog(`Created branch: ${name}`);
  }, [state.branches, currentBranch, addLog]);

  const checkout = useCallback((name: string) => {
    const target = state.branches.find(b => b.name === name);
    if (!target) {
      addLog(`Branch ${name} not found`);
      return;
    }

    const targetCommit = state.commits.find(c => c.id === target.headCommitId)!;
    
    setState(prev => ({
      ...prev,
      currentBranchId: target.id,
      workingDirectory: { ...targetCommit.files },
    }));

    addLog(`Switched to branch: ${name}`);
  }, [state.branches, state.commits, addLog]);

  const merge = useCallback((sourceBranchName: string) => {
    const sourceBranch = state.branches.find(b => b.name === sourceBranchName);
    if (!sourceBranch) {
      addLog(`Branch ${sourceBranchName} not found`);
      return;
    }

    if (sourceBranch.id === state.currentBranchId) {
      addLog('Already on this branch');
      return;
    }

    const sourceCommit = state.commits.find(c => c.id === sourceBranch.headCommitId)!;
    const currentCommit = headCommit;

    // Detect conflicts
    const conflicts: string[] = [];
    Object.keys(sourceCommit.files).forEach(file => {
      if (currentCommit.files[file] !== undefined && currentCommit.files[file] !== sourceCommit.files[file]) {
        conflicts.push(file);
      }
    });

    if (conflicts.length > 0) {
      const conflictFile = conflicts[0];
      setState(prev => ({
        ...prev,
        conflict: {
          file: conflictFile,
          baseContent: 'Unknown base', // Simplified
          currentContent: currentCommit.files[conflictFile],
          incomingContent: sourceCommit.files[conflictFile],
          mergingBranch: sourceBranchName,
        }
      }));
      addLog(`CONFLICT in ${conflictFile}. Automatic merge failed; fix conflicts and then commit the result.`);
      return;
    }

    // Fast-forward or simple merge
    const newFiles = { ...currentCommit.files, ...sourceCommit.files };
    const newCommitId = `merge-${sourceBranch.id}-${Date.now()}`;
    
    const newCommit: Commit = {
      id: newCommitId,
      message: `Merge branch '${sourceBranchName}' into ${currentBranch.name}`,
      parentId: currentBranch.headCommitId,
      branchIds: [state.currentBranchId],
      x: headCommit.x + 100,
      y: headCommit.y,
      author: 'git-system',
      timestamp: Date.now(),
      files: newFiles,
    };

    setState(prev => ({
      ...prev,
      commits: [...prev.commits, newCommit],
      branches: prev.branches.map(b => 
        b.id === state.currentBranchId ? { ...b, headCommitId: newCommitId } : b
      ),
      workingDirectory: newFiles,
    }));

    addLog(`Merged ${sourceBranchName} into ${currentBranch.name}`);
  }, [state, currentBranch, headCommit, addLog]);

  const resolveConflict = useCallback((resolution: string) => {
    if (!state.conflict) return;

    const updatedFiles = {
      ...state.workingDirectory,
      [state.conflict.file]: resolution
    };

    setState(prev => ({
      ...prev,
      workingDirectory: updatedFiles,
      conflict: null
    }));

    addLog(`Resolved conflict in ${state.conflict.file}`);
  }, [state.conflict, state.workingDirectory, addLog]);

  const abortMerge = useCallback(() => {
    setState(prev => ({ ...prev, conflict: null }));
    addLog('Merge aborted.');
  }, [addLog]);

  const updateFile = useCallback((name: string, content: string) => {
    setState(prev => ({
      ...prev,
      workingDirectory: {
        ...prev.workingDirectory,
        [name]: content
      }
    }));
  }, []);

  return {
    state,
    logs,
    currentBranch,
    headCommit,
    commit,
    createBranch,
    checkout,
    merge,
    resolveConflict,
    abortMerge,
    updateFile,
    addLog
  };
}
