
export interface Commit {
  id: string;
  message: string;
  parentId: string | null;
  branchIds: string[];
  x: number;
  y: number;
  author: string;
  timestamp: number;
  files: Record<string, string>;
}

export interface Branch {
  id: string;
  name: string;
  headCommitId: string;
  color: string;
}

export interface GitState {
  commits: Commit[];
  branches: Branch[];
  currentBranchId: string;
  workingDirectory: Record<string, string>;
  stagingArea: Record<string, string>;
  conflict: Conflict | null;
}

export interface Conflict {
  file: string;
  baseContent: string;
  currentContent: string;
  incomingContent: string;
  mergingBranch: string;
}
