import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Check, X } from 'lucide-react';
import { Conflict } from '../types';

interface ConflictResolverProps {
  conflict: Conflict | null;
  onResolve: (content: string) => void;
  onAbort: () => void;
}

export const ConflictResolver: React.FC<ConflictResolverProps> = ({ conflict, onResolve, onAbort }) => {
  if (!conflict) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="bg-[#0d1117] border border-[#30363d] rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden"
        >
          <div className="p-4 bg-[#161b22] border-b border-[#30363d] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-[#f851491a] p-2 rounded-lg">
                <AlertTriangle className="text-[#f85149]" size={20} />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">Merge Conflict</h2>
                <p className="text-xs text-[#8b949e] font-mono">File: {conflict.file}</p>
              </div>
            </div>
            <button onClick={onAbort} className="text-[#8b949e] hover:text-white transition-colors p-1 hover:bg-[#30363d] rounded">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-auto grid grid-cols-2 divide-x divide-[#30363d]">
            {/* Current Changes */}
            <div className="flex flex-col bg-[#0d1117]">
              <div className="p-3 bg-[#58a6ff1a] text-[#58a6ff] text-[10px] font-bold uppercase tracking-widest border-b border-[#30363d]">
                Current Changes (HEAD)
              </div>
              <div className="p-6 flex-1 font-mono text-sm text-[#c9d1d9] whitespace-pre-wrap leading-relaxed overflow-auto">
                {conflict.currentContent}
              </div>
              <div className="p-4 bg-[#161b22] border-t border-[#30363d]">
                <button
                  onClick={() => onResolve(conflict.currentContent)}
                  className="w-full px-4 py-2 bg-[#238636] hover:bg-[#2ea043] text-white rounded-lg text-sm font-bold transition-all flex items-center justify-center gap-2"
                >
                  <Check size={16} />
                  Accept Current
                </button>
              </div>
            </div>

            {/* Incoming Changes */}
            <div className="flex flex-col bg-[#0d1117]">
              <div className="p-3 bg-[#3fb9501a] text-[#3fb950] text-[10px] font-bold uppercase tracking-widest border-b border-[#30363d]">
                Incoming Changes ({conflict.mergingBranch})
              </div>
              <div className="p-6 flex-1 font-mono text-sm text-[#c9d1d9] whitespace-pre-wrap leading-relaxed overflow-auto">
                {conflict.incomingContent}
              </div>
              <div className="p-4 bg-[#161b22] border-t border-[#30363d]">
                <button
                  onClick={() => onResolve(conflict.incomingContent)}
                  className="w-full px-4 py-2 bg-[#58a6ff33] hover:bg-[#58a6ff] text-[#58a6ff] hover:text-white border border-[#58a6ff33] rounded-lg text-sm font-bold transition-all flex items-center justify-center gap-2"
                >
                  <Check size={16} />
                  Accept Incoming
                </button>
              </div>
            </div>
          </div>

          <div className="p-4 bg-[#0d1117] border-t border-[#30363d] flex items-center justify-between">
            <p className="text-[10px] text-[#8b949e] italic">
              * Hint: Rebasing would have replayed these commits one by one.
            </p>
            <div className="flex gap-3">
              <button
                onClick={onAbort}
                className="px-4 py-2 text-[#8b949e] hover:text-[#c9d1d9] text-xs font-medium transition-colors"
              >
                Abort Merge
              </button>
              <button 
                onClick={() => onResolve(`${conflict.currentContent}\n\n${conflict.incomingContent}`)}
                className="px-6 py-2 bg-[#21262d] hover:bg-[#30363d] text-white border border-[#30363d] text-xs font-bold rounded-lg transition-colors"
              >
                Keep Both Changes
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
