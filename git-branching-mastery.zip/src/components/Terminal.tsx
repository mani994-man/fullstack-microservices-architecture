import React, { useState } from 'react';
import { Terminal as TerminalIcon, ChevronRight } from 'lucide-react';

interface TerminalProps {
  onCommand: (cmd: string) => void;
  logs: string[];
}

export const Terminal: React.FC<TerminalProps> = ({ onCommand, logs }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onCommand(input.trim());
      setInput('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-black text-[#c9d1d9] font-mono text-xs overflow-hidden">
      <div className="flex-1 p-4 overflow-y-auto space-y-1">
        {logs.map((log, i) => (
          <div key={i} className={`whitespace-pre-wrap ${log.startsWith('>') ? 'text-[#3fb950] font-bold' : 'text-[#8b949e]'}`}>
            {log}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex items-center gap-2 px-4 py-3 bg-[#0d1117] border-t border-[#30363d]">
        <span className="text-[#3fb950] font-bold">$</span>
        <input
          autoFocus
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="git merge..."
          className="flex-1 bg-transparent outline-none border-none text-[#c9d1d9] placeholder-[#444c56]"
        />
      </form>
    </div>
  );
};
