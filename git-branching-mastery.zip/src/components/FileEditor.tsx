import React from 'react';
import { FileCode, Save } from 'lucide-react';

interface FileEditorProps {
  files: Record<string, string>;
  onUpdate: (name: string, content: string) => void;
  onCommit: (msg: string) => void;
  isConflict: boolean;
}

export const FileEditor: React.FC<FileEditorProps> = ({ files, onUpdate, onCommit, isConflict }) => {
  const [activeFile, setActiveFile] = React.useState(Object.keys(files)[0] || '');
  const [commitMsg, setCommitMsg] = React.useState('');

  const currentContent = files[activeFile] || '';

  return (
    <div className="flex flex-col h-full bg-transparent overflow-hidden">
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#161b22] border-b border-[#30363d]">
        <div className="flex items-center gap-4 overflow-x-auto">
          {Object.keys(files).map((name) => (
            <button
              key={name}
              onClick={() => setActiveFile(name)}
              className={`flex items-center gap-2 px-3 py-1 text-[10px] transition-colors rounded ${
                activeFile === name ? 'bg-[#0d1117] text-[#58a6ff] border border-[#30363d]' : 'text-[#8b949e] hover:text-[#c9d1d9]'
              }`}
            >
              <FileCode size={12} />
              {name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 relative">
        <textarea
          disabled={isConflict}
          value={currentContent}
          onChange={(e) => onUpdate(activeFile, e.target.value)}
          className="w-full h-full p-6 bg-transparent text-[#c9d1d9] font-mono text-[13px] outline-none resize-none leading-relaxed"
          placeholder="Edit file contents..."
        />
        {isConflict && (
          <div className="absolute inset-0 bg-[#f851490d] backdrop-blur-[1px] flex items-center justify-center">
             <div className="bg-[#f85149] text-white px-4 py-2 rounded-lg text-[10px] font-bold shadow-xl">
                CONFLICT IN FILE
             </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-[#0d1117] border-t border-[#30363d] space-y-3">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={commitMsg}
            onChange={(e) => setCommitMsg(e.target.value)}
            placeholder="Commit message..."
            className="flex-1 bg-[#161b22] border border-[#30363d] rounded-md px-3 py-1.5 text-xs text-[#c9d1d9] outline-none focus:border-[#58a6ff] transition-colors"
          />
          <button
            onClick={() => {
              if (commitMsg.trim()) {
                onCommit(commitMsg);
                setCommitMsg('');
              }
            }}
            disabled={isConflict || !commitMsg.trim()}
            className="flex items-center gap-2 px-4 py-1.5 bg-[#238636] hover:bg-[#2ea043] disabled:opacity-50 disabled:bg-[#23863655] disabled:cursor-not-allowed text-white text-xs font-bold rounded-md transition-colors"
          >
            <Save size={14} />
            Commit
          </button>
        </div>
      </div>
    </div>
  );
};
