import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { Commit, Branch } from '../types';

interface GitGraphProps {
  commits: Commit[];
  branches: Branch[];
  currentBranchId: string;
}

export const GitGraph: React.FC<GitGraphProps> = ({ commits, branches, currentBranchId }) => {
  const links = useMemo(() => {
    return commits.map(commit => {
      if (!commit.parentId) return null;
      const parent = commits.find(c => c.id === commit.parentId);
      if (!parent) return null;

      return (
        <line
          key={`${parent.id}-${commit.id}`}
          x1={parent.x}
          y1={parent.y}
          x2={commit.x}
          y2={commit.y}
          stroke="var(--border)"
          strokeWidth="2"
          strokeDasharray="4"
        />
      );
    }).filter(Boolean);
  }, [commits]);

  return (
    <div className="relative w-full h-full overflow-auto bg-transparent p-8">
      <svg width="2000" height="600" className="min-w-full">
        <defs>
          <marker
            id="arrowhead"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="var(--border)" />
          </marker>
        </defs>
        
        {/* Connection lines */}
        <g strokeLinecap="round">{links}</g>

        {/* Commit circles */}
        {commits.map((commit) => {
          const isHead = branches.some(b => b.headCommitId === commit.id);
          const headBranch = branches.find(b => b.headCommitId === commit.id);
          const isCurrentHead = headBranch?.id === currentBranchId;

          return (
            <motion.g
              key={commit.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', damping: 12, stiffness: 100 }}
            >
              <circle
                cx={commit.x}
                cy={commit.y}
                r="10"
                fill={isCurrentHead ? '#fff' : 'var(--card-bg)'}
                stroke={headBranch?.color || 'var(--border)'}
                strokeWidth={isHead ? "3" : "2"}
                className="cursor-pointer transition-colors"
              />
              <text
                x={commit.x}
                y={commit.y + 25}
                textAnchor="middle"
                className="text-[9px] fill-[#8b949e] font-mono pointer-events-none"
              >
                {commit.id}
              </text>
              <text
                x={commit.x}
                y={commit.y - 20}
                textAnchor="middle"
                className="text-[10px] fill-[#c9d1d9] font-medium pointer-events-none"
              >
                {commit.message.length > 15 ? commit.message.slice(0, 12) + '...' : commit.message}
              </text>
              
              {/* Branch Indicators */}
              {branches.filter(b => b.headCommitId === commit.id).map((b, i) => (
                <motion.g 
                  key={b.id} 
                  initial={{ y: -10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="pointer-events-none"
                >
                  <rect
                    x={commit.x - 30}
                    y={commit.y + 35 + (i * 20)}
                    width="60"
                    height="16"
                    rx="4"
                    fill={isCurrentHead && b.id === currentBranchId ? 'var(--accent-blue)' : b.color}
                    fillOpacity="0.1"
                    stroke={isCurrentHead && b.id === currentBranchId ? 'var(--accent-blue)' : b.color}
                    strokeWidth="1"
                  />
                  <text
                    x={commit.x}
                    y={commit.y + 47 + (i * 20)}
                    textAnchor="middle"
                    className="text-[9px] font-bold fill-white uppercase tracking-wider"
                  >
                    {b.name}
                  </text>
                </motion.g>
              ))}
            </motion.g>
          );
        })}
      </svg>
      
      {/* Legend */}
      <div className="absolute top-4 left-4 bg-[#0d1117]/80 backdrop-blur border border-[#30363d] p-3 rounded-lg text-[10px] text-[#8b949e] space-y-2">
         <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full border-2 border-white bg-[#0d1117]" />
            <span>Current HEAD</span>
         </div>
         <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full border-2 border-emerald-500 bg-[#0d1117]" />
            <span>Branch HEAD</span>
         </div>
         <div className="flex items-center gap-2">
            <div className="w-3 h-0.5 border-t-2 border-dashed border-[#30363d]" />
            <span>Parent Pointer</span>
         </div>
      </div>
    </div>
  );
};
