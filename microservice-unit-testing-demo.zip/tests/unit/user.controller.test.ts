import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { UserController } from '../../src/api/user/user.controller';
import { UserService } from '../../src/api/user/user.service';

describe('UserController (REST Controller)', () => {
  let app: express.Express;
  let mockUserService: any;

  beforeEach(() => {
    mockUserService = {
      listUsers: vi.fn(),
      getUserProfile: vi.fn(),
      registerUser: vi.fn(),
    };

    const controller = new UserController(mockUserService as UserService);
    app = express();
    app.use(express.json());
    app.use('/users', controller.router);
  });

  describe('GET /users', () => {
    it('should return list of users', async () => {
      const users = [{ id: '1', username: 'test' }];
      mockUserService.listUsers.mockResolvedValue(users);

      const response = await request(app).get('/users');
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(users);
    });
  });

  describe('GET /users/:id', () => {
    it('should return user if found', async () => {
      const user = { id: '1', username: 'test' };
      mockUserService.getUserProfile.mockResolvedValue(user);

      const response = await request(app).get('/users/1');
      
      expect(response.status).toBe(200);
      expect(response.body).toEqual(user);
    });

    it('should return 404 if user not found', async () => {
      mockUserService.getUserProfile.mockRejectedValue(new Error('User not found'));

      const response = await request(app).get('/users/999');
      
      expect(response.status).toBe(404);
      expect(response.body.message).toBe('User not found');
    });
  });

  describe('POST /users', () => {
    it('should create user and return 201', async () => {
      const newUser = { username: 'test', email: 'test@test.com' };
      const createdUser = { id: '123', ...newUser, role: 'user' };
      mockUserService.registerUser.mockResolvedValue(createdUser);

      const response = await request(app)
        .post('/users')
        .send(newUser);
      
      expect(response.status).toBe(201);
      expect(response.body).toEqual(createdUser);
    });

    it('should return 400 for bad requests (logic errors)', async () => {
      mockUserService.registerUser.mockRejectedValue(new Error('Username too short'));

      const response = await request(app)
        .post('/users')
        .send({ username: 'ab' });
      
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Username too short');
    });
  });
});
