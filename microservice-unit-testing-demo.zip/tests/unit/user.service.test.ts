import { describe, it, expect, vi, beforeEach } from 'vitest';
import { UserService } from '../../src/api/user/user.service';
import { UserRepository } from '../../src/api/user/user.repository';

describe('UserService (Service Logic)', () => {
  let userService: UserService;
  let mockRepository: any;

  beforeEach(() => {
    // Mock the repository to isolate service logic
    mockRepository = {
      findById: vi.fn(),
      findByEmail: vi.fn(),
      save: vi.fn(),
      getAll: vi.fn(),
    };
    userService = new UserService(mockRepository as UserRepository);
  });

  describe('getUserProfile', () => {
    it('should return user when found', async () => {
      const mockUser = { id: '1', username: 'test', email: 'test@test.com', role: 'user' };
      mockRepository.findById.mockResolvedValue(mockUser);

      const result = await userService.getUserProfile('1');
      expect(result).toEqual(mockUser);
      expect(mockRepository.findById).toHaveBeenCalledWith('1');
    });

    it('should throw error when user not found', async () => {
      mockRepository.findById.mockResolvedValue(null);

      await expect(userService.getUserProfile('1')).rejects.toThrow('User not found');
    });
  });

  describe('registerUser', () => {
    const newUser = { username: 'newuser', email: 'new@test.com' };

    it('should register a new user successfully', async () => {
      mockRepository.findByEmail.mockResolvedValue(null);
      mockRepository.save.mockResolvedValue({ id: '123', ...newUser, role: 'user' });

      const result = await userService.registerUser(newUser);
      
      expect(result.id).toBe('123');
      expect(mockRepository.save).toHaveBeenCalledWith(newUser);
    });

    it('should throw if email is already taken', async () => {
      mockRepository.findByEmail.mockResolvedValue({ id: '1' });

      await expect(userService.registerUser(newUser)).rejects.toThrow('Email already in use');
    });

    it('should throw if username too short', async () => {
      await expect(userService.registerUser({ username: 'ab', email: 'test@test.com' }))
        .rejects.toThrow('Username too short');
    });
  });
});
