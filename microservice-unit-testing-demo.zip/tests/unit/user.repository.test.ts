import { describe, it, expect, beforeEach } from 'vitest';
import { UserRepository } from '../../src/api/user/user.repository';

describe('UserRepository (Data Handling)', () => {
  let repository: UserRepository;

  beforeEach(() => {
    repository = new UserRepository();
  });

  it('should find a user by ID', async () => {
    const user = await repository.findById('1');
    expect(user).toBeDefined();
    expect(user?.username).toBe('john_doe');
  });

  it('should return null for non-existent user ID', async () => {
    const user = await repository.findById('999');
    expect(user).toBeNull();
  });

  it('should save a new user', async () => {
    const newUser = { username: 'test_user', email: 'test@example.com' };
    const savedUser = await repository.save(newUser);
    
    expect(savedUser.id).toBeDefined();
    expect(savedUser.role).toBe('user');
    
    const found = await repository.findById(savedUser.id);
    expect(found).toMatchObject(newUser);
  });

  it('should find a user by email', async () => {
    const user = await repository.findByEmail('john@example.com');
    expect(user).toBeDefined();
    expect(user?.id).toBe('1');
  });
});
