import express from 'express';
import { UserRepository } from './api/user/user.repository';
import { UserService } from './api/user/user.service';
import { UserController } from './api/user/user.controller';

const app = express();
app.use(express.json());

const userRepository = new UserRepository();
const userService = new UserService(userRepository);
const userController = new UserController(userService);

app.use('/api/users', userController.router);

export default app;
