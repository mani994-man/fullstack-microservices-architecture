import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  Server, 
  Globe, 
  CheckCircle2, 
  Users, 
  RefreshCw,
  AlertCircle,
  Terminal
} from 'lucide-react';

interface User {
  id: string;
  username: string;
  email: string;
  role: string;
}

export default function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'api' | 'tests'>('api');

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      setUsers(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col font-sans bg-bg text-ink overflow-hidden selection:bg-ink selection:text-bg">
      {/* Header */}
      <header className="h-[80px] border-b border-ink flex items-baseline justify-between px-10 shrink-0">
        <div className="italic-display text-2xl font-black tracking-tighter">Studio.Unit</div>
        <div className="text-[11px] font-bold uppercase tracking-[2px]">Deployment Phase // Task-18</div>
      </header>

      {/* Main Body */}
      <main className="flex-1 grid grid-cols-[350px_1fr_300px] overflow-hidden">
        {/* Sidebar Left */}
        <section className="border-r border-ink p-10 flex flex-col justify-between overflow-y-auto">
          <div>
            <span className="label-caps mb-2 block">Current Objective</span>
            <h1 className="text-[54px] font-bold leading-[0.9] uppercase mb-10 break-all">
              {activeTab === 'api' ? 'Live API Monitor' : 'Testing Logic'}
            </h1>
            
            <div className="space-y-6">
              <span className="label-caps block">Navigation</span>
              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => setActiveTab('api')}
                  className={`text-left italic-display text-lg py-1 border-b transition-all ${activeTab === 'api' ? 'border-ink text-ink' : 'border-transparent text-dim hover:text-ink'}`}
                >
                  &mdash; User Microservice API
                </button>
                <button 
                  onClick={() => setActiveTab('tests')}
                  className={`text-left italic-display text-lg py-1 border-b transition-all ${activeTab === 'tests' ? 'border-ink text-ink' : 'border-transparent text-dim hover:text-ink'}`}
                >
                  &mdash; Reliability Unit Tests
                </button>
              </div>
            </div>
          </div>

          <div className="pt-10">
            <span className="label-caps mb-4 block">Tech Stack</span>
            <ul className="italic-display text-[18px] space-y-3">
              <li>&mdash; Vitest / SuperTest</li>
              <li>&mdash; Express / Node.js</li>
              <li>&mdash; TypeScript / React</li>
            </ul>
          </div>
        </section>

        {/* Content Core */}
        <section className="bg-white border-r border-ink p-14 relative overflow-y-auto">
          <div className="flex justify-between items-center mb-8">
            <span className="label-caps">Reliability Metrics</span>
            {activeTab === 'api' && (
              <button 
                onClick={fetchUsers}
                className="text-[10px] font-bold uppercase tracking-widest border border-ink px-4 py-1 rounded-full hover:bg-ink hover:text-bg transition-colors"
              >
                Refresh Stream
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-10">
            <MetricBox label="Logic Branch Coverage" val="94.2%" progress={94} />
            <MetricBox label="Controller Integrity" val="88.5%" progress={88} />
            <MetricBox label="Data Persistence" val="100%" progress={100} />
            <MetricBox label="Mocking Efficiency" val="12ms" progress={20} />
          </div>

          <div className="mt-14 h-px bg-ink/10" />

          <div className="mt-14">
            <AnimatePresence mode="wait">
              {activeTab === 'api' ? (
                <motion.div 
                  key="api"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <span className="label-caps mb-6 block">Service Output</span>
                  {loading ? (
                    <div className="p-12 text-center italic-display opacity-40">Parsing stream...</div>
                  ) : error ? (
                    <div className="p-12 text-center text-red-600 font-mono text-xs italic">{error}</div>
                  ) : (
                    <div className="border border-ink divide-y divide-ink">
                      {users.map((user) => (
                        <div key={user.id} className="p-5 flex justify-between items-center hover:bg-bg transition-colors">
                          <div>
                            <p className="font-bold">{user.username}</p>
                            <p className="text-[11px] font-medium text-dim">{user.email}</p>
                          </div>
                          <span className={`text-[9px] uppercase font-bold tracking-widest px-2 py-0.5 border border-ink rounded-full ${user.role === 'admin' ? 'bg-ink text-bg' : ''}`}>
                            {user.role}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div 
                  key="tests"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-10"
                >
                  <span className="label-caps mb-6 block">Vitest Execution Log</span>
                  <div className="space-y-8">
                    <TestFile name="user.controller.test.ts" cases={['GET /users', 'GET /users/:id', 'POST /users']} />
                    <TestFile name="user.service.test.ts" cases={['getUserProfile', 'registerUser', 'validation']} />
                    <TestFile name="user.repository.test.ts" cases={['findById', 'save', 'findByEmail']} />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="mt-14 pt-10 border-t border-ink">
            <span className="label-caps mb-3 block">System Log</span>
            <p className="italic-display text-2xl leading-tight">
              &ldquo;{activeTab === 'api' ? 'Verifying real-time microservice throughput and response integrity.' : 'Complete isolation of core service logic ensured via dependency mocking.'}&rdquo;
            </p>
          </div>
        </section>

        {/* Sidebar Right */}
        <section className="p-10 bg-bg/30 overflow-y-auto">
          <div className="inline-block px-3 py-1 border border-ink rounded-full text-[10px] font-bold uppercase mb-10">
            Live Environment
          </div>

          <div className="space-y-10">
            <DetailItem 
              id="01" 
              title="Independent Execution" 
              desc="Isolation of service logic from external network dependencies using stubs." 
            />
            <DetailItem 
              id="02" 
              title="REST Layer Mapping" 
              desc="Ensuring JSON serialization and status codes meet contract definitions." 
            />
            <DetailItem 
              id="03" 
              title="Data Abstraction" 
              desc="Repository pattern prevents direct coupling with database implementation." 
            />
          </div>

          <div className="mt-20 p-6 border border-ink bg-white italic-display text-sm relative">
             <Terminal size={12} className="absolute top-2 right-2 opacity-20" />
             <p className="opacity-70 mb-2">// Sample Request</p>
             <code className="text-[11px] block text-accent overflow-x-auto">
               GET /api/users/1<br/>
               Status: 200 OK
             </code>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="h-[120px] border-t border-ink grid grid-cols-3 divide-x divide-ink shrink-0">
        <div className="flex flex-col justify-center px-10">
          <span className="label-caps mb-1">Active Suites</span>
          <strong className="text-xl">14 Unit Tests</strong>
        </div>
        <div className="flex flex-col justify-center px-10">
          <span className="label-caps mb-1">Overall Health</span>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <strong className="text-xl">Operational</strong>
          </div>
        </div>
        <div className="flex flex-col justify-center px-10">
          <span className="label-caps mb-1">Revision Hash</span>
          <strong className="font-mono text-sm uppercase">8A2F99-TSK18</strong>
        </div>
      </footer>
    </div>
  );
}

function MetricBox({ label, val, progress }: { label: string, val: string, progress: number }) {
  return (
    <div className="p-6 border border-ink bg-white relative group">
      <span className="label-caps">{label}</span>
      <div className="text-[42px] font-light my-2">{val}</div>
      <div className="h-px bg-ink w-full relative mt-4">
        <div 
          className="absolute h-1 bg-ink -top-[1.5px] left-0 transition-all duration-1000" 
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}

function TestFile({ name, cases }: { name: string, cases: string[] }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3 border-b border-ink/20 pb-1">
        <span className="italic-display text-lg font-bold">{name}</span>
        <CheckCircle2 size={14} className="text-accent" />
      </div>
      <div className="space-y-2 pl-4">
        {cases.map((test, i) => (
          <div key={i} className="flex items-center gap-3 text-[13px] text-ink/70">
            <CheckCircle2 size={10} className="text-accent shrink-0" />
            <span>{test}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function DetailItem({ id, title, desc }: { id: string, title: string, desc: string }) {
  return (
    <div>
      <span className="label-caps mb-1 block text-ink/20">{id}</span>
      <h3 className="text-[14px] font-bold mb-2 uppercase tracking-tight">{title}</h3>
      <p className="text-xs text-dim leading-relaxed italic-display font-medium">
        {desc}
      </p>
    </div>
  );
}
