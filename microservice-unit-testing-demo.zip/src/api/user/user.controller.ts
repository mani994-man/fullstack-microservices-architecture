import { Request, Response, Router } from 'express';
import { UserService } from './user.service';

export class UserController {
  public router: Router;

  constructor(private userService: UserService) {
    this.router = Router();
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get('/', this.getAllUsers.bind(this));
    this.router.get('/:id', this.getUser.bind(this));
    this.router.post('/', this.createUser.bind(this));
  }

  async getAllUsers(req: Request, res: Response) {
    try {
      const users = await this.userService.listUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  }

  async getUser(req: Request, res: Response) {
    try {
      const user = await this.userService.getUserProfile(req.params.id);
      res.json(user);
    } catch (error: any) {
      const status = error.message === 'User not found' ? 404 : 500;
      res.status(status).json({ message: error.message });
    }
  }

  async createUser(req: Request, res: Response) {
    try {
      const user = await this.userService.registerUser(req.body);
      res.status(201).json(user);
    } catch (error: any) {
      const status = error.message.includes('already in use') || error.message.includes('too short') ? 400 : 500;
      res.status(status).json({ message: error.message });
    }
  }
}
