import { UserRepository } from './user.repository';
import { User, CreateUserDTO } from './user.types';

export class UserService {
  constructor(private userRepository: UserRepository) {}

  async getUserProfile(id: string): Promise<User> {
    const user = await this.userRepository.findById(id);
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  }

  async registerUser(data: CreateUserDTO): Promise<User> {
    const existing = await this.userRepository.findByEmail(data.email);
    if (existing) {
      throw new Error('Email already in use');
    }

    if (data.username.length < 3) {
      throw new Error('Username too short');
    }

    return this.userRepository.save(data);
  }

  async listUsers(): Promise<User[]> {
    return this.userRepository.getAll();
  }
}
