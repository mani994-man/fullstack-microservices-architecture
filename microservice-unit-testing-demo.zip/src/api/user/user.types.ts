export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
}

export interface CreateUserDTO {
  username: string;
  email: string;
}
