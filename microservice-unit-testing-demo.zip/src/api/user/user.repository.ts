import { User, CreateUserDTO } from './user.types';

export class UserRepository {
  private users: User[] = [
    { id: '1', username: 'john_doe', email: 'john@example.com', role: 'user' },
    { id: '2', username: 'admin_jane', email: 'jane@example.com', role: 'admin' },
  ];

  async findById(id: string): Promise<User | null> {
    return this.users.find(u => u.id === id) || null;
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.users.find(u => u.email === email) || null;
  }

  async save(data: CreateUserDTO): Promise<User> {
    const newUser: User = {
      ...data,
      id: Math.random().toString(36).substring(2, 9),
      role: 'user',
    };
    this.users.push(newUser);
    return newUser;
  }

  async getAll(): Promise<User[]> {
    return [...this.users];
  }
}
