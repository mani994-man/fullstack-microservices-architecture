import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Users, Calendar, BarChart3, Star } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface AdminEvent {
  id: string;
  title: string;
  event_date: string;
  event_type: string;
  department: string;
  capacity: number;
  registration_count: number;
  avg_rating: number | null;
  feedback_count: number;
}

export const Route = createFileRoute("/admin/")({
  component: AdminDashboard,
});

function AdminDashboard() {
  const [events, setEvents] = useState<AdminEvent[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data: evs } = await supabase
      .from("events")
      .select("id, title, event_date, event_type, department, capacity")
      .order("event_date", { ascending: false });

    if (!evs) { setEvents([]); setLoading(false); return; }

    const enriched = await Promise.all(evs.map(async (e) => {
      const { count: regCount } = await supabase
        .from("registrations").select("*", { count: "exact", head: true }).eq("event_id", e.id);
      const { data: fb } = await supabase
        .from("feedback").select("rating").eq("event_id", e.id);
      const ratings = fb ?? [];
      const avg = ratings.length ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length : null;
      return { ...e, registration_count: regCount ?? 0, avg_rating: avg, feedback_count: ratings.length };
    }));

    setEvents(enriched);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleDelete = async (id: string, title: string) => {
    if (!confirm(`Delete "${title}"? This cancels all registrations.`)) return;
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Event deleted"); load(); }
  };

  const totalRegs = events.reduce((s, e) => s + e.registration_count, 0);
  const totalEvents = events.length;
  const avgFill = events.length
    ? Math.round((events.reduce((s, e) => s + e.registration_count / e.capacity, 0) / events.length) * 100)
    : 0;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight">Admin dashboard</h1>
          <p className="mt-2 text-muted-foreground">Manage events and view statistics.</p>
        </div>
        <Button asChild className="bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90">
          <Link to="/admin/events/new"><Plus className="mr-1 h-4 w-4" /> New event</Link>
        </Button>
      </div>

      {/* Stats */}
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <StatCard icon={Calendar} label="Total events" value={totalEvents.toString()} />
        <StatCard icon={Users} label="Total registrations" value={totalRegs.toString()} />
        <StatCard icon={BarChart3} label="Avg fill rate" value={`${avgFill}%`} />
      </div>

      {/* Events table */}
      <h2 className="mt-10 font-display text-xl font-semibold">All events</h2>
      {loading ? (
        <div className="mt-4 h-40 animate-pulse rounded-2xl bg-muted" />
      ) : events.length === 0 ? (
        <Card className="mt-4 p-12 text-center">
          <p className="text-muted-foreground">No events yet. Create your first one.</p>
        </Card>
      ) : (
        <div className="mt-4 space-y-3">
          {events.map((e) => {
            const fill = Math.round((e.registration_count / e.capacity) * 100);
            return (
              <Card key={e.id} className="p-5 shadow-card">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className="bg-gradient-brand text-primary-foreground border-0">{e.event_type}</Badge>
                      <span className="text-xs text-muted-foreground">{e.department}</span>
                    </div>
                    <Link to="/events/$eventId" params={{ eventId: e.id }} className="mt-1.5 block font-semibold hover:text-gradient">
                      {e.title}
                    </Link>
                    <p className="mt-1 text-xs text-muted-foreground">{format(new Date(e.event_date), "MMM d, yyyy · h:mm a")}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button asChild size="sm" variant="outline">
                      <Link to="/admin/events/$eventId/edit" params={{ eventId: e.id }}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleDelete(e.id, e.title)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <Stat label="Registered" value={`${e.registration_count} / ${e.capacity}`} sub={`${fill}% full`} />
                  <Stat
                    label="Avg rating"
                    value={e.avg_rating !== null ? e.avg_rating.toFixed(1) : "—"}
                    sub={e.feedback_count ? `${e.feedback_count} ratings` : "no ratings"}
                    icon={Star}
                  />
                  <div>
                    <p className="text-xs uppercase tracking-wide text-muted-foreground">Capacity</p>
                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full bg-gradient-brand"
                        style={{ width: `${Math.min(fill, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <Card className="p-5 shadow-card">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{label}</p>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-brand">
          <Icon className="h-4 w-4 text-primary-foreground" />
        </div>
      </div>
      <p className="mt-3 font-display text-3xl font-bold">{value}</p>
    </Card>
  );
}

function Stat({ label, value, sub, icon: Icon }: { label: string; value: string; sub?: string; icon?: React.ComponentType<{ className?: string }> }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 inline-flex items-center gap-1 font-display text-lg font-semibold">
        {Icon && <Icon className="h-4 w-4 text-accent fill-accent" />}
        {value}
      </p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}
