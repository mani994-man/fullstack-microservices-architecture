import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import type { EventRow } from "@/lib/events";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Calendar, MapPin, Users, Clock, ArrowLeft, Star } from "lucide-react";
import { format, isPast } from "date-fns";
import { toast } from "sonner";

export const Route = createFileRoute("/events/$eventId")({
  component: EventDetailPage,
});

function EventDetailPage() {
  const { eventId } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState<EventRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [registered, setRegistered] = useState(false);
  const [registrationCount, setRegistrationCount] = useState(0);
  const [busy, setBusy] = useState(false);
  const [myRating, setMyRating] = useState<number | null>(null);
  const [hover, setHover] = useState(0);

  const load = async () => {
    const { data: ev } = await supabase.from("events").select("*").eq("id", eventId).maybeSingle();
    setEvent(ev as EventRow | null);
    const { count } = await supabase
      .from("registrations")
      .select("*", { count: "exact", head: true })
      .eq("event_id", eventId);
    setRegistrationCount(count ?? 0);
    if (user) {
      const { data: reg } = await supabase
        .from("registrations").select("id").eq("event_id", eventId).eq("user_id", user.id).maybeSingle();
      setRegistered(!!reg);
      const { data: fb } = await supabase
        .from("feedback").select("rating").eq("event_id", eventId).eq("user_id", user.id).maybeSingle();
      setMyRating(fb?.rating ?? null);
    }
    setLoading(false);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [eventId, user?.id]);

  const handleRegister = async () => {
    if (!user) { navigate({ to: "/auth" }); return; }
    if (!event) return;
    setBusy(true);
    const { error } = await supabase.from("registrations").insert({ event_id: event.id, user_id: user.id });
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("You're registered!"); load(); }
  };

  const handleCancel = async () => {
    if (!user || !event) return;
    setBusy(true);
    const { error } = await supabase.from("registrations").delete().eq("event_id", event.id).eq("user_id", user.id);
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Registration cancelled"); load(); }
  };

  const setRating = async (r: number) => {
    if (!user || !event) return;
    const { error } = await supabase
      .from("feedback")
      .upsert({ event_id: event.id, user_id: user.id, rating: r }, { onConflict: "event_id,user_id" });
    if (error) toast.error(error.message);
    else { toast.success("Thanks for the feedback!"); setMyRating(r); }
  };

  if (loading) return <div className="mx-auto max-w-3xl px-4 py-10"><div className="h-64 animate-pulse rounded-2xl bg-muted" /></div>;
  if (!event) return (
    <div className="mx-auto max-w-3xl px-4 py-10 text-center">
      <p>Event not found.</p>
      <Button asChild className="mt-4"><Link to="/events">Back to events</Link></Button>
    </div>
  );

  const full = registrationCount >= event.capacity;
  const deadlinePassed = isPast(new Date(event.registration_deadline));
  const eventPassed = isPast(new Date(event.event_date));

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Link to="/events" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All events
      </Link>

      <div className="mb-6 flex flex-wrap gap-2">
        <Badge className="bg-gradient-brand text-primary-foreground border-0">{event.event_type}</Badge>
        <Badge variant="secondary">{event.department}</Badge>
      </div>

      <h1 className="font-display text-4xl font-bold leading-tight tracking-tight sm:text-5xl">{event.title}</h1>
      <p className="mt-4 text-base text-muted-foreground">{event.description}</p>

      <Card className="mt-8 grid gap-4 p-6 shadow-card sm:grid-cols-2">
        <Info icon={Calendar} label="When" value={format(new Date(event.event_date), "EEE, MMM d, yyyy · h:mm a")} />
        <Info icon={MapPin} label="Where" value={event.location} />
        <Info icon={Users} label="Capacity" value={`${registrationCount} / ${event.capacity} registered`} />
        <Info icon={Clock} label="Register by" value={format(new Date(event.registration_deadline), "MMM d, h:mm a")} />
      </Card>

      <div className="mt-6">
        {eventPassed ? (
          registered ? (
            <Card className="p-6 shadow-card">
              <h3 className="font-display text-lg font-semibold">Rate this event</h3>
              <p className="mt-1 text-sm text-muted-foreground">Your feedback helps organizers improve.</p>
              <div className="mt-3 flex gap-1">
                {[1,2,3,4,5].map((r) => (
                  <button
                    key={r}
                    onMouseEnter={() => setHover(r)}
                    onMouseLeave={() => setHover(0)}
                    onClick={() => setRating(r)}
                    className="p-1"
                    aria-label={`Rate ${r} stars`}
                  >
                    <Star
                      className={`h-7 w-7 transition-colors ${
                        (hover || myRating || 0) >= r ? "fill-accent text-accent" : "text-muted-foreground/40"
                      }`}
                    />
                  </button>
                ))}
              </div>
              {myRating && <p className="mt-2 text-xs text-muted-foreground">Your rating: {myRating}/5</p>}
            </Card>
          ) : (
            <p className="text-sm text-muted-foreground">This event has already taken place.</p>
          )
        ) : registered ? (
          <Button onClick={handleCancel} disabled={busy} variant="outline" size="lg">
            ✓ You're registered — Cancel
          </Button>
        ) : (
          <Button
            onClick={handleRegister}
            disabled={busy || full || deadlinePassed}
            size="lg"
            className="bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90"
          >
            {full ? "Event is full" : deadlinePassed ? "Registration closed" : "Register now"}
          </Button>
        )}
      </div>
    </div>
  );
}

function Info({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-4 w-4 text-foreground" />
      </div>
      <div>
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}
