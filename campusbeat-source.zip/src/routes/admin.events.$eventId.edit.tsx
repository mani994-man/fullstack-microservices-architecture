import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { EVENT_TYPES, DEPARTMENTS } from "@/lib/events";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/events/$eventId/edit")({
  component: EditEvent,
});

const schema = z.object({
  title: z.string().trim().min(3).max(150),
  description: z.string().trim().min(10).max(2000),
  event_date: z.string().min(1),
  registration_deadline: z.string().min(1),
  location: z.string().trim().min(1).max(200),
  event_type: z.string().min(1),
  department: z.string().min(1),
  capacity: z.number().int().min(1).max(10000),
});

function EditEvent() {
  const { eventId } = Route.useParams();
  const isNew = eventId === "new";
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(!isNew);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    title: "", description: "", event_date: "", registration_deadline: "",
    location: "", event_type: "Workshop", department: "Computer Science", capacity: 50,
  });

  useEffect(() => {
    if (isNew) return;
    supabase.from("events").select("*").eq("id", eventId).maybeSingle().then(({ data }) => {
      if (data) {
        setForm({
          title: data.title,
          description: data.description,
          event_date: data.event_date.slice(0, 16),
          registration_deadline: data.registration_deadline.slice(0, 16),
          location: data.location,
          event_type: data.event_type,
          department: data.department,
          capacity: data.capacity,
        });
      }
      setLoading(false);
    });
  }, [eventId, isNew]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({
      ...form,
      event_date: new Date(form.event_date).toISOString(),
      registration_deadline: new Date(form.registration_deadline).toISOString(),
      capacity: Number(form.capacity),
    });
    if (!parsed.success) { toast.error(parsed.error.errors[0].message); return; }

    setBusy(true);
    const payload = parsed.data;
    if (isNew) {
      const { error } = await supabase.from("events").insert({ ...payload, created_by: user!.id });
      setBusy(false);
      if (error) toast.error(error.message);
      else { toast.success("Event created!"); navigate({ to: "/admin" }); }
    } else {
      const { error } = await supabase.from("events").update(payload).eq("id", eventId);
      setBusy(false);
      if (error) toast.error(error.message);
      else { toast.success("Event updated!"); navigate({ to: "/admin" }); }
    }
  };

  if (loading) return <div className="mx-auto max-w-2xl px-4 py-10"><div className="h-96 animate-pulse rounded-2xl bg-muted" /></div>;

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <Link to="/admin" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to admin
      </Link>
      <h1 className="font-display text-3xl font-bold tracking-tight">{isNew ? "New event" : "Edit event"}</h1>

      <Card className="mt-6 p-6 shadow-card">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Title">
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required maxLength={150} />
          </Field>
          <Field label="Description">
            <Textarea rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required maxLength={2000} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Event date & time">
              <Input type="datetime-local" value={form.event_date} onChange={(e) => setForm({ ...form, event_date: e.target.value })} required />
            </Field>
            <Field label="Registration deadline">
              <Input type="datetime-local" value={form.registration_deadline} onChange={(e) => setForm({ ...form, registration_deadline: e.target.value })} required />
            </Field>
          </div>
          <Field label="Location">
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} required maxLength={200} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Type">
              <Select value={form.event_type} onValueChange={(v) => setForm({ ...form, event_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{EVENT_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Department">
              <Select value={form.department} onValueChange={(v) => setForm({ ...form, department: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DEPARTMENTS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Capacity">
              <Input type="number" min={1} max={10000} value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} required />
            </Field>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => navigate({ to: "/admin" })}>Cancel</Button>
            <Button type="submit" disabled={busy} className="bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90">
              {busy ? "Saving…" : isNew ? "Create event" : "Save changes"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
