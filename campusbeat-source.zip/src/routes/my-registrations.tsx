import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import type { EventRow } from "@/lib/events";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin } from "lucide-react";
import { format, isPast } from "date-fns";

export const Route = createFileRoute("/my-registrations")({
  head: () => ({ meta: [{ title: "My events — CampusBeat" }] }),
  component: MyRegistrations,
});

function MyRegistrations() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<EventRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/auth" });
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("registrations")
      .select("event_id, events(*)")
      .eq("user_id", user.id)
      .then(({ data }) => {
        const evs = (data ?? []).map((r: { events: EventRow | null }) => r.events).filter(Boolean) as EventRow[];
        evs.sort((a, b) => new Date(a.event_date).getTime() - new Date(b.event_date).getTime());
        setItems(evs);
        setLoading(false);
      });
  }, [user]);

  if (!user) return null;

  const upcoming = items.filter((e) => !isPast(new Date(e.event_date)));
  const past = items.filter((e) => isPast(new Date(e.event_date)));

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="font-display text-4xl font-bold tracking-tight">My events</h1>
      <p className="mt-2 text-muted-foreground">Events you've registered for.</p>

      {loading ? (
        <div className="mt-8 h-40 animate-pulse rounded-2xl bg-muted" />
      ) : items.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
          <p className="text-muted-foreground">You haven't registered for any events yet.</p>
          <Button asChild className="mt-4 bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90">
            <Link to="/events">Browse events</Link>
          </Button>
        </div>
      ) : (
        <>
          {upcoming.length > 0 && (
            <Section title="Upcoming">
              {upcoming.map((e) => <Row key={e.id} event={e} />)}
            </Section>
          )}
          {past.length > 0 && (
            <Section title="Past">
              {past.map((e) => <Row key={e.id} event={e} />)}
            </Section>
          )}
        </>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-8">
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">{title}</h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Row({ event }: { event: EventRow }) {
  return (
    <Link to="/events/$eventId" params={{ eventId: event.id }}>
      <Card className="flex items-start gap-4 p-5 shadow-card transition-shadow hover:shadow-pop">
        <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-xl bg-gradient-soft">
          <span className="text-xs font-medium text-muted-foreground">{format(new Date(event.event_date), "MMM")}</span>
          <span className="font-display text-xl font-bold">{format(new Date(event.event_date), "d")}</span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Badge className="bg-gradient-brand text-primary-foreground border-0">{event.event_type}</Badge>
            <span className="text-xs text-muted-foreground">{event.department}</span>
          </div>
          <h3 className="mt-1.5 font-semibold">{event.title}</h3>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Calendar className="h-3 w-3" />{format(new Date(event.event_date), "h:mm a")}</span>
            <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{event.location}</span>
          </div>
        </div>
      </Card>
    </Link>
  );
}
