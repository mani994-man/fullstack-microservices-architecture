import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { EventRow } from "@/lib/events";
import { EVENT_TYPES, DEPARTMENTS } from "@/lib/events";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Search } from "lucide-react";
import { format } from "date-fns";
import { AdminBootstrap } from "@/components/AdminBootstrap";

export const Route = createFileRoute("/events/")({
  head: () => ({ meta: [{ title: "Browse events — CampusBeat" }] }),
  component: EventsPage,
});

function EventsPage() {
  const [events, setEvents] = useState<EventRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [type, setType] = useState<string>("all");
  const [dept, setDept] = useState<string>("all");

  useEffect(() => {
    supabase
      .from("events")
      .select("*")
      .gte("event_date", new Date().toISOString())
      .order("event_date", { ascending: true })
      .then(({ data }) => {
        setEvents((data ?? []) as EventRow[]);
        setLoading(false);
      });
  }, []);

  const filtered = useMemo(() => {
    return events.filter((e) => {
      if (type !== "all" && e.event_type !== type) return false;
      if (dept !== "all" && e.department !== dept) return false;
      if (q && !e.title.toLowerCase().includes(q.toLowerCase()) && !e.description.toLowerCase().includes(q.toLowerCase()))
        return false;
      return true;
    });
  }, [events, q, type, dept]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <AdminBootstrap />
      <div className="mb-8">
        <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">Upcoming events</h1>
        <p className="mt-2 text-muted-foreground">Filter and find your next campus experience.</p>
      </div>

      {/* Filters */}
      <div className="mb-6 grid gap-3 sm:grid-cols-[1fr_auto_auto]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search events…"
            className="pl-9"
          />
        </div>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {EVENT_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={dept} onValueChange={setDept}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Department" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All departments</SelectItem>
            {DEPARTMENTS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-56 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <p className="text-muted-foreground">No events match your filters.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((ev) => <EventCard key={ev.id} event={ev} />)}
        </div>
      )}
    </div>
  );
}

function EventCard({ event }: { event: EventRow }) {
  return (
    <Link
      to="/events/$eventId"
      params={{ eventId: event.id }}
      className="group block"
    >
      <Card className="h-full overflow-hidden border-border p-5 shadow-card transition-all hover:-translate-y-1 hover:shadow-pop">
        <div className="flex items-start justify-between gap-2">
          <Badge className="bg-gradient-brand text-primary-foreground border-0">{event.event_type}</Badge>
          <span className="text-xs text-muted-foreground">{event.department}</span>
        </div>
        <h3 className="mt-3 font-display text-lg font-semibold leading-tight group-hover:text-gradient">
          {event.title}
        </h3>
        <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{event.description}</p>
        <div className="mt-4 space-y-1.5 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            {format(new Date(event.event_date), "MMM d, yyyy · h:mm a")}
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" />
            {event.location}
          </div>
        </div>
      </Card>
    </Link>
  );
}
