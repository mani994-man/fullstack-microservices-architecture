import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Calendar, Users, BarChart3, Sparkles, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CampusBeat — Discover campus events that move you" },
      { name: "description", content: "Browse workshops, seminars, hackathons and cultural events at your campus. Register in seconds." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-soft opacity-60" />
        <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-gradient-brand opacity-30 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-accent opacity-30 blur-3xl" />

        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-28">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-1.5 text-xs font-medium backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-brand" />
            Smart Campus Event Management
          </div>
          <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-7xl">
            Where campus
            <br />
            <span className="text-gradient">comes alive.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Browse workshops, seminars, hackathons & cultural fests. Register in one tap. Don't miss a beat.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90">
              <Link to="/events">
                Browse events <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/auth">Get started</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-6 sm:grid-cols-3">
          {[
            { icon: Calendar, title: "Discover", desc: "Filter events by date, department, or type — find what matters to you." },
            { icon: Users, title: "Register", desc: "One-click signup with capacity tracking and instant confirmation." },
            { icon: BarChart3, title: "Engage", desc: "Rate events you attend. Admins see live attendance stats." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 shadow-card transition-shadow hover:shadow-pop">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-brand">
                <f.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
