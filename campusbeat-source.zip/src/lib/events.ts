export const EVENT_TYPES = ["Workshop", "Seminar", "Hackathon", "Cultural", "Sports", "Conference"] as const;
export const DEPARTMENTS = [
  "Computer Science",
  "Electrical",
  "Mechanical",
  "Civil",
  "Business",
  "Arts",
  "All Departments",
] as const;

export type EventType = (typeof EVENT_TYPES)[number];
export type Department = (typeof DEPARTMENTS)[number];

export interface EventRow {
  id: string;
  title: string;
  description: string;
  event_date: string;
  location: string;
  event_type: string;
  department: string;
  capacity: number;
  registration_deadline: string;
  created_at: string;
}
