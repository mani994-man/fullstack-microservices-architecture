import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { ShieldCheck } from "lucide-react";
import { toast } from "sonner";

/**
 * Bootstrap card: if zero admins exist in the system, lets the
 * currently-signed-in user claim the first admin role.
 * Hidden as soon as any admin exists.
 */
export function AdminBootstrap() {
  const { user, isAdmin, refreshRoles } = useAuth();
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user || isAdmin) { setNeedsBootstrap(false); return; }
    // Try to read user_roles; if no admins exist for current user OR no admin-role rows visible,
    // try insert. The has_role check + RLS means non-admins can't read admin rows of others,
    // so we attempt the insert and let DB constraints / a count check decide.
    supabase
      .from("user_roles")
      .select("user_id", { count: "exact", head: true })
      .eq("role", "admin")
      .then(({ count, error }) => {
        // If there are no admins at all OR we can't see any (RLS), allow attempt.
        if (error || !count || count === 0) setNeedsBootstrap(true);
      });
  }, [user, isAdmin]);

  if (!user || isAdmin || !needsBootstrap) return null;

  const claimAdmin = async () => {
    setBusy(true);
    // Re-check there are truly no admins (anyone can run this query, RLS allows seeing own role only,
    // but we want a global check — so we do a head count which RLS may filter. Best-effort.)
    const { count } = await supabase
      .from("user_roles").select("*", { count: "exact", head: true }).eq("role", "admin");
    if (count && count > 0) {
      toast.error("An admin already exists. Ask them to grant you access.");
      setBusy(false);
      setNeedsBootstrap(false);
      return;
    }
    const { error } = await supabase.from("user_roles").insert({ user_id: user.id, role: "admin" });
    setBusy(false);
    if (error) {
      toast.error("Could not claim admin: " + error.message);
    } else {
      toast.success("You are now an admin!");
      await refreshRoles();
      setNeedsBootstrap(false);
    }
  };

  return (
    <div className="mb-6 rounded-2xl border border-dashed border-brand/40 bg-gradient-soft p-5">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-brand">
          <ShieldCheck className="h-5 w-5 text-primary-foreground" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-display font-semibold">No admin yet</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">
            This campus has no admin. Claim the first admin role to start creating events.
          </p>
        </div>
        <Button onClick={claimAdmin} disabled={busy} size="sm" className="bg-gradient-brand text-primary-foreground shadow-pop hover:opacity-90">
          {busy ? "…" : "Become admin"}
        </Button>
      </div>
    </div>
  );
}
