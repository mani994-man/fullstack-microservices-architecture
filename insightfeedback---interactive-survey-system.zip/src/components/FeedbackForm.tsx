import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, CheckCircle2, AlertCircle, Send } from 'lucide-react';
import { validateEmail, validateName, validateMessage } from '../lib/validation';

interface FormData {
  name: string;
  email: string;
  rating: number | null;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
  rating?: string;
}

export default function FeedbackForm() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    rating: null,
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [hoveredRating, setHoveredRating] = useState<number | null>(null);
  const submitButtonRef = useRef<HTMLButtonElement>(null);

  // Field validation logic triggered on key up (keypress requirement)
  const handleKeyUp = (e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>, field: keyof FormData) => {
    const value = e.currentTarget.value;
    let error = '';

    if (field === 'name' && !validateName(value)) {
      error = "At least 2 characters required";
    } else if (field === 'email' && value && !validateEmail(value)) {
      error = "Invalid email format";
    } else if (field === 'message' && !validateMessage(value)) {
      error = "Tell us more! (min 10 chars)";
    }

    setErrors(prev => ({ ...prev, [field]: error }));
  };

  const handleInputChange = (field: keyof FormData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Double-click submit requirement
  const handleDoubleClickSubmit = () => {
    // Final validation
    const newErrors: FormErrors = {};
    if (!validateName(formData.name)) newErrors.name = "Required";
    if (!validateEmail(formData.email)) newErrors.email = "Required";
    if (!validateMessage(formData.message)) newErrors.message = "Required";
    if (formData.rating === null) newErrors.rating = "Please select a rating";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Success path
    localStorage.setItem('feedback_data', JSON.stringify({ ...formData, timestamp: new Date().toISOString() }));
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="max-w-md"
      >
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 bg-black flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 text-[#00FF00]" />
          </div>
          <h2 className="text-5xl font-black uppercase tracking-tighter">Received.</h2>
        </div>
        <p className="text-xl font-medium text-gray-500 mb-8 leading-tight">
          Your feedback has been successfully processed by the system.
        </p>
        <button 
          onClick={() => {
            setIsSubmitted(false);
            setFormData({ name: '', email: '', rating: null, message: '' });
          }}
          className="bg-black text-white px-10 py-4 font-black uppercase tracking-widest hover:bg-[#00FF00] hover:text-black transition-colors"
        >
          Send Another
        </button>
      </motion.div>
    );
  }

  return (
    <div className="w-full max-w-2xl">
      <form className="space-y-12" onKeyDown={(e) => e.key === 'Enter' && e.preventDefault()}>
        {/* Name Field */}
        <div className="group transition-transform duration-200 hover:translate-x-[10px]">
          <label className="block text-[14px] font-[800] uppercase tracking-[1px] mb-2 text-black">
            Full Name
          </label>
          <div className="relative border-b-[4px] border-black">
            <input
              type="text"
              placeholder="ENTER NAME"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              onKeyUp={(e) => handleKeyUp(e, 'name')}
              className="w-full bg-transparent border-none py-3 text-[32px] font-[600] outline-none placeholder:text-gray-200 uppercase text-black"
            />
            {errors.name && (
              <span className="absolute right-0 bottom-[12px] bg-black text-white text-[11px] font-[700] uppercase px-2 py-1">
                {errors.name}
              </span>
            )}
            {!errors.name && formData.name.length >= 2 && (
              <span className="absolute right-0 bottom-[12px] bg-[#00FF00] text-black text-[11px] font-[700] uppercase px-2 py-1">
                VALID FORMAT
              </span>
            )}
          </div>
          <p className="text-[12px] italic opacity-60 mt-2">Validates in real-time as you type.</p>
        </div>

        {/* Email Field */}
        <div className="group transition-transform duration-200 hover:translate-x-[10px]">
          <label className="block text-[14px] font-[800] uppercase tracking-[1px] mb-2 text-black">
            Email Address
          </label>
          <div className="relative border-b-[4px] border-black">
            <input
              type="email"
              placeholder="EMAIL@DOMAIN.COM"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              onKeyUp={(e) => handleKeyUp(e, 'email')}
              className="w-full bg-transparent border-none py-2 text-[32px] font-[600] outline-none placeholder:text-gray-200 uppercase text-black"
            />
            {errors.email && (
              <span className="absolute right-0 bottom-[12px] bg-red-600 text-white text-[11px] font-[700] uppercase px-2 py-1">
                {errors.email}
              </span>
            )}
          </div>
        </div>

        {/* Rating Field */}
        <div className="group transition-transform duration-200 hover:translate-x-[10px]">
          <label className="block text-[14px] font-[800] uppercase tracking-[1px] mb-4 text-black">
            Rating
          </label>
          <div className="flex gap-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(null)}
                onClick={() => handleInputChange('rating', star)}
                className="relative active:scale-95 transition-transform"
              >
                <div className={`w-12 h-12 flex items-center justify-center border-4 border-black transition-colors
                  ${(hoveredRating || 0) >= star || (formData.rating || 0) >= star 
                    ? 'bg-black text-[#00FF00]' 
                    : 'bg-transparent text-black'}
                `}>
                  <span className="text-xl font-black">{star}</span>
                </div>
              </button>
            ))}
          </div>
          {errors.rating && <p className="mt-2 text-xs font-bold text-red-600 uppercase">{errors.rating}</p>}
        </div>

        {/* Feedback Message */}
        <div className="group transition-transform duration-200 hover:translate-x-[10px]">
          <label className="block text-[14px] font-[800] uppercase tracking-[1px] mb-2 text-black">
            Your Thoughts
          </label>
          <div className="relative border-b-[4px] border-black">
            <textarea
              rows={3}
              placeholder="SPEAK YOUR MIND..."
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              onKeyUp={(e) => handleKeyUp(e, 'message')}
              className="w-full bg-transparent border-none py-2 text-[24px] font-[600] outline-none resize-none placeholder:text-gray-200 uppercase text-black"
            />
            {errors.message && (
              <span className="absolute right-0 bottom-[12px] bg-black text-white text-[11px] font-[700] uppercase px-2 py-1">
                {errors.message}
              </span>
            )}
          </div>
        </div>

        {/* Submit Area */}
        <div className="pt-4">
          <button
            ref={submitButtonRef}
            type="button"
            onDoubleClick={handleDoubleClickSubmit}
            className="bg-black text-white px-12 py-6 text-[24px] font-[900] uppercase tracking-wide cursor-pointer hover:bg-[#00FF00] hover:text-black transition-all"
          >
            Submit Feedback
          </button>
          <span className="block mt-3 text-[11px] font-[600] uppercase opacity-50 text-black">
            [ Double-click to confirm submission ]
          </span>
        </div>
      </form>
    </div>
  );
}
