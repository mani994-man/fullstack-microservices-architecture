/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import FeedbackForm from './components/FeedbackForm';

export default function App() {
  return (
    <div className="flex h-screen overflow-hidden bg-white text-black font-sans selection:bg-[#00FF00] selection:text-black">
      {/* Sidebar - Bold Display Typography Theme */}
      <aside className="w-[400px] p-[60px_40px] border-r-2 border-black flex flex-col justify-between shrink-0 bg-white">
        <div>
          <div className="w-5 h-5 bg-[#00FF00] mb-[10px]" />
          <h1 className="text-[80px] font-[900] leading-[0.9] uppercase tracking-[-4px] font-sans">
            Feed<br />Back<br />System
          </h1>
        </div>
        <div className="text-[12px] font-[700] uppercase tracking-[2px]">
          System Version 4.0.2 &copy; 2026
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-[80px] overflow-y-auto flex flex-col justify-center bg-white">
        <FeedbackForm />
      </main>
    </div>
  );
}

