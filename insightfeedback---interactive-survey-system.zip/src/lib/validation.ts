/**
 * Reusable validation logic for the feedback form.
 */

export const validateEmail = (email: string): boolean => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validateName = (name: string): boolean => {
  return name.trim().length >= 2;
};

export const validateMessage = (message: string): boolean => {
  return message.trim().length >= 10;
};

export const validateForm = (data: { name: string; email: string; message: string; rating: number | null }) => {
  const errors: Record<string, string> = {};

  if (!validateName(data.name)) {
    errors.name = "Name must be at least 2 characters.";
  }

  if (!validateEmail(data.email)) {
    errors.email = "Please enter a valid email address.";
  }

  if (!validateMessage(data.message)) {
    errors.message = "Feedback must be at least 10 characters long.";
  }

  if (data.rating === null) {
    errors.rating = "Please provide a rating.";
  }

  return errors;
};
