/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  GitBranch, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Terminal, 
  HardDrive, 
  Activity, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight,
  Github,
  Gitlab,
  Server
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type StepStatus = 'pending' | 'running' | 'success' | 'failed';

interface PipelineStep {
  id: string;
  name: string;
  description: string;
  status: StepStatus;
  duration?: string;
}

const INITIAL_STEPS: PipelineStep[] = [
  { id: 'checkout', name: 'Code Checkout', description: 'Retrieving latest code from repository', status: 'pending' },
  { id: 'lint', name: 'Lint & Quality', description: 'Running static analysis and formatting checks', status: 'pending' },
  { id: 'test', name: 'Unit Testing', description: 'Executing vitest suites for core logic', status: 'pending' },
  { id: 'build', name: 'Production Build', description: 'Compiling assets for production deployment', status: 'pending' },
  { id: 'deploy', name: 'Cloud Deployment', description: 'Syncing build artifacts to production servers', status: 'pending' },
];

const CONFIG_FILES = {
  github: {
    name: '.github/workflows/ci-cd.yml',
    icon: Github,
    content: `name: CI/CD Pipeline
on: push: branches: [ main ]
jobs:
  build-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm install
      - run: npm test
      - run: npm run build`
  },
  jenkins: {
    name: 'Jenkinsfile',
    icon: Server,
    content: `pipeline {
  agent any
  stages {
    stage('Test') { steps { sh 'npm test' } }
    stage('Build') { steps { sh 'npm run build' } }
    stage('Deploy') { steps { sh 'echo "Deploying..." ' } }
  }
}`
  },
  gitlab: {
    name: '.gitlab-ci.yml',
    icon: Gitlab,
    content: `stages: [build, test, deploy]
test_job:
  stage: test
  script:
    - npm test
deploy_job:
  stage: deploy
  script:
    - echo "Deploying..." `
  }
};

export default function App() {
  const [steps, setSteps] = useState<PipelineStep[]>(INITIAL_STEPS);
  const [activeConfig, setActiveConfig] = useState<keyof typeof CONFIG_FILES>('github');
  const [isSimulating, setIsSimulating] = useState(false);

  const startSimulation = async () => {
    setIsSimulating(true);
    setSteps(INITIAL_STEPS.map(s => ({ ...s, status: 'pending' })));

    for (let i = 0; i < INITIAL_STEPS.length; i++) {
        setSteps(prev => prev.map((s, idx) => idx === i ? { ...s, status: 'running' } : s));
        await new Promise(r => setTimeout(r, 1500));
        setSteps(prev => prev.map((s, idx) => idx === i ? { ...s, status: 'success', duration: (Math.random() * 5 + 2).toFixed(1) + 's' } : s));
    }
    setIsSimulating(false);
  };

  return (
    <div className="min-h-screen bg-bg p-6 flex flex-col gap-6 font-sans">
      {/* Header */}
      <header className="flex justify-between items-center px-2">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center shadow-lg shadow-accent-blue/20">
            <Activity className="w-5 h-5 text-bg" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-text-main">Pipeline Pro</h1>
            <p className="text-[10px] text-text-muted uppercase font-semibold tracking-wider">DevOps Central / GitHub Actions</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
           <div className={`px-3 py-1 rounded-full border text-[10px] font-bold tracking-wider uppercase transition-colors
              ${isSimulating ? 'bg-accent-blue/10 border-accent-blue text-accent-blue animate-pulse' : 'bg-green-500/10 border-green-500 text-green-500'}`}>
              {isSimulating ? 'Pipeline in Progress' : 'System Ready'}
           </div>
        </div>
      </header>

      {/* Bento Grid */}
      <main className="grid grid-cols-1 md:grid-cols-4 grid-rows-none md:grid-rows-3 gap-5 flex-grow">
        
        {/* Pipeline Visualizer - Span 3 cols, 1 row */}
        <section className="md:col-span-3 bg-card border border-border rounded-2xl p-6 flex flex-col shadow-xl shadow-black/20">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-[11px] font-bold uppercase tracking-wider text-text-muted">Workflow Visualization: main_deployment.yml</h2>
            <div className="flex items-center gap-4 text-[10px] text-text-muted font-mono">
              <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-accent-green" /> Success</span>
              <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-accent-blue" /> Running</span>
            </div>
          </div>

          <div className="relative flex justify-between items-center px-4 md:px-12 flex-grow">
            {/* Connection Line */}
            <div className="absolute top-1/2 left-16 right-16 h-0.5 bg-border -translate-y-1/2 z-0" />
            
            {steps.map((step) => (
              <div key={step.id} className="relative z-10 flex flex-col items-center gap-3">
                <motion.div 
                  layout
                  className={`w-10 h-10 rounded-full border-2 flex items-center justify-center font-bold text-sm transition-all duration-500
                    ${step.status === 'success' ? 'bg-accent-green/10 border-accent-green text-accent-green' : 
                      step.status === 'running' ? 'bg-accent-blue/10 border-accent-blue text-accent-blue animate-pulse shadow-lg shadow-accent-blue/20' : 
                      'bg-card border-border text-text-muted'}`}
                >
                  {step.status === 'success' ? '✓' : step.status === 'running' ? '●' : '-'}
                </motion.div>
                <span className={`text-[10px] font-bold whitespace-nowrap transition-colors ${step.status === 'running' ? 'text-accent-blue' : 'text-text-main'}`}>
                  {step.name}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Start/Trigger Card - Span 1 col, 1 row */}
        <section className="md:col-span-1 bg-card border border-border rounded-2xl p-6 flex flex-col justify-between shadow-xl shadow-black/20">
          <div>
            <h2 className="text-[11px] font-bold uppercase tracking-wider text-text-muted mb-4">Pipeline Trigger</h2>
            <div className="flex flex-col gap-1 mb-6">
              <span className="text-accent-blue font-mono text-sm tracking-tight flex items-center gap-2">
                <GitBranch className="w-4 h-4" /> 7c9a1f2
              </span>
              <span className="text-sm font-medium text-text-main leading-snug">feat: push bento grid redesign to prod</span>
              <p className="text-[10px] text-text-muted mt-1 underline">vtu26136 • active now</p>
            </div>
          </div>
          <button 
            onClick={startSimulation}
            disabled={isSimulating}
            className={`w-full py-3 rounded-xl uppercase text-xs font-bold tracking-widest transition-all
              ${isSimulating 
                ? 'bg-border text-text-muted cursor-not-allowed' 
                : 'bg-accent-blue text-bg hover:scale-[1.02] active:scale-95 shadow-lg shadow-accent-blue/20'}`}
          >
            {isSimulating ? 'Running...' : 'Deploy Now'}
          </button>
        </section>

        {/* Logs Card - Span 3 cols, 2 rows */}
        <section className="md:col-span-3 md:row-span-2 bg-black border border-border rounded-2xl p-6 flex flex-col shadow-xl shadow-black/20 overflow-hidden">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-[11px] font-bold uppercase tracking-wider text-accent-green">Real-time Runner logs: ais-production-executor</h2>
            <div className="flex gap-1.5">
               <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
               <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
               <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
            </div>
          </div>
          <div className="flex-grow font-mono text-xs text-[#a5b4fc] overflow-y-auto space-y-2 scrollbar-hide">
            <div className="flex gap-4 opacity-50"><span className="text-[#6366f1]">[14:22:01]</span> INITIALIZING RUNNER CONTEXT...</div>
            <div className="flex gap-4 opacity-50"><span className="text-[#6366f1]">[14:22:02]</span> LOADING REPOSITORY SECRETS...</div>
            
            {steps[0].status === 'success' && <div className="flex gap-4"><span className="text-[#6366f1]">[14:22:04]</span> SUCCESS: CHECKED OUT @MAIN</div>}
            {steps[1].status === 'running' && <div className="flex gap-4 animate-pulse"><span className="text-[#6366f1]">[14:22:05]</span> RUNNING ESLINT ANALYSIS...</div>}
            {steps[1].status === 'success' && <div className="flex gap-4 text-accent-green"><span className="text-[#6366f1]">[14:22:07]</span> PASS: LINTING CHECKS READY</div>}
            
            {steps[2].status === 'running' && (
              <>
                <div className="flex gap-4"><span className="text-[#6366f1]">[14:22:08]</span> EXECUTING VITEST SUITE...</div>
                <div className="flex gap-4 opacity-70">  PASS  src/pipeline.test.ts</div>
              </>
            )}
            {steps[2].status === 'success' && <div className="flex gap-4 text-accent-green"><span className="text-[#6366f1]">[14:22:15]</span> UNIT TESTS: 100% SUCCESS RATE</div>}
            
            {isSimulating && steps[4].status === 'pending' && <div className="animate-pulse">_</div>}
            
            {!isSimulating && steps[4].status === 'success' && (
              <div className="pt-4 border-t border-white/10 text-accent-green font-bold text-center">
                PIPELINE EXECUTION FINISHED SUCCESSFULLY
              </div>
            )}
          </div>
        </section>

        {/* Integration Selector - Span 1 col, 1 row */}
        <section className="md:col-span-1 bg-card border border-border rounded-2xl p-6 flex flex-col shadow-xl shadow-black/20">
          <h2 className="text-[11px] font-bold uppercase tracking-wider text-text-muted mb-4">Pipeline Config</h2>
          <div className="flex flex-col gap-2">
            {(Object.keys(CONFIG_FILES) as Array<keyof typeof CONFIG_FILES>).map((tool) => {
              const Icon = CONFIG_FILES[tool].icon;
              return (
                <button
                  key={tool}
                  onClick={() => setActiveConfig(tool)}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all
                    ${activeConfig === tool ? 'bg-accent-blue/10 border-accent-blue text-accent-blue' : 'bg-transparent border-border text-text-muted hover:border-text-muted'}`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-[10px] uppercase font-bold tracking-widest">{tool}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Performance/Stats - Span 1 col, 1 row */}
        <section className="md:col-span-1 bg-card border border-border rounded-2xl p-6 flex flex-col justify-between shadow-xl shadow-black/20">
          <h2 className="text-[11px] font-bold uppercase tracking-wider text-text-muted mb-4">Performance Metrics</h2>
          <div className="space-y-3">
             <div className="flex justify-between items-center text-xs">
               <span className="text-text-muted">Avg. Build</span>
               <span className="font-bold">4m 12s</span>
             </div>
             <div className="flex justify-between items-center text-xs">
               <span className="text-text-muted">Stability</span>
               <span className="font-bold text-accent-green">98.4%</span>
             </div>
             <div className="flex justify-between items-center text-xs">
               <span className="text-text-muted">Deployments</span>
               <span className="font-bold">12/day</span>
             </div>
          </div>
          <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
             <div className="flex items-center gap-2">
               <ShieldCheck className="w-4 h-4 text-accent-blue opacity-50" />
               <span className="text-[10px] text-text-muted font-bold uppercase tracking-tighter">Secrets: Vaulted</span>
             </div>
             <ChevronRight className="w-4 h-4 text-text-muted hover:text-text-main cursor-pointer" />
          </div>
        </section>

      </main>
    </div>
  );
}
