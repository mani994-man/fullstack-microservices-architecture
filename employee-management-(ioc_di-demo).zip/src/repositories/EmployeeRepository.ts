import { Component } from '../lib/di';
import { Employee } from '../types/employee';

@Component('employeeRepository')
export class EmployeeRepository {
  private employees: Employee[] = [
    { id: '1', name: 'John Doe', position: 'Software Engineer', department: 'Engineering', salary: 85000 },
    { id: '2', name: 'Jane Smith', position: 'Product Manager', department: 'Product', salary: 95000 },
    { id: '3', name: 'Bob Johnson', position: 'Designer', department: 'Design', salary: 75000 },
  ];

  findAll(): Employee[] {
    return [...this.employees];
  }

  findById(id: string): Employee | undefined {
    return this.employees.find(e => e.id === id);
  }

  save(employee: Employee): Employee {
    const index = this.employees.findIndex(e => e.id === employee.id);
    if (index !== -1) {
      this.employees[index] = employee;
    } else {
      this.employees.push(employee);
    }
    return employee;
  }

  delete(id: string): void {
    this.employees = this.employees.filter(e => e.id !== id);
  }
}
