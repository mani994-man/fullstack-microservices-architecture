import { Component, Autowired } from '../lib/di';
import { EmployeeRepository } from '../repositories/EmployeeRepository';
import { Employee } from '../types/employee';

@Component('employeeService')
export class EmployeeService {
  @Autowired('employeeRepository')
  private repository!: EmployeeRepository;

  getAllEmployees(): Employee[] {
    return this.repository.findAll();
  }

  getEmployeeById(id: string): Employee | undefined {
    return this.repository.findById(id);
  }

  addEmployee(employee: Omit<Employee, 'id'>): Employee {
    const newEmployee: Employee = {
      ...employee,
      id: Math.random().toString(36).substr(2, 9)
    };
    return this.repository.save(newEmployee);
  }

  updateEmployee(employee: Employee): Employee {
    return this.repository.save(employee);
  }

  removeEmployee(id: string): void {
    this.repository.delete(id);
  }

  calculateAverageSalary(): number {
    const employees = this.repository.findAll();
    if (employees.length === 0) return 0;
    const total = employees.reduce((acc, curr) => acc + curr.salary, 0);
    return total / employees.length;
  }
}
