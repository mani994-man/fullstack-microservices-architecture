import { useState, useEffect, useMemo, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, Edit2, Users, Search, X, Check, Activity, Terminal, Layers, Cpu } from 'lucide-react';
import { BeanFactory } from './lib/di';
import { EmployeeService } from './services/EmployeeService';
import { Employee } from './types/employee';

// Import services to trigger @Component registration
import './repositories/EmployeeRepository';
import './services/EmployeeService';

export default function App() {
  const employeeService = useMemo(() => BeanFactory.getBean<EmployeeService>('employeeService'), []);

  const [employees, setEmployees] = useState<Employee[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  
  const [formData, setFormData] = useState<Omit<Employee, 'id'>>({
    name: '',
    position: '',
    department: '',
    salary: 50000
  });

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-4), `[INFO] ${new Date().toLocaleTimeString()} - ${msg}`]);
  };

  const refreshData = () => {
    setEmployees(employeeService.getAllEmployees());
  };

  useEffect(() => {
    refreshData();
    addLog("BeanFactory initialized successfully.");
    addLog("Dependencies autowired for 'employeeService'.");
  }, [employeeService]);

  const filteredEmployees = employees.filter(e => 
    e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const averageSalary = employees.reduce((acc, curr) => acc + curr.salary, 0) / (employees.length || 1);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (editingEmployee) {
      employeeService.updateEmployee({ ...formData, id: editingEmployee.id });
      addLog(`Updated record for '${formData.name}'`);
    } else {
      const newEmp = employeeService.addEmployee(formData);
      addLog(`Created new bean 'emp-${newEmp.id.slice(0, 4)}' for '${formData.name}'`);
    }
    setIsModalOpen(false);
    setEditingEmployee(null);
    setFormData({ name: '', position: '', department: '', salary: 50000 });
    refreshData();
  };

  const handleDelete = (id: string, name: string) => {
    employeeService.removeEmployee(id);
    addLog(`Deregistered bean at memory address '${id}'`);
    refreshData();
  };

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee);
    setFormData({
      name: employee.name,
      position: employee.position,
      department: employee.department,
      salary: employee.salary
    });
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen p-8 max-w-[1200px] mx-auto flex flex-col gap-8">
      {/* Header Area */}
      <header className="flex justify-between items-end border-b-2 border-[#1A1A1A] pb-4">
        <div>
          <h1 className="text-[32px] font-[800] tracking-tighter uppercase leading-none">Employee Module</h1>
          <p className="text-[14px] text-[#636E72] font-medium mt-1">Spring IoC & Dependency Injection Management Console</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-[11px] font-bold text-[#00B894] border border-[#00B894] px-3 py-1 bg-[#00B894]/5 uppercase">@SpringFramework 6.1</div>
          <button 
            onClick={() => { setEditingEmployee(null); setFormData({ name: '', position: '', department: '', salary: 50000 }); setIsModalOpen(true); }}
            className="bg-[#1A1A1A] text-white px-5 py-2 text-[12px] font-extrabold uppercase hover:translate-y-[-2px] hover:shadow-[4px_4px_0px_#6C5CE7] transition-all"
          >
            Add Record
          </button>
        </div>
      </header>

      {/* Bento Grid */}
      <main className="grid grid-cols-4 grid-rows-[repeat(3,minmax(200px,auto))] gap-4 flex-grow">
        
        {/* Card 1: Bean Inventory */}
        <div className="bento-card col-span-1 row-span-2">
          <div className="card-title">BeanFactory Inventory <Layers className="w-3.5 h-3.5" /></div>
          <div className="space-y-1 mt-2">
            {[
              { name: 'employeeController', type: 'Singleton' },
              { name: 'employeeService', type: 'Singleton' },
              { name: 'employeeRepository', type: 'Singleton' },
              { name: 'dataSource', type: 'Singleton' },
              { name: 'applicationContext', type: 'Context' },
              { name: 'auditAspect', type: 'Prototype' },
            ].map((bean, i) => (
              <div key={i} className="flex justify-between py-2 border-b border-[#F0F0F0] font-mono text-[11px]">
                <span className="text-[#1A1A1A]">{bean.name}</span>
                <span className="text-[#6C5CE7] opacity-70 italic">{bean.type}</span>
              </div>
            ))}
          </div>
          <div className="mt-auto pt-4">
            <span className="tag-flat">Status: context_up</span>
          </div>
        </div>

        {/* Card 2: Main Directory (The Table) */}
        <div className="bento-card col-span-2 row-span-2 overflow-hidden flex flex-col">
          <div className="card-title">
            Active Employee Directory
            <div className="relative group">
              <Search className="absolute left-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#636E72]" />
              <input 
                className="pl-5 bg-transparent border-none focus:ring-0 text-[11px] placeholder:text-[#636E72]/40 p-0 uppercase" 
                placeholder="Find Staff..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="overflow-y-auto flex-grow -mx-6 px-6">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-[#1A1A1A]">
                  <th className="text-[10px] text-[#636E72] py-2 text-left font-extrabold pb-3">ID REF</th>
                  <th className="text-[10px] text-[#636E72] py-2 text-left font-extrabold pb-3">FULL NAME</th>
                  <th className="text-[10px] text-[#636E72] py-2 text-left font-extrabold pb-3">DEPT</th>
                  <th className="text-[10px] text-[#636E72] py-2 text-right font-extrabold pb-3">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F0F0F0]">
                <AnimatePresence mode="popLayout">
                  {filteredEmployees.map((emp) => (
                    <motion.tr 
                      key={emp.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="group transition-colors"
                    >
                      <td className="text-[11px] font-mono text-[#636E72] py-4">{emp.id.slice(0, 7)}</td>
                      <td className="text-[13px] font-extrabold py-4">{emp.name}</td>
                      <td className="py-4">
                        <span className="badge-flat !bg-[#F0F0F0] !text-[#1A1A1A] !p-[1px_4px]">{emp.department.slice(0, 3)}</span>
                      </td>
                      <td className="py-4 text-right">
                        <div className="flex justify-end gap-1 opacity-10 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => handleEdit(emp)} className="p-1 hover:text-[#6C5CE7]"><Edit2 className="w-3.5 h-3.5"/></button>
                          <button onClick={() => handleDelete(emp.id, emp.name)} className="p-1 hover:text-[#D63031]"><Trash2 className="w-3.5 h-3.5"/></button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </div>

        {/* Card 3: Memory Footprint (Avg Salary) */}
        <div className="bento-card col-span-1 row-span-1">
          <div className="card-title">Economic Load <Activity className="w-3.5 h-3.5"/></div>
          <div className="metric-value mt-auto">
            {Math.round(averageSalary / 1000)}<span className="text-[16px] text-[#636E72] font-medium tracking-tight whitespace-nowrap"> K/AVG</span>
          </div>
          <p className="text-[11px] mt-4 text-[#636E72] font-semibold">In-memory ArrayList storage active.</p>
        </div>

        {/* Card 4: DI Flow Analysis */}
        <div className="bento-card col-span-1 row-span-2">
          <div className="card-title">DI Flow Analysis <Cpu className="w-3.5 h-3.5"/></div>
          <div className="space-y-4 mt-2">
            {[
              { label: '@Component Scan', detail: 'Discovered candidate classes', annotation: '@Component' },
              { label: 'Instantiation', detail: 'Default constructor used', annotation: 'NEW' },
              { label: '@Autowired Wiring', detail: 'Repository injected into Service', annotation: '@Autowired' },
            ].map((step, i) => (
              <div key={i} className="bg-[#FAFAFA] border-l-4 border-[#6C5CE7] p-3">
                <div className="text-[11px] font-extrabold">
                  <span className="text-[#D63031]">{step.annotation}</span> {step.label}
                </div>
                <div className="text-[10px] text-[#636E72] font-semibold mt-1">{step.detail}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 5: Record Count */}
        <div className="bento-card col-span-1 row-span-1">
          <div className="card-title">Instance Count <Users className="w-3.5 h-3.5"/></div>
          <div className="metric-value mt-auto">{employees.length}</div>
          <div className="bg-[#6C5CE7] h-1 w-[40%] mt-4"></div>
        </div>

        {/* Card 6: Console Output */}
        <div className="bento-card col-span-2 row-span-1 bg-[#1A1A1A] !border-none text-[#F8F9FA]">
          <div className="card-title !text-white/40">Console Output <Terminal className="w-3.5 h-3.5"/></div>
          <div className="font-mono text-[11px] space-y-1 mt-2 overflow-y-auto">
            {logs.map((log, i) => (
              <div key={i} className="flex gap-2">
                <span className="text-[#00B894]">&gt;</span>
                <span className="opacity-80">{log}</span>
              </div>
            ))}
            <div className="flex gap-2 text-[#00B894] font-bold">
              <span>&gt;</span>
              <motion.span 
                animate={{ opacity: [1, 0] }}
                transition={{ repeat: Infinity, duration: 0.8 }}
                className="w-2 h-4 bg-[#00B894] inline-block mt-0.5"
              />
              <span className="ml-1 uppercase">Ready for context update</span>
            </div>
          </div>
        </div>

      </main>

      {/* Bento-style Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60" onClick={() => setIsModalOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 30 }}
              className="relative bg-white border-[3px] border-[#1A1A1A] w-full max-w-md p-10 shadow-[8px_8px_0px_#1A1A1A]"
            >
              <div className="flex justify-between items-start mb-8">
                <h2 className="text-[20px] font-[900] uppercase tracking-tighter">{editingEmployee ? 'Modify Bean' : 'Register New Bean'}</h2>
                <button onClick={() => setIsModalOpen(false)} className="hover:rotate-90 transition-transform"><X className="w-6 h-6"/></button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-[10px] font-extrabold uppercase text-[#636E72] mb-2">Member Name</label>
                  <input required className="w-full border-2 border-[#1A1A1A] px-4 py-3 text-[13px] font-bold focus:shadow-[4px_4px_0px_#6C5CE7] transition-all outline-none"
                    value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-extrabold uppercase text-[#636E72] mb-2">Role</label>
                    <input required className="w-full border-2 border-[#1A1A1A] px-4 py-3 text-[13px] font-medium outline-none"
                      value={formData.position} onChange={(e) => setFormData({...formData, position: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-[10px] font-extrabold uppercase text-[#636E72] mb-2">Dept</label>
                    <select required className="w-full border-2 border-[#1A1A1A] px-4 py-3 text-[13px] font-medium outline-none bg-white"
                      value={formData.department} onChange={(e) => setFormData({...formData, department: e.target.value})}>
                      <option value="">Select...</option>
                      {['Engineering', 'Product', 'Design', 'Marketing', 'HR'].map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold uppercase text-[#636E72] mb-2">Annual Budget ($)</label>
                  <input required type="number" className="w-full border-2 border-[#1A1A1A] px-4 py-3 text-[13px] font-bold outline-none"
                    value={formData.salary} onChange={(e) => setFormData({...formData, salary: parseInt(e.target.value)})} />
                </div>

                <button type="submit" className="w-full bg-[#1A1A1A] text-white py-4 font-black uppercase text-[12px] tracking-widest hover:bg-[#6C5CE7] transition-colors flex items-center justify-center gap-2">
                  <Check className="w-4 h-4" /> {editingEmployee ? 'Commit Changes' : 'Initialize Instance'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
