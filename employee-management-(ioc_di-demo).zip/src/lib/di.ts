/**
 * A simple BeanFactory implementation to demonstrate Dependency Injection and Inversion of Control.
 * This mimics the core functionality of Spring's BeanFactory.
 */
class BeanFactoryContainer {
  private beans: Map<string, any> = new Map();
  private beanDefinitions: Map<string, any> = new Map();

  /**
   * Register a class definition as a bean.
   */
  register(name: string, constructor: any) {
    this.beanDefinitions.set(name, constructor);
    console.log(`[BeanFactory] Registered bean: ${name}`);
  }

  /**
   * Get an instance of a bean. Lazily creates the bean if it doesn't exist.
   */
  getBean<T>(name: string): T {
    if (this.beans.has(name)) {
      return this.beans.get(name);
    }

    const Constructor = this.beanDefinitions.get(name);
    if (!Constructor) {
      throw new Error(`[BeanFactory] No bean named '${name}' found.`);
    }

    // Create the instance
    const instance = new Constructor();
    this.beans.set(name, instance);
    
    // Support for circular dependencies would go here in a full implementation,
    // but for this demo, we keep it simple.
    
    console.log(`[BeanFactory] Instantiated bean: ${name}`);
    return instance;
  }
}

export const BeanFactory = new BeanFactoryContainer();

/**
 * simulated @Component annotation
 */
export function Component(name: string) {
  return function (constructor: any) {
    BeanFactory.register(name, constructor);
  };
}

/**
 * simulated @Autowired annotation
 */
export function Autowired(beanName: string) {
  return function (target: any, propertyKey: string) {
    // We use a getter to lazily fetch the bean from the factory
    Object.defineProperty(target, propertyKey, {
      get: () => BeanFactory.getBean(beanName),
      enumerable: true,
      configurable: true,
    });
  };
}
