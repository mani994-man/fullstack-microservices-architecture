/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Users, 
  CheckSquare, 
  Activity, 
  Cpu, 
  Network, 
  Box, 
  ArrowRight, 
  RefreshCw,
  AlertCircle,
  Database,
  Lock,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface Task {
  id: string;
  title: string;
  status: string;
  userId: string;
}

interface ServiceStatus {
  name: string;
  status: 'online' | 'offline' | 'degraded';
  latency: number;
  requests: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'architecture' | 'users' | 'tasks'>('architecture');
  const [users, setUsers] = useState<User[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [packets, setPackets] = useState<{id: number, from: string, to: string}[]>([]);

  // Simulation of metrics
  const [userStatus, setUserStatus] = useState<ServiceStatus>({
    name: 'User Service',
    status: 'online',
    latency: 12,
    requests: 1240
  });

  const [taskStatus, setTaskStatus] = useState<ServiceStatus>({
    name: 'Task Service',
    status: 'online',
    latency: 18,
    requests: 890
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    addLog('Initiating Gateway aggregation request...');
    sendPacket('gateway', 'aggregator');

    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      setUsers(data.data.users);
      setTasks(data.data.tasks);
      addLog('Success: Aggregated data received from 2 services.');
    } catch (error) {
      addLog('Error: Failed to fetch from microservices gateway.');
    } finally {
      setLoading(false);
    }
  };

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 19)]);
  };

  const sendPacket = (from: string, to: string) => {
    const id = Date.now();
    setPackets(prev => [...prev, { id, from, to }]);
    setTimeout(() => {
      setPackets(prev => prev.filter(p => p.id !== id));
    }, 1500);
  };

  const ServiceCard = ({ service, icon: Icon }: { service: ServiceStatus, icon: any }) => (
    <div className="bg-white/5 border border-white/10 p-6 rounded-sm flex flex-col gap-4 group hover:bg-white/10 transition-all duration-300">
      <div className="flex justify-between items-start">
        <div className="p-2 text-gold">
          <Icon size={22} />
        </div>
        <div className="flex items-center gap-2 px-2 py-0.5 border border-gold/30 rounded-full">
          <div className={`w-1.5 h-1.5 rounded-full ${service.status === 'online' ? 'bg-[#4CAF50] shadow-[0_0_8px_rgba(76,175,80,0.5)]' : 'bg-red-500'}`} />
          <span className="text-[9px] uppercase font-mono tracking-widest text-gold/80 italic">{service.status}</span>
        </div>
      </div>
      <div>
        <h3 className="text-lg font-serif text-white group-hover:text-gold transition-colors">{service.name}</h3>
        <p className="text-[10px] text-white/40 uppercase tracking-widest mt-1">Micro-instance ID: {Math.random().toString(36).substr(2, 6).toUpperCase()}</p>
      </div>
      <div className="grid grid-cols-2 gap-4 mt-2">
        <div>
          <p className="text-[9px] text-gold/60 uppercase tracking-[0.15em] mb-1">Inbound</p>
          <p className="text-xl font-light text-white font-mono">{service.requests} req</p>
        </div>
        <div>
          <p className="text-[9px] text-gold/60 uppercase tracking-[0.15em] mb-1">Latency</p>
          <p className="text-xl font-light text-white font-mono">{service.latency} ms</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark text-white/80 font-sans selection:bg-gold/30">
      {/* Dynamic Header */}
      <header className="px-10 py-8 border-b border-gold/15 flex justify-between items-end backdrop-blur-3xl sticky top-0 z-[100] bg-dark/80">
        <div>
          <h1 className="text-4xl font-serif text-gold tracking-tight lowercase">
            architectural <span className="text-white/40">refractor</span>
          </h1>
          <p className="text-[11px] text-white/30 uppercase tracking-[0.25em] mt-2 font-mono flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-gold/50 animate-pulse" /> active migration session: PRJ-8829
          </p>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="text-[9px] text-white/40 uppercase tracking-[0.2em] mb-1">Gateway Cluster</span>
            <div className="px-4 py-1.5 border border-gold/40 rounded-full text-[10px] text-gold font-medium uppercase tracking-widest bg-gold/5">
              Optimum Health
            </div>
          </div>
          <button 
            onClick={fetchData}
            disabled={loading}
            className="p-3 bg-white/5 text-gold border border-gold/20 rounded-sm hover:bg-gold/10 transition-all disabled:opacity-30 group"
          >
            <RefreshCw size={20} className={loading ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-700'} />
          </button>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto p-12 grid grid-cols-[320px_1fr] gap-16 min-h-[calc(100vh-140px)]">
        
        {/* Sidebar: Monolith Node and Logic */}
        <aside className="flex flex-col gap-10">
          <div className="bg-white/[0.03] border border-white/10 p-8 rounded-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 px-2 py-0.5 bg-safety text-black text-[9px] font-bold tracking-widest">
              DEPRECATED
            </div>
            <span className="text-[10px] text-gold uppercase tracking-[0.2em] mb-6 block font-medium">Source Monolith</span>
            <h2 className="text-2xl font-serif text-white tracking-wide">EnterpriseCore_v12</h2>
            <p className="text-xs text-white/50 mt-4 leading-relaxed italic">System complexity is currently rated at 84.2/100, signifying high technical debt.</p>
            
            <div className="grid grid-cols-2 gap-6 mt-10">
              <div>
                <p className="text-[9px] text-gold/60 uppercase tracking-widest mb-1 font-mono">Coupling Index</p>
                <p className="text-xl font-light text-white font-mono">0.92</p>
              </div>
              <div>
                <p className="text-[9px] text-gold/60 uppercase tracking-widest mb-1 font-mono">Deploy Index</p>
                <p className="text-xl font-light text-safety font-mono">RISK</p>
              </div>
            </div>
          </div>

          <div className="p-8 border-l border-gold/30 bg-gold/5 space-y-6">
            <span className="text-[10px] text-gold uppercase tracking-[0.2em] block font-medium">Transformation Engine</span>
            <p className="text-xs text-white/50 leading-loose">
              Targeting loose coupling through event-driven messaging. Service extraction aims to reach 95%+ core responsibility focus per domain.
            </p>
            <div className="flex items-center gap-2 group cursor-pointer">
              <span className="text-[10px] text-white/70 group-hover:text-gold transition-colors font-mono">Isolation strategies enforced</span>
              <ArrowRight size={12} className="text-gold group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Service Mesh Mini Dashboard */}
          <div className="bg-white/5 border border-white/10 p-8 rounded-sm space-y-4">
             <span className="text-[10px] text-gold uppercase tracking-[0.2em] block font-medium">Network Mesh</span>
             <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-white/40">Propagation</span>
                <span className="text-white font-light">4ms</span>
             </div>
             <div className="w-full h-[1px] bg-white/10 relative overflow-hidden">
                <motion.div 
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-0 bg-gold/50 w-20"
                />
             </div>
             <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-white/40">Packet Loss</span>
                <span className="text-white font-light">0.002%</span>
             </div>
          </div>
        </aside>

        {/* Central Canvas Visualizer and Data View */}
        <section className="flex flex-col gap-12">
          
          {/* Visualization Tab Toggle */}
          <div className="flex items-center gap-2 p-1 bg-white/5 border border-white/10 rounded-sm w-fit">
            {[
              { id: 'architecture', label: 'Migration Topology', icon: Cpu },
              { id: 'users', label: 'Identity Svc', icon: Users },
              { id: 'tasks', label: 'Ledger Svc', icon: CheckSquare },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-3 px-6 py-2 rounded-sm text-xs font-mono transition-all duration-300 ${
                  activeTab === tab.id 
                    ? 'bg-gold text-black italic' 
                    : 'text-white/40 hover:text-white hover:bg-white/5'
                }`}
              >
                <tab.icon size={14} />
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            {activeTab === 'architecture' ? (
              <motion.div 
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="bg-white/[0.02] border border-white/5 rounded-sm p-20 min-h-[500px] flex items-center justify-center relative overflow-hidden"
              >
                {/* Visualizer Mesh */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #D4AF37 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

                <div className="relative z-10 flex flex-col items-center gap-24">
                  {/* API Gateway Cluster */}
                  <div className="flex flex-col items-center gap-4">
                    <motion.div 
                      whileHover={{ scale: 1.02 }}
                      className="w-48 h-48 bg-dark border-2 border-gold/40 rounded-sm flex flex-col items-center justify-center gap-3 shadow-[0_0_80px_rgba(212,175,55,0.05)]"
                    >
                      <Server size={32} className="text-gold" />
                      <div className="flex flex-col items-center">
                        <span className="text-[11px] font-serif text-white uppercase tracking-widest">Entry Gateway</span>
                        <span className="text-[9px] font-mono text-gold px-2 py-0.5 bg-gold/10 mt-1">SECURE</span>
                      </div>
                    </motion.div>
                  </div>

                  <div className="flex gap-48 items-center">
                    {/* User Extracted Domain */}
                    <div className="flex flex-col items-center gap-6">
                      <div className="w-28 h-28 bg-white/5 border border-white/10 rounded-sm flex items-center justify-center text-gold/70 group-hover:text-gold transition-colors">
                        <Users size={32} strokeWidth={1} />
                      </div>
                      <span className="text-[9px] font-mono tracking-[0.2em] text-white/50 uppercase">Identity.Domain</span>
                    </div>

                    {/* Task Extracted Domain */}
                    <div className="flex flex-col items-center gap-6">
                      <div className="w-28 h-28 bg-white/5 border border-white/10 rounded-sm flex items-center justify-center text-gold/70 group-hover:text-gold transition-colors">
                        <CheckSquare size={32} strokeWidth={1} />
                      </div>
                      <span className="text-[9px] font-mono tracking-[0.2em] text-white/50 uppercase">Ledger.Domain</span>
                    </div>
                  </div>
                </div>

                {/* Micro-Packet Transmissions */}
                <AnimatePresence>
                  {packets.map(packet => (
                    <motion.div
                      key={packet.id}
                      initial={{ x: 0, y: 0, opacity: 0 }}
                      animate={{ 
                        y: packet.to === 'aggregator' ? 50 : 250,
                        opacity: 1, 
                        scale: [1, 1.5, 1]
                      }}
                      exit={{ opacity: 0 }}
                      className="absolute w-1 h-1 bg-gold rounded-full shadow-[0_0_12px_#D4AF37] z-50 pointer-events-none"
                    />
                  ))}
                </AnimatePresence>

                {/* Status Bar for Canvas */}
                <div className="absolute bottom-10 left-10 flex gap-8">
                  <div className="flex items-center gap-2">
                    <div className="w-[1px] h-3 bg-gold" />
                    <span className="text-[9px] font-mono text-white/40 uppercase">Active Ingress</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-[1px] h-3 bg-gold/30" />
                    <span className="text-[9px] font-mono text-white/40 uppercase">Isolating Path</span>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="grid grid-cols-2 gap-8">
                 <ServiceCard service={activeTab === 'users' ? userStatus : taskStatus} icon={activeTab === 'users' ? Users : CheckSquare} />
                 
                 <div className="bg-white/5 border border-white/10 p-8 flex flex-col justify-center gap-6">
                    <span className="text-[10px] text-gold uppercase tracking-[0.2em] block font-medium">Database Persistence</span>
                    <div className="flex items-center gap-4">
                       <Database className="text-white/40" size={40} strokeWidth={1} />
                       <div>
                          <p className="text-sm font-serif text-white">Postgres Integration</p>
                          <p className="text-[10px] text-white/40 font-mono mt-1">ACID COMPLIANT . ISOLATED</p>
                       </div>
                    </div>
                    <div className="pt-6 border-t border-white/10">
                       <p className="text-[11px] text-white/50 italic leading-relaxed">
                         "Database-per-service" principle ensures no hidden coupling at the storage layer. Propagation delay simulated at &lt; 2ms.
                       </p>
                    </div>
                 </div>

                 <div className="col-span-2 mt-4 bg-dark border border-white/5 p-8">
                    <table className="w-full text-left font-mono">
                      <thead>
                        <tr className="border-b border-white/10 text-gold/60 uppercase text-[9px] tracking-widest italic font-serif">
                           <th className="pb-4 px-2">Registry ID</th>
                           <th className="pb-4 px-2">{activeTab === 'users' ? 'Entity Name' : 'Process Title'}</th>
                           <th className="pb-4 px-2 tracking-normal">Status/Meta</th>
                           <th className="pb-4 px-2 text-right italic font-serif">SR Score</th>
                        </tr>
                      </thead>
                      <tbody>
                        {activeTab === 'users' ? users.map(user => (
                          <tr key={user.id} className="border-b border-white/5 last:border-0 text-xs hover:bg-white/5 transition-colors group">
                            <td className="py-5 px-2 text-white/40 group-hover:text-gold transition-colors font-mono tracking-tighter">[ID-{user.id}]</td>
                            <td className="py-5 px-2 text-white font-serif text-base">{user.name}</td>
                            <td className="py-5 px-2 text-white/50">{user.email}</td>
                            <td className="py-5 px-2 text-right">
                               <span className="text-gold font-mono">94%</span>
                            </td>
                          </tr>
                        )) : tasks.map(task => (
                          <tr key={task.id} className="border-b border-white/5 last:border-0 text-xs hover:bg-white/5 transition-colors group">
                            <td className="py-5 px-2 text-white/40 group-hover:text-gold transition-colors font-mono tracking-tighter">[TK-{task.id}]</td>
                            <td className="py-5 px-2 text-white font-serif text-base">{task.title}</td>
                            <td className="py-5 px-2">
                               <span className="text-[10px] px-2 py-0.5 border border-white/10 text-white/60">
                                 {task.status.toUpperCase()}
                               </span>
                            </td>
                            <td className="py-5 px-2 text-right">
                               <span className="text-gold font-mono">88%</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                 </div>
              </div>
            )}
          </div>
        </section>

      </main>

      {/* Persistent System Log Footer */}
      <footer className="px-10 py-6 border-t border-white/5 flex justify-between items-center bg-black/40 backdrop-blur-xl">
        <div className="flex items-center gap-4 text-[11px] font-mono overflow-hidden max-w-[70%]">
          <span className="text-gold/60 shrink-0">SYSTEM LOG //</span>
          <AnimatePresence mode="wait">
            <motion.div
              key={logs[0]}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-white/40 truncate"
            >
              {logs[0] || "[SYS] INITIALIZING REFRAC SESSION..."}
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="flex items-center gap-6">
           <div className="flex items-center gap-2">
             <span className="text-[10px] text-white/30 uppercase tracking-widest">Isolated Domains</span>
             <span className="text-[11px] text-gold font-mono">02</span>
           </div>
           <div className="text-[11px] text-gold uppercase tracking-[0.2em] font-medium italic">
             MIGRATION PROGRESS: 64%
           </div>
        </div>
      </footer>
    </div>
  );

}

