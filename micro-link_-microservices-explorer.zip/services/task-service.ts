import express from 'express';

const app = express();
app.use(express.json());

// Simulated DB
const tasks = [
  { id: '101', title: 'System Architecture', status: 'Completed', userId: '1' },
  { id: '102', title: 'Database Migration', status: 'In Progress', userId: '2' },
  { id: '103', title: 'Security Audit', status: 'Pending', userId: '1' },
  { id: '104', title: 'CI/CD Pipeline', status: 'Active', userId: '3' },
];

app.get('/', (req, res) => {
  console.log('[Task Service] GET /');
  res.json({ service: 'Task Service', status: 'online', tasks });
});

app.get('/user/:userId', (req, res) => {
  const userTasks = tasks.filter(t => t.userId === req.params.userId);
  res.json(userTasks);
});

export default app;
