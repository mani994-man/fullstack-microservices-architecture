import express from 'express';

const app = express();
app.use(express.json());

// Simulated DB
const users = [
  { id: '1', name: 'Alice Smith', email: 'alice@example.com', role: 'Architect' },
  { id: '2', name: 'Bob Johnson', email: 'bob@example.com', role: 'Developer' },
  { id: '3', name: 'Charlie Brown', email: 'charlie@example.com', role: 'DevOps' },
];

app.get('/', (req, res) => {
  console.log('[User Service] GET /');
  res.json({ service: 'User Service', status: 'online', users });
});

app.get('/:id', (req, res) => {
  const user = users.find(u => u.id === req.params.id);
  if (user) {
    res.json(user);
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

// We export the app to be mounted or run independently
export default app;
