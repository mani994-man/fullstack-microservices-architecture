import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import userService from './services/user-service.ts';
import taskService from './services/task-service.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // API Gateway Logging Middleware
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[API Gateway] ${req.method} ${req.path} - ${new Date().toISOString()}`);
    }
    next();
  });

  // Microservices Routes (Mounted as independent mini-apps)
  // In a real microservices system, these would be on different IPs.
  // Here we use Express mounting to simulate the decoupled logic.
  app.use('/api/users', userService);
  app.use('/api/tasks', taskService);

  // Aggregated Endpoint (BFF - Backend For Frontend pattern)
  app.get('/api/dashboard', async (req, res) => {
    // Simulating inter-service communication
    // In real microservices, you'd use fetch() to other services
    try {
      // Mocking the data aggregation
      const usersResponse = [
        { id: '1', name: 'Alice Smith', email: 'alice@example.com', role: 'Architect' },
        { id: '2', name: 'Bob Johnson', email: 'bob@example.com', role: 'Developer' },
        { id: '3', name: 'Charlie Brown', email: 'charlie@example.com', role: 'DevOps' },
      ];
      const tasksResponse = [
        { id: '101', title: 'System Architecture', status: 'Completed', userId: '1' },
        { id: '102', title: 'Database Migration', status: 'In Progress', userId: '2' },
        { id: '103', title: 'Security Audit', status: 'Pending', userId: '1' },
      ];

      res.json({
        system: 'Micro-Link Gateway',
        timestamp: new Date().toISOString(),
        services: {
          users: { status: 'OK', count: usersResponse.length },
          tasks: { status: 'OK', count: tasksResponse.length }
        },
        data: {
          users: usersResponse,
          tasks: tasksResponse
        }
      });
    } catch (error) {
      res.status(500).json({ error: 'Gateway aggregation failed' });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[System] Main Gateway running on http://localhost:${PORT}`);
    console.log(`[System] User Service simulated at /api/users`);
    console.log(`[System] Task Service simulated at /api/tasks`);
  });
}

startServer().catch(err => {
  console.error('[Fatal] Failed to start server:', err);
});
