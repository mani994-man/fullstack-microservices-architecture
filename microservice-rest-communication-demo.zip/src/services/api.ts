import axios from 'axios';

export interface InventoryItem {
  id: string;
  name: string;
  stock: number;
  price: number;
}

export interface Order {
  id: string;
  itemId: string;
  quantity: number;
  status: string;
  timestamp: string;
}

export const fetchInventory = async (flakeRate: number = 0) => {
  const { data } = await axios.get<InventoryItem[]>(`/api/inventory/items?flake=${flakeRate}`);
  return data;
};

export const createOrder = async (itemId: string, quantity: number, flakeRate: number = 0) => {
  // We pass flakeRate so Service B can pass it to Service A for testing failure
  try {
    const { data } = await axios.post('/api/orders/create', { itemId, quantity }, {
      params: { flake: flakeRate }
    });
    return data;
  } catch (error: any) {
    if (error.response) {
      return error.response.data;
    }
    throw error;
  }
};

export const fetchOrderHistory = async () => {
  const { data } = await axios.get<Order[]>('/api/orders/history');
  return data;
};
