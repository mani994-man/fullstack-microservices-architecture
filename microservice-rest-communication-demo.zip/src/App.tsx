import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, 
  ShoppingCart, 
  Activity, 
  AlertCircle, 
  CheckCircle2, 
  History, 
  RefreshCcw, 
  Layers,
  Container,
  Zap,
  Trash2
} from 'lucide-react';
import { fetchInventory, createOrder, fetchOrderHistory, InventoryItem, Order } from './services/api';

export default function App() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [logs, setLogs] = useState<{ id: string; msg: string; type: 'info' | 'error' | 'success'; time: string }[]>([]);
  const [flakeRate, setFlakeRate] = useState(0.2); // 20% failure rate by default
  const [loading, setLoading] = useState(false);

  const addLog = (msg: string, type: 'info' | 'error' | 'success' = 'info') => {
    setLogs(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      msg,
      type,
      time: new Date().toLocaleTimeString()
    }, ...prev].slice(0, 50));
  };

  const loadData = async () => {
    try {
      const inv = await fetchInventory();
      const ords = await fetchOrderHistory();
      setInventory(inv);
      setOrders(ords);
    } catch (err) {
      addLog('Failed to fetch initial state', 'error');
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleOrder = async (itemId: string) => {
    setLoading(true);
    addLog(`[Order Service] Initiating order for ${itemId}`, 'info');
    
    try {
      const result = await createOrder(itemId, 1, flakeRate);
      
      if (result.status === 'SUCCESS') {
        addLog(`[Order Service] SUCCESS: ${result.order.id} processed`, 'success');
        setOrders(prev => [result.order, ...prev]);
        loadData();
      } else {
        addLog(`[Order Service] GRACEFUL FAILURE: ${result.error}`, 'error');
      }
    } catch (err: any) {
      addLog(`[Order Service] CRITICAL ERROR: Communication broke down`, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4 lg:p-10 min-h-screen flex flex-col gap-10">
      {/* HEADER SECTION - ARTISTIC FLAIR STYLE */}
      <header className="flex justify-between items-start border-b-2 border-ink pb-6 ml-1 mt-1">
        <div className="task-id font-black text-[100px] lg:text-[140px] leading-[0.8] tracking-[-0.05em] lg:tracking-[-0.08em]">
          17
        </div>
        <div className="metadata text-right font-mono text-[10px] lg:text-[12px] leading-relaxed uppercase">
          OBJECTIVE: INTER-SERVICE COMMUNICATION<br />
          METHOD: REST-BASED API CONSUMPTION<br />
          PROTOCOL: HTTP/1.1<br />
          STATUS: <span className="text-accent font-bold">ACTIVE</span>
        </div>
      </header>

      {/* CONTROLS */}
      <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-xs uppercase border-b border-ink/10 pb-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <span className="opacity-60">CHAOS INJECTION::</span>
            <input 
              type="range" min="0" max="0.5" step="0.1" 
              value={flakeRate} 
              onChange={(e) => setFlakeRate(parseFloat(e.target.value))}
              className="w-32 accent-accent cursor-crosshair"
            />
            <span className="font-bold">{(flakeRate * 100).toFixed(0)}%</span>
          </div>
        </div>
        <button 
          onClick={loadData}
          className="px-4 py-1 border border-ink hover:bg-ink hover:text-white transition-all flex items-center gap-2 uppercase font-bold"
        >
          <RefreshCcw className="w-3 h-3" /> Sync Services
        </button>
      </div>

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-10">
        
        {/* SERVICE CARDS */}
        <div className="space-y-10">
          {/* ORDER SERVICE - THE CONSUMER */}
          <div className="brutal-card group">
            <div className="consumer-tag">Primary Consumer</div>
            <h2 className="text-3xl font-extrabold uppercase tracking-tighter mb-2">ORDER_SVC_A</h2>
            <p className="text-sm opacity-80 leading-snug mb-6">
              Processing inbound orders and orchestrating inventory verification via REST.
            </p>
            
            <div className="space-y-4">
              <div className="font-mono text-[11px] uppercase text-gray-400 border-b border-gray-100 pb-1">Inventory Registry (Remote)</div>
              {inventory.map((item) => (
                <div key={item.id} className="flex justify-between items-center group/item py-2 border-b border-gray-100 last:border-0">
                  <div className="font-medium text-sm flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-ink rounded-full"></span>
                    {item.name}
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`font-mono text-xs ${item.stock === 0 ? 'text-red-600 line-through' : ''}`}>
                      {item.stock} Units
                    </span>
                    <button 
                      disabled={loading || item.stock === 0}
                      onClick={() => handleOrder(item.id)}
                      className="px-3 py-1 bg-ink text-white text-[10px] font-black uppercase hover:bg-accent transition-colors disabled:opacity-20 translate-x-1 group-hover/item:translate-x-0"
                    >
                      {loading ? '...' : 'Reserve'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 font-mono text-[10px] bg-gray-100 p-2 border-l-4 border-accent uppercase flex items-center gap-2">
              <Activity className="w-3 h-3" /> Endpoint: POST /api/orders/create
            </div>
          </div>

          {/* INVENTORY SERVICE - THE PRODUCER */}
          <div className="brutal-card">
            <div className="consumer-tag bg-ink">Remote Producer</div>
            <h2 className="text-3xl font-extrabold uppercase tracking-tighter mb-2">INV_MGMT_B</h2>
            <p className="text-sm opacity-80 leading-snug">
              Exposes stock availability and reservation endpoints. Scalable persistence layer.
            </p>
            <div className="mt-6 font-mono text-[10px] bg-gray-100 p-2 border-l-4 border-ink uppercase">
              Operational :: Region US-EAST-1
            </div>
          </div>
        </div>

        {/* INTERACTION STREAM (Logic Flow / Interaction Pipe) */}
        <div className="flex flex-col gap-6">
           <div className="font-bold text-sm uppercase flex items-center gap-2 mb-2">
             <span className="status-orb"></span> REST Communication Pipe
           </div>
           
           <div className="flex-1 bg-ink text-gray-300 font-mono text-[11px] p-6 terminal-scroll overflow-y-auto border-4 border-ink relative">
             <div className="absolute top-0 left-0 right-0 h-1 bg-accent/30"></div>
             <AnimatePresence initial={false}>
              {logs.map((log) => (
                <motion.div 
                  key={log.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-2 border-b border-white/5 pb-2"
                >
                  <span className="opacity-30">[{log.time}]</span>{' '}
                  <span className={`${
                    log.type === 'error' ? 'text-red-400 font-bold' : 
                    log.type === 'success' ? 'text-accent font-black' : 
                    'text-white'
                  }`}>
                    {log.msg.toUpperCase()}
                  </span>
                </motion.div>
              ))}
            </AnimatePresence>
            {logs.length === 0 && <span className="opacity-20 italic underline decoration-dotted">Waiting for REST handshake...</span>}
           </div>

           {/* ORDER LEDGER */}
           <div className="border-4 border-ink p-4">
              <h3 className="font-mono text-[10px] uppercase font-bold mb-3 flex items-center gap-2">
                <History className="w-3 h-3" /> Transaction Ledger
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {orders.map(order => (
                  <div key={order.id} className="text-[10px] border border-ink/20 p-2 font-mono flex justify-between">
                    <span className="font-bold tracking-tight">{order.id}</span>
                    <span className="text-accent underline decoration-2 underline-offset-2">OK</span>
                  </div>
                ))}
              </div>
           </div>
        </div>
      </main>

      {/* FOOTER - ARTISTIC FLAIR STYLE */}
      <footer className="mt-auto pt-6 border-t-2 border-ink flex justify-between items-center font-mono text-[10px] tracking-[0.15em] uppercase pb-2">
        <div className="flex items-center">
          <span className="status-orb"></span> SYSTEM NOMINAL
        </div>
        <div>
          DEPLOYMENT: STAGE_04 // REGION: AS-EAST
        </div>
      </footer>
    </div>
  );
}
