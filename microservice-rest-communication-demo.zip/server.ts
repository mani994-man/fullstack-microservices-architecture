import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import axios from "axios";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;
  const INTERNAL_BASE_URL = `http://localhost:${PORT}/api`;

  app.use(express.json());

  // --- DATA STORES (Simulated DB) ---
  const inventory = {
    "item-1": { id: "item-1", name: "Premium Coffee Beans", stock: 10, price: 25.0 },
    "item-2": { id: "item-2", name: "Organic Green Tea", stock: 5, price: 15.0 },
    "item-3": { id: "item-3", name: "Artisanal Honey", stock: 0, price: 12.0 },
  };

  const orders = [];

  // --- SERVICE A: INVENTORY SERVICE (The Provider) ---
  const inventoryRouter = express.Router();

  // Middleware to simulate flakiness (Chaos Monkey)
  inventoryRouter.use((req, res, next) => {
    const flakeFactor = parseFloat(req.query.flake as string) || 0;
    if (Math.random() < flakeFactor) {
      console.log(`[Inventory Service] Simulation: Random Failure triggered.`);
      return res.status(503).json({ error: "Inventory Service Unavailable (Simulated)" });
    }
    next();
  });

  inventoryRouter.get("/items", (req, res) => {
    res.json(Object.values(inventory));
  });

  inventoryRouter.get("/items/:id", (req, res) => {
    const item = inventory[req.params.id];
    if (!item) return res.status(404).json({ error: "Item not found" });
    res.json(item);
  });

  inventoryRouter.post("/items/:id/reserve", (req, res) => {
    const { quantity } = req.body;
    const item = inventory[req.params.id];

    if (!item) return res.status(404).json({ error: "Item not found" });
    if (item.stock < quantity) {
      return res.status(400).json({ error: "Insufficient stock" });
    }

    item.stock -= quantity;
    console.log(`[Inventory Service] Reserved ${quantity} of ${item.name}. New stock: ${item.stock}`);
    res.json({ success: true, remaining: item.stock });
  });

  app.use("/api/inventory", inventoryRouter);

  // --- SERVICE B: ORDER SERVICE (The Consumer) ---
  const orderRouter = express.Router();

  orderRouter.post("/create", async (req, res) => {
    const { itemId, quantity } = req.body;
    console.log(`[Order Service] Received request to create order for ${itemId} (qty: ${quantity})`);

    try {
      // 1. Consume REST API from Inventory Service
      // Note: In real microservices, this would be a different host/URL.
      // Here we call the local instance via its REST endpoint.
      console.log(`[Order Service] Calling Inventory Service for item verification...`);
      
      const inventoryResponse = await axios.post(`${INTERNAL_BASE_URL}/inventory/items/${itemId}/reserve`, {
        quantity
      }, {
        timeout: 5000 // Graceful requirement: Timeouts
      });

      // 2. Process Result
      const order = {
        id: `ORD-${Date.now()}`,
        itemId,
        quantity,
        status: "COMPLETED",
        timestamp: new Date().toISOString()
      };
      orders.push(order);

      console.log(`[Order Service] Order ${order.id} processed successfully.`);
      res.json({ status: "SUCCESS", order });

    } catch (error: any) {
      // Graceful Failure Handling
      console.error(`[Order Service] Failed to process order for ${itemId}:`, error.message);

      if (error.code === 'ECONNABORTED') {
        return res.status(504).json({ 
          status: "FAILED", 
          error: "Inventory Service timed out. Please try again later.",
          graceful: true 
        });
      }

      if (error.response) {
        // The service responded with a status code out of 2xx range
        const status = error.response.status;
        const message = error.response.data?.error || "Upstream Service Error";

        if (status === 503) {
           return res.status(503).json({ 
             status: "FAILED", 
             error: "Inventory Service is currently overloaded. We have logged this attempt for manual reconciliation.",
             graceful: true 
           });
        }

        return res.status(status).json({ 
          status: "FAILED", 
          error: `Inventory Service Error: ${message}`,
          graceful: true 
        });
      }

      // Generic failure handler
      res.status(500).json({ 
        status: "ERROR", 
        error: "An unexpected system failure occurred while processing your order.",
        graceful: true 
      });
    }
  });

  orderRouter.get("/history", (req, res) => {
    res.json(orders);
  });

  app.use("/api/orders", orderRouter);

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[System] Main server running on http://localhost:${PORT}`);
    console.log(`[System] Service A (Inventory) at /api/inventory`);
    console.log(`[System] Service B (Orders) at /api/orders`);
  });
}

startServer();
