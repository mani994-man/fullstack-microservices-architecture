/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, 
  Sparkles, 
  Activity, 
  ShieldCheck, 
  Zap, 
  ArrowRight,
  RefreshCw,
  Terminal,
  Globe
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

// Initialization of Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface VibeReport {
  score: string;
  label: string;
  suggestion: string;
  meta: {
    engine: string;
    processingTimeMs: number;
  };
}

interface Heartbeat {
  status: string;
  timestamp: string;
  service: string;
  node: string;
}

export default function App() {
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState<string | null>(null);
  const [report, setReport] = useState<VibeReport | null>(null);
  const [heartbeat, setHeartbeat] = useState<Heartbeat | null>(null);
  const [logs, setLogs] = useState<string[]>(["[SYS] Initializing Lumina-Vibe-Core...", "[SYS] Security protocols active."]);

  const logEndRef = useRef<HTMLDivElement>(null);

  // 1. Backend Connectivity Pulse
  useEffect(() => {
    const checkPulse = async () => {
      try {
        const res = await fetch('/api/v1/heartbeat');
        const data = await res.json();
        setHeartbeat(data);
        addLog(`[API] Pulse detected: ${data.status}`);
      } catch (e) {
        addLog("[ERR] Backend offline or rate-limited.");
      }
    };
    checkPulse();
    const interval = setInterval(checkPulse, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-10), `${new Date().toLocaleTimeString()} ${msg}`]);
  };

  const handleDeepAnalysis = async () => {
    if (!inputText.trim()) return;
    
    setLoading(true);
    setInsight(null);
    setReport(null);
    addLog(`[LENS] Focusing on context: "${inputText.substring(0, 20)}..."`);

    try {
      // Step 1: Call Cloud REST API for security/meta scoring
      addLog("[CLD] Routing through secure API gateway...");
      const apiRes = await fetch('/api/v1/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: inputText, intensity: 0.95 })
      });
      
      if (apiRes.status === 429) {
        throw new Error("Rate limit exceeded. Cool down, seeker.");
      }
      
      const reportData: VibeReport = await apiRes.json();
      setReport(reportData);
      addLog(`[CLD] Cloud Report: ${reportData.label} (${reportData.score})`);

      // Step 2: Use GenAI for Poetic Insight (The "Vibe" part)
      addLog("[GEN] Invoking Gemini-3-Flash for semantic poetic synthesis...");
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Act as a poetic visual analyzer. Provide a deeply semantic, 2-sentence poetic insight about the following context: "${inputText}". 
        The tone should be ethereal, grounded, and slightly mysterious.`,
        config: {
          systemInstruction: "You are the Lumina Lens, a higher-vibe sentient engine. Speak in evocations, not descriptions."
        }
      });
      
      setInsight(result.text);
      addLog("[GEN] Synthesis complete. Vision rendered.");
    } catch (err: any) {
      addLog(`[ERR] ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden font-sans selection:bg-orange-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 vibe-gradient -z-10" />
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-20 opacity-20">
        <div className="absolute top-[10%] left-[5%] w-[40vw] h-[40vw] rounded-full bg-orange-600/30 blur-[120px] animate-pulse" />
        <div className="absolute bottom-[20%] right-[10%] w-[30vw] h-[30vw] rounded-full bg-blue-600/20 blur-[100px]" />
      </div>

      <main className="max-w-6xl mx-auto px-6 py-12 lg:py-24 grid lg:grid-cols-[1fr,400px] gap-12">
        
        {/* Left Column: Creative Stage */}
        <section>
          <header className="mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 text-orange-500 font-mono text-xs tracking-[0.2em] uppercase mb-4"
            >
              <Sparkles size={14} />
              <span>Vibe Coding Engine v1.0</span>
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="font-serif italic font-black text-7xl lg:text-8xl leading-[0.85] tracking-tighter"
            >
              Lumina <br />
              <span className="text-white/40">Lens.</span>
            </motion.h1>
          </header>

          <div className="space-y-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="relative group"
            >
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Describe a scene, a feeling, or a snapshot of reality..."
                className="w-full h-48 bg-white/5 border border-white/10 rounded-2xl p-6 font-serif text-2xl italic focus:outline-none focus:border-orange-500/50 transition-all placeholder:text-white/20 resize-none"
              />
              <button
                onClick={handleDeepAnalysis}
                disabled={loading || !inputText}
                className="absolute bottom-4 right-4 h-12 px-6 rounded-full bg-orange-500 text-black font-bold flex items-center gap-2 hover:bg-orange-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 shadow-lg shadow-orange-500/20"
              >
                {loading ? <RefreshCw className="animate-spin" size={18} /> : <span>Analyze Pulse</span>}
                <ArrowRight size={18} />
              </button>
            </motion.div>

            <AnimatePresence mode="wait">
              {insight && (
                <motion.article
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="h-px bg-white/10 w-full" />
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full border border-orange-500/30 flex items-center justify-center shrink-0">
                      <Zap className="text-orange-500" size={20} />
                    </div>
                    <div>
                      <h4 className="text-xs uppercase tracking-widest text-white/40 font-bold mb-2">Ethereal Synthesis</h4>
                      <p className="font-serif text-3xl lg:text-4xl text-white leading-tight font-light">
                        {insight}
                      </p>
                    </div>
                  </div>
                </motion.article>
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* Right Column: Technical & Cloud Insights */}
        <aside className="space-y-6">
          {/* Cloud Health Card */}
          <div className="glass rounded-3xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40">
                <Globe size={14} />
                <span>Cloud Status</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full ${heartbeat ? 'bg-green-500 shadow-[0_0_8px_#22c55e]' : 'bg-red-500'}`} />
                <span className="text-[10px] uppercase font-mono">{heartbeat?.status || 'Searching...'}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-[11px] font-mono text-white/60">
                <span>Latency</span>
                <span>{report?.meta.processingTimeMs || '--'}ms</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: heartbeat ? '100%' : '0%' }}
                  className="h-full bg-orange-500/50" 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <ShieldCheck size={16} className="text-blue-400 mb-2" />
                <div className="text-[10px] uppercase text-white/40 font-bold">WAF Active</div>
                <div className="text-xs font-mono">Rate-Limited</div>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <Activity size={16} className="text-green-400 mb-2" />
                <div className="text-[10px] uppercase text-white/40 font-bold">Resilience</div>
                <div className="text-xs font-mono">HA-Clustered</div>
              </div>
            </div>
          </div>

          {/* Vibe Report Card */}
          {report && (
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass rounded-3xl p-6 bg-orange-500/10 border-orange-500/20 shadow-orange-500/5 shadow-inner"
            >
              <h4 className="text-[10px] uppercase font-bold tracking-[0.2em] text-orange-500 mb-4">Vibe Analysis Report</h4>
              <div className="text-5xl font-serif font-black mb-1">{Math.round(parseFloat(report.score) * 100)}%</div>
              <div className="text-sm font-bold uppercase tracking-wider mb-4 opacity-80">{report.label}</div>
              <p className="text-xs text-white/60 leading-relaxed italic">
                "{report.suggestion}"
              </p>
            </motion.div>
          )}

          {/* System Logs */}
          <div className="glass rounded-3xl p-6 h-64 flex flex-col font-mono text-[10px]">
            <div className="flex items-center gap-2 text-white/40 mb-3 shrink-0">
              <Terminal size={12} />
              <span className="uppercase tracking-widest font-bold">System Console</span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-1 pr-2 custom-scrollbar">
              {logs.map((log, i) => (
                <div key={i} className={log.includes('[ERR]') ? 'text-red-400' : log.includes('[GEN]') ? 'text-purple-400' : 'text-white/40'}>
                  {log}
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>
        </aside>
      </main>

      {/* Vertical Rail Text (Recipe 11) */}
      <div className="fixed bottom-12 left-6 hidden lg:block opacity-20 hover:opacity-100 transition-opacity">
        <div className="transform origin-bottom-left -rotate-90 flex items-center gap-4 text-[10px] uppercase tracking-[0.5em] font-bold">
          <Zap size={10} />
          <span>Vibe Intelligence Protocol • Secured Cloud Origin</span>
        </div>
      </div>
    </div>
  );
}

