import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Lumina Lens Core Server
 * 
 * A high-vibe, cloud-ready REST API built with security and scalability 
 * as first-class citizens.
 */
async function startServer() {
  const app = express();
  const PORT = 3000;

  // 1. Security Layer: Hardening the infrastructure
  app.use(helmet({
    contentSecurityPolicy: false, // Essential for full-stack Vite previews
  }));
  app.use(cors());
  app.use(express.json({ limit: '5mb' }));

  // 2. Resilience Layer: Rate limiting to prevent abuse
  const apiLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute window
    max: 20, // 20 requests per minute
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Cool down, seeker. The vibe is too high for this many requests." }
  });
  
  // Apply limiter to API routes
  app.use("/api/", apiLimiter);

  // 3. Service Layer: High-performance endpoints
  app.get("/api/v1/heartbeat", (req, res) => {
    res.status(200).json({
      status: "pulsing",
      timestamp: new Date().toISOString(),
      service: "Lumina Insight Engine",
      node: process.env.NODE_ENV || "development"
    });
  });

  /**
   * Insights Endpoint
   * Processes semantic data and returns a consolidated 'vibe' analysis.
   */
  app.post("/api/v1/analyze", (req, res) => {
    const { context, intensity } = req.body;
    
    if (!context) {
      return res.status(400).json({ error: "Context is required for a deep lens analysis." });
    }

    // High-performance simulation of cloud-based AI scoring
    const dynamicScore = (Math.random() * (intensity || 1)).toFixed(3);
    
    res.status(200).json({
      meta: {
        engine: "Gemini-Optimized-Vibe-Core",
        processingTimeMs: Math.floor(Math.random() * 50) + 10
      },
      analysis: {
        score: dynamicScore,
        label: parseFloat(dynamicScore) > 0.5 ? "Higher Consciousness" : "Grounding Required",
        suggestion: "Deepen the contrast to reveal hidden symmetries."
      }
    });
  });

  // 4. Orchestration Layer: Vite Development & Production Static Serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("✧ Vite Middleware Loaded (Development)");
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("✧ Standard Production Static Serving Active");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\n-----------------------------------------`);
    console.log(`🚀 LUMINA LENS ACTIVE ON PORT ${PORT}`);
    console.log(`📡 Environment: ${process.env.NODE_ENV || "development"}`);
    console.log(`-----------------------------------------\n`);
  });
}

startServer().catch((err) => {
  console.error("Critical System Failure:", err);
  process.exit(1);
});
