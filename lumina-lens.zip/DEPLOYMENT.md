# ☁️ Cloud Deployment: Lumina Lens

Directives for deploying the Lumina Lens stack to industry-standard cloud environments.

## 1. Containerization (Docker)
Lumina Lens is designed to run in a stateless container.

```dockerfile
# /Dockerfile
FROM node:22-slim AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM node:22-slim
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/server.ts ./
COPY --from=builder /app/package*.json ./
RUN npm install --production
RUN npm install -g tsx
EXPOSE 3000
CMD ["npm", "run", "start"]
```

## 2. Platform Options
*   **Google Cloud Run**: Ideal for the serverless nature of this API.
    *   `gcloud run deploy lumina-lens --source .`
*   **AWS App Runner**: For a managed container experience.
*   **Vercel/Netlify**: Can be used if refactored to serverless functions, but the current Express + Vite setup is optimized for **Cloud Run**.

## 3. Environment Secrets
Configure the following in your cloud provider's secret manager:
*   `GEMINI_API_KEY`: Obtained from Google AI Studio.
*   `NODE_ENV`: Set to `production`.
*   `APP_URL`: The public-facing URL of the service.

## 4. Scalability Strategy
The REST API uses `express-rate-limit` which is **in-memory** by default. For horizontally scaled cloud deployments:
1.  **Distributed Limiter**: Replace `express-rate-limit` with a Redis-backed store.
2.  **CDN Caching**: Serve the `/dist` assets via a Global CDN (Cloudflare or Google Cloud CDN) to reduce load on the origin server.
3.  **Managed Database**: If persistence is added, use Google Firestore (Standard or Enterprise) for real-time capabilities.
