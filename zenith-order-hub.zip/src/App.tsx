import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Database,
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

interface OrderHistoryItem {
  orderId: number;
  customerName: string;
  productName: string;
  quantity: number;
  price: number;
  totalValue: number;
  orderDate: string;
}

interface SummaryStats {
  revenue: number;
  orders: number;
}

interface HighestOrder {
  id: number;
  customerName: string;
  totalValue: number;
}

interface ActiveCustomer {
  name: string;
  order_count: number;
}

export default function App() {
  const [orders, setOrders] = useState<OrderHistoryItem[]>([]);
  const [summary, setSummary] = useState<SummaryStats | null>(null);
  const [highestOrder, setHighestOrder] = useState<HighestOrder | null>(null);
  const [activeCustomer, setActiveCustomer] = useState<ActiveCustomer | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [ordersRes, summaryRes, highestRes, activeRes] = await Promise.all([
        fetch('/api/orders/history'),
        fetch('/api/analytics/summary'),
        fetch('/api/analytics/highest-value-order'),
        fetch('/api/analytics/most-active-customer')
      ]);

      const [ordersData, summaryData, highestData, activeData] = await Promise.all([
        ordersRes.json(),
        summaryRes.json(),
        highestRes.json(),
        activeRes.json()
      ]);

      setOrders(ordersData);
      setSummary(summaryData);
      setHighestOrder(highestData);
      setActiveCustomer(activeData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-brand-bg flex items-center justify-center font-mono">
        <motion.div 
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-brand-accent tracking-[0.5em] text-xs uppercase"
        >
          CONNECTING.SYSTEM_RESOURCES...
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text flex flex-col selection:bg-brand-accent selection:text-brand-bg">
      {/* Header */}
      <header className="px-10 py-10 md:px-[60px] md:py-10 border-b border-brand-border flex justify-between items-baseline">
        <h1 className="text-brand-accent text-sm font-extrabold tracking-[0.2em] uppercase">
          SYSTEM.ORDER_MANAGEMENT_SQL
        </h1>
        <div className="font-mono text-xs text-brand-muted hidden sm:block">
          QUERY_LATENCY: 0.042ms // DB_CONNECTED
        </div>
      </header>

      {/* Analytics Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 border-b border-brand-border">
        <div className="p-10 md:p-[60px] border-b md:border-b-0 md:border-r border-brand-border flex flex-col justify-center">
          <span className="text-[11px] uppercase tracking-[0.1em] text-brand-muted mb-2.5 block">
            Subquery Result: Highest Value Order
          </span>
          <div className="text-[64px] lg:text-[84px] font-black leading-[0.9] tracking-[-0.04em] uppercase">
            ${highestOrder?.totalValue?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <span className="mt-[15px] text-lg text-brand-muted font-normal block">
            Order #{highestOrder?.id} // {highestOrder?.customerName}
          </span>
        </div>
        
        <div className="p-10 md:p-[60px] flex flex-col justify-center">
          <span className="text-[11px] uppercase tracking-[0.1em] text-brand-muted mb-2.5 block">
            Subquery Result: Most Active Customer
          </span>
          <div className="text-[64px] lg:text-[84px] font-black leading-[0.9] tracking-[-0.04em] uppercase">
            {activeCustomer?.name?.split(' ')[0]}
          </div>
          <span className="mt-[15px] text-lg text-brand-muted font-normal block">
            {activeCustomer?.order_count} Orders Total // Lifetime VIP
          </span>
        </div>
      </section>

      {/* Table Section */}
      <section className="flex-grow p-10 md:p-[60px] pb-20">
        <span className="text-[11px] uppercase tracking-[0.1em] text-brand-muted mb-5 block">
          Join Query Result: Recent Customer Order History
        </span>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="text-left py-4 border-b-2 border-brand-text text-[12px] uppercase tracking-[0.1em]">Order ID</th>
                <th className="text-left py-4 border-b-2 border-brand-text text-[12px] uppercase tracking-[0.1em]">Customer</th>
                <th className="text-left py-4 border-b-2 border-brand-text text-[12px] uppercase tracking-[0.1em]">Product</th>
                <th className="text-left py-4 border-b-2 border-brand-text text-[12px] uppercase tracking-[0.1em]">Date</th>
                <th className="text-left py-4 border-b-2 border-brand-text text-[12px] uppercase tracking-[0.1em]">Amount</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, i) => (
                <motion.tr 
                  key={order.orderId}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="border-b border-brand-border group hover:bg-white/5"
                >
                  <td className="py-5 font-mono text-[14px] text-brand-muted group-hover:text-brand-text">#ORD-{order.orderId}</td>
                  <td className="py-5 text-base font-light">{order.customerName}</td>
                  <td className="py-5 text-base font-light">{order.productName}</td>
                  <td className="py-5 text-base font-light">{new Date(order.orderDate).toLocaleDateString()}</td>
                  <td className="py-5 text-base font-light font-mono">${order.totalValue.toFixed(2)}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Chart Visualization (Adapted for theme) */}
        <div className="mt-20 border border-brand-border p-8 rounded-sm">
          <span className="text-[11px] uppercase tracking-[0.1em] text-brand-muted mb-8 block">Revenue Analysis: Top Orders</span>
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={orders.slice(0, 8)}>
                <Bar dataKey="totalValue">
                  {orders.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#D1FF26' : 'rgba(255, 255, 255, 0.1)'} />
                  ))}
                </Bar>
                <XAxis hide />
                <YAxis hide />
                <Tooltip 
                  cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }}
                  contentStyle={{ 
                    backgroundColor: '#050505', 
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '0px',
                    fontSize: '10px',
                    fontFamily: 'monospace'
                  }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-10 py-5 md:px-[60px] border-t border-brand-border flex flex-col md:flex-row justify-between gap-4 text-[10px] text-brand-muted uppercase tracking-[0.1em]">
        <div>Schema: [Customers] JOIN [Orders] JOIN [Products]</div>
        <div className="flex gap-8">
          <span>Page 1 of 1</span>
          <span>Sorted by: order_date DESC</span>
        </div>
      </footer>
    </div>
  );
}

