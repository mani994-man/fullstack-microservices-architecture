import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(':memory:'); // Use in-memory for this demo

// Initialize DB schema
db.exec(`
  CREATE TABLE customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL
  );

  CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    category TEXT NOT NULL
  );

  CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
  );
`);

// Seed data
const seedData = () => {
  const insertCustomer = db.prepare('INSERT INTO customers (name, email) VALUES (?, ?)');
  const customers = [
    ['Alice Johnson', 'alice@zenith.com'],
    ['Bob Smith', 'bob@zenith.com'],
    ['Charlie Davis', 'charlie@zenith.com'],
    ['Diana Prince', 'diana@zenith.com']
  ];
  customers.forEach(c => insertCustomer.run(...c));

  const insertProduct = db.prepare('INSERT INTO products (name, price, category) VALUES (?, ?, ?)');
  const products = [
    ['Quantum Laptop', 1299.99, 'Electronics'],
    ['Ergonomic Throne', 450.00, 'Furniture'],
    ['Nebula Smartphone', 899.50, 'Electronics'],
    ['Titanium Watch', 299.00, 'Accessories'],
    ['Solar Charger', 85.00, 'Accessories']
  ];
  products.forEach(p => insertProduct.run(...p));

  const insertOrder = db.prepare('INSERT INTO orders (customer_id, product_id, quantity, order_date) VALUES (?, ?, ?, ?)');
  const now = new Date();
  const orders = [
    [1, 1, 1, new Date(now.getTime() - 86400000 * 2).toISOString()],
    [1, 4, 1, new Date(now.getTime() - 86400000 * 1).toISOString()],
    [2, 2, 1, new Date(now.getTime() - 86400000 * 3).toISOString()],
    [3, 3, 2, new Date(now.getTime() - 86400000 * 5).toISOString()],
    [3, 5, 3, new Date(now.getTime() - 86400000 * 4).toISOString()],
    [4, 1, 1, new Date(now.getTime() - 86400000 * 1).toISOString()]
  ];
  orders.forEach(o => insertOrder.run(...o));
};

seedData();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Endpoints using JOINS and Subqueries

  // 1. Customer Order History (JOIN)
  app.get('/api/orders/history', (req, res) => {
    const query = `
      SELECT 
        o.id as orderId,
        c.name as customerName,
        p.name as productName,
        o.quantity,
        p.price,
        (o.quantity * p.price) as totalValue,
        o.order_date as orderDate
      FROM orders o
      JOIN customers c ON o.customer_id = c.id
      JOIN products p ON o.product_id = p.id
      ORDER BY o.order_date DESC
    `;
    const rows = db.prepare(query).all();
    res.json(rows);
  });

  // 2. Highest Value Order (Subquery in WHERE or as a derived value)
  app.get('/api/analytics/highest-value-order', (req, res) => {
    const query = `
      SELECT 
        o.id, 
        c.name as customerName, 
        (o.quantity * p.price) as totalValue
      FROM orders o
      JOIN customers c ON o.customer_id = c.id
      JOIN products p ON o.product_id = p.id
      WHERE (o.quantity * p.price) = (
        SELECT MAX(quantity * price) 
        FROM orders ord
        JOIN products prd ON ord.product_id = prd.id
      )
    `;
    const result = db.prepare(query).get();
    res.json(result);
  });

  // 3. Most Active Customer (Subquery / Aggregation)
  app.get('/api/analytics/most-active-customer', (req, res) => {
    const query = `
      SELECT 
        c.name, 
        order_count
      FROM customers c
      JOIN (
        SELECT customer_id, COUNT(*) as order_count
        FROM orders
        GROUP BY customer_id
      ) as order_counts ON c.id = order_counts.customer_id
      ORDER BY order_count DESC
      LIMIT 1
    `;
    const result = db.prepare(query).get();
    res.json(result);
  });

  // 4. Summary Stats
  app.get('/api/analytics/summary', (req, res) => {
    const totalRevenue = db.prepare('SELECT SUM(o.quantity * p.price) as revenue FROM orders o JOIN products p ON o.product_id = p.id').get() as { revenue: number };
    const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get() as { count: number };
    res.json({ 
      revenue: totalRevenue.revenue, 
      orders: totalOrders.count 
    });
  });

  // Vite setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Zenith Order Hub running on http://localhost:${PORT}`);
  });
}

startServer();
