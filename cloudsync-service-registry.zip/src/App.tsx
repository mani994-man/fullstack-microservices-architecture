import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Server, 
  Activity, 
  Search, 
  RefreshCw, 
  ShieldCheck, 
  AlertCircle,
  Database,
  ArrowRight,
  ExternalLink,
  Cpu
} from 'lucide-react';

interface ServiceInstance {
  id: string;
  name: string;
  url: string;
  lastHeartbeat: number;
  status: 'UP' | 'DOWN' | 'OUT_OF_SERVICE';
}

export default function App() {
  const [instances, setInstances] = useState<ServiceInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [lookupResult, setLookupResult] = useState<any>(null);
  const [lookingUp, setLookingUp] = useState(false);
  const [activeTab, setActiveTab] = useState<'instances' | 'discover'>('instances');

  const fetchInstances = async () => {
    try {
      const res = await fetch('/api/registry/instances');
      const data = await res.json();
      setInstances(data);
    } catch (error) {
      console.error('Failed to fetch instances', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInstances();
    const interval = setInterval(fetchInstances, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleDiscover = async (serviceName: string) => {
    setLookingUp(true);
    setLookupResult(null);
    try {
      const res = await fetch(`/api/registry/discover/${serviceName}`);
      if (res.ok) {
        const instance = await res.json();
        setLookupResult({ type: 'success', instance });
      } else {
        const err = await res.json();
        setLookupResult({ type: 'error', message: err.error });
      }
    } catch (error) {
      setLookupResult({ type: 'error', message: 'Discovery request failed' });
    } finally {
      setLookingUp(false);
    }
  };

  const filteredInstances = instances.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    i.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F3F4F6] text-[#111827] font-sans p-4 md:p-8">
      {/* Header */}
      <header className="max-w-7xl mx-auto mb-8 flex justify-between items-end border-b-2 border-black pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Server className="w-6 h-6 text-[#2563EB]" />
            <h1 className="text-2xl font-black uppercase tracking-tighter text-[#111827]">HyperRegistry <span className="text-[#2563EB]">v4.2</span></h1>
          </div>
          <p className="text-[10px] uppercase font-bold opacity-50 tracking-wider">Node Cluster: ASIA-EAST1-B // Status: Active</p>
        </div>
        <div className="hidden md:flex gap-4 items-center">
          <div className="text-right">
            <p className="text-[10px] uppercase font-bold opacity-30">Registry Time</p>
            <p className="text-sm font-bold font-mono">{new Date().toLocaleTimeString()}</p>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={fetchInstances}
            className="p-2 border-2 border-black rounded-lg bg-white shadow-[2px_2px_0px_#000000] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] transition-all"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </motion.button>
        </div>
      </header>

      {/* Main Content - Bento Grid Layout */}
      <main className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Stats Cards */}
          <div className="bg-white border-2 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000000]">
            <p className="text-[11px] font-bold uppercase text-gray-500 mb-2 tracking-widest">Total Nodes</p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold">{instances.length}</span>
              <span className="text-xs text-[#059669] font-bold">↑ Active</span>
            </div>
            <p className="text-[11px] mt-2 opacity-60">Clustered across 3 zones</p>
          </div>

          <div className="bg-[#ECFDF5] border-2 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000000]">
            <p className="text-[11px] font-bold uppercase text-[#059669] mb-2 tracking-widest">System Health</p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#059669]">99.8%</span>
            </div>
            <p className="text-[11px] mt-2 opacity-60 text-[#059669]">Self-preservation: ON</p>
          </div>

          {/* Search / Discover Tab Bar */}
          <div className="md:col-span-2 bg-white border-2 border-black rounded-2xl p-2 flex gap-2 items-center shadow-[4px_4px_0px_#000000]">
            <button 
              onClick={() => setActiveTab('instances')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-xs uppercase transition-all ${activeTab === 'instances' ? 'bg-[#111827] text-white' : 'hover:bg-gray-100 dark:hover:text-[#111827]'}`}
            >
              <Database className="w-4 h-4" />
              Service Map
            </button>
            <button 
              onClick={() => setActiveTab('discover')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-xs uppercase transition-all ${activeTab === 'discover' ? 'bg-[#111827] text-white' : 'hover:bg-gray-100 dark:hover:text-[#111827]'}`}
            >
              <Search className="w-4 h-4" />
              Dynamic Lookup
            </button>
          </div>

          {/* Registry Table / Discovery Panels */}
          <div className="md:col-span-3 md:row-span-2 bg-white border-2 border-black rounded-2xl shadow-[4px_4px_0px_#000000] overflow-hidden flex flex-col min-h-[400px]">
            <div className="p-5 border-b-2 border-black flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <h2 className="text-sm font-black uppercase tracking-tight flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#2563EB]" />
                {activeTab === 'instances' ? 'Active Service Registry' : 'Service Discovery Tunnel'}
              </h2>
              {activeTab === 'instances' && (
                <div className="relative w-full sm:w-auto">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-bold opacity-30">FILTER:</span>
                  <input 
                    type="text"
                    placeholder="NAME OR ID..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full sm:w-64 bg-gray-100 border-2 border-black pl-14 pr-4 py-2 text-[11px] font-bold uppercase rounded-lg focus:outline-none focus:bg-white"
                  />
                </div>
              )}
            </div>

            <div className="flex-grow overflow-auto">
              {activeTab === 'instances' ? (
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b-2 border-black/5">
                    <tr>
                      <th className="px-5 py-3 text-[11px] font-bold text-gray-400 uppercase">Application</th>
                      <th className="px-5 py-3 text-[11px] font-bold text-gray-400 uppercase">Node ID</th>
                      <th className="px-5 py-3 text-[11px] font-bold text-gray-400 uppercase">Endpoint</th>
                      <th className="px-5 py-3 text-[11px] font-bold text-gray-400 uppercase">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    <AnimatePresence mode="popLayout">
                      {filteredInstances.map((instance) => (
                        <motion.tr 
                          key={instance.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="hover:bg-blue-50/50 transition-colors group"
                        >
                          <td className="px-5 py-4 decoration-skip-ink font-bold text-sm tracking-tight">{instance.name}</td>
                          <td className="px-5 py-4">
                            <span className="bg-gray-100 border border-gray-200 text-[10px] font-mono px-2 py-1 rounded-md text-gray-600 uppercase font-bold">
                              {instance.id}
                            </span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-2 text-xs font-medium text-[#2563EB]">
                              {instance.url}
                              <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100" />
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${instance.status === 'UP' ? 'bg-[#059669]' : 'bg-[#DC2626]'}`} />
                              <span className={`text-[11px] font-bold uppercase ${instance.status === 'UP' ? 'text-[#059669]' : 'text-[#DC2626]'}`}>
                                {instance.status}
                              </span>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </tbody>
                </table>
              ) : (
                <div className="p-8 h-full flex flex-col md:flex-row gap-8">
                  <div className="flex-1 space-y-6">
                    <div>
                      <h4 className="text-[11px] font-bold uppercase text-gray-400 mb-3 text-[#111827]">Service Selection</h4>
                      <select 
                        onChange={(e) => handleDiscover(e.target.value)}
                        className="w-full bg-gray-50 border-2 border-black p-4 font-bold text-sm uppercase rounded-xl appearance-none focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                      >
                        <option value="">-- Choose Microservice --</option>
                        <option value="OrderService">Order-Flow-Engine</option>
                        <option value="InventoryService">Inventory-API</option>
                        <option value="PaymentService">Payment-Processor</option>
                      </select>
                    </div>

                    <AnimatePresence mode="wait">
                      {lookupResult && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className={`p-6 border-2 border-black rounded-xl shadow-[4px_4px_0_0_#000] ${lookupResult.type === 'success' ? 'bg-[#EEF2FF] border-[#2563EB]' : 'bg-[#FEF2F2] border-[#DC2626]'}`}
                        >
                          {lookupResult.type === 'success' ? (
                            <div className="flex gap-4 text-[#111827]">
                              <div className="bg-[#2563EB] text-white p-2 rounded-lg h-fit">
                                <ShieldCheck className="w-5 h-5" />
                              </div>
                              <div>
                                <p className="text-[10px] font-bold uppercase text-[#2563EB] mb-1">Route Resolved</p>
                                <p className="text-lg font-black tracking-tight">{lookupResult.instance.url}</p>
                                <div className="mt-3 flex gap-2">
                                  <span className="text-[10px] bg-white border border-[#2563EB]/20 px-2 py-1 rounded font-bold uppercase text-[#2563EB]">NODE: {lookupResult.instance.id}</span>
                                  <span className="text-[10px] bg-white border border-[#2563EB]/20 px-2 py-1 rounded font-bold uppercase text-[#2563EB]">Latency: 4ms</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex gap-4">
                              <AlertCircle className="w-5 h-5 text-[#DC2626]" />
                              <div>
                                <p className="text-[10px] font-bold uppercase text-[#DC2626] mb-1">Resolution Error</p>
                                <p className="text-sm font-bold uppercase text-[#111827]">{lookupResult.message}</p>
                              </div>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <div className="w-full md:w-64 bg-[#111827] text-white p-6 rounded-xl">
                    <h4 className="text-[10px] font-bold uppercase text-gray-500 mb-4 tracking-widest text-gray-300">Discovery Node Info</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center border-b border-white/10 pb-3">
                        <span className="text-[10px] text-gray-400 uppercase">Lease Data</span>
                        <span className="text-[11px] font-bold text-white">Enabled</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-white/10 pb-3">
                        <span className="text-[10px] text-gray-400 uppercase">Encrypted</span>
                        <span className="text-[11px] font-bold text-[#059669]">YES</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-gray-400 uppercase block mb-2">Protocol Trace</span>
                        <div className="bg-black/50 p-3 rounded font-mono text-[9px] text-[#A5B4FC]">
                          GET /registry/v2/resolve?s=OrderService HTTP/1.1
                          <br />
                          X-Registry-Client: v4.2.0
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Environment Card */}
          <div className="bg-white border-2 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000000]">
            <p className="text-[11px] font-bold uppercase text-gray-500 mb-4 tracking-widest text-[#111827]">Environment</p>
            <div className="space-y-4">
              <div className="flex justify-between items-center bg-gray-50 p-2 rounded-lg border border-black/5 text-[#111827]">
                <span className="text-[10px] font-bold uppercase">Region</span>
                <span className="text-[10px] font-black uppercase text-[#2563EB]">US-EAST-1</span>
              </div>
              <div className="flex justify-between items-center bg-gray-50 p-2 rounded-lg border border-black/5 text-[#111827]">
                <span className="text-[10px] font-bold uppercase">Tier</span>
                <span className="bg-[#111827] text-white text-[9px] px-2 py-0.5 rounded font-black uppercase">Production</span>
              </div>
              <p className="text-[10px] font-bold uppercase opacity-30 text-center pt-2 italic text-[#111827]">Eureka Persistence: active</p>
            </div>
          </div>

          {/* Network Activity Card */}
          <div className="bg-white border-2 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000000] flex flex-col">
            <p className="text-[11px] font-bold uppercase text-gray-400 mb-4 tracking-widest text-[#111827]">Traffic Load</p>
            <div className="flex-grow flex items-end gap-1.5 h-16">
              {[40, 60, 55, 80, 75, 90, 85, 95, 70, 80].map((h, i) => (
                <div key={i} className="flex-1 bg-[#111827] rounded-sm" style={{ height: `${h}%` }} />
              ))}
            </div>
            <p className="text-[11px] mt-4 font-bold opacity-60 text-[#111827]">Heartbeat threshold: <b className="text-black">85%</b></p>
          </div>
        </div>
      </main>
    </div>
  );
}
