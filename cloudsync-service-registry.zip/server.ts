import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ServiceInstance {
  id: string;
  name: string;
  url: string;
  lastHeartbeat: number;
  status: 'UP' | 'DOWN' | 'OUT_OF_SERVICE';
}

const registry: Map<string, ServiceInstance> = new Map();

async function startServer() {
  const app = express();
  app.use(express.json());

  // Service Registry API
  app.post('/api/registry/register', (req, res) => {
    const { id, name, url } = req.body;
    if (!id || !name || !url) {
      return res.status(400).json({ error: 'Missing service details' });
    }
    
    registry.set(id, {
      id,
      name,
      url,
      lastHeartbeat: Date.now(),
      status: 'UP'
    });
    
    console.log(`[Registry] Registered service: ${name} (${id})`);
    res.json({ message: 'Registered successfully', service: registry.get(id) });
  });

  app.post('/api/registry/heartbeat/:id', (req, res) => {
    const { id } = req.params;
    const service = registry.get(id);
    if (service) {
      service.lastHeartbeat = Date.now();
      service.status = 'UP';
      res.json({ status: 'UP' });
    } else {
      res.status(404).json({ error: 'Service not found' });
    }
  });

  app.get('/api/registry/instances', (req, res) => {
    res.json(Array.from(registry.values()));
  });

  app.get('/api/registry/discover/:name', (req, res) => {
    const { name } = req.params;
    const instances = Array.from(registry.values()).filter(s => s.name === name && s.status === 'UP');
    
    if (instances.length > 0) {
      // Simple round robin or random selection
      const instance = instances[Math.floor(Math.random() * instances.length)];
      res.json(instance);
    } else {
      res.status(404).json({ error: `Service ${name} not found or down` });
    }
  });

  // Mock Microservices
  app.get('/services/orders/status', (req, res) => {
    res.json({ service: 'Order Service', status: 'Healthy', version: '1.0.4' });
  });

  app.get('/services/inventory/check', (req, res) => {
    res.json({ service: 'Inventory Service', available: true, stockLevel: 45 });
  });

  app.get('/services/payment/verify', (req, res) => {
    res.json({ service: 'Payment Service', verified: true, merchantId: 'm_9921' });
  });

  // Cleanup lost heartbeats every 10 seconds
  setInterval(() => {
    const now = Date.now();
    registry.forEach((service, id) => {
      if (now - service.lastHeartbeat > 30000) { // 30s threshold
        service.status = 'DOWN';
      }
    });
  }, 10000);

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    
    // Self-register mock services
    const baseUrl = 'http://localhost:3000';
    
    const mockServices = [
      { id: 'order-v1', name: 'OrderService', url: `${baseUrl}/services/orders` },
      { id: 'inventory-v2', name: 'InventoryService', url: `${baseUrl}/services/inventory` },
      { id: 'payment-alpha', name: 'PaymentService', url: `${baseUrl}/services/payment` }
    ];

    mockServices.forEach(async (s) => {
      try {
        await fetch(`${baseUrl}/api/registry/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(s)
        });
      } catch (e) {
        console.error(`Failed to register mock service ${s.name}`);
      }
    });
  });
}

startServer();
