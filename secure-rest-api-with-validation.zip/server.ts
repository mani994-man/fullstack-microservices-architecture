import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { UserSchema, User, ApiErrorResponse } from './src/schema.ts';
import { ZodError } from 'zod';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory "database"
  let users: User[] = [
    { id: '1', name: 'John Doe', email: 'john@example.com', age: 30, role: 'admin' }
  ];

  // API Routes
  app.get('/api/users', (req: Request, res: Response) => {
    res.json({ status: 'success', data: users });
  });

  app.post('/api/users', (req: Request, res: Response, next: NextFunction) => {
    try {
      // Validation check
      const validatedData = UserSchema.parse(req.body);
      const newUser = { ...validatedData, id: Date.now().toString() };
      users.push(newUser);
      res.status(201).json({ status: 'success', data: newUser });
    } catch (error) {
      next(error); // Pass to global error handler
    }
  });

  // Example of a route that throws a custom error
  app.get('/api/users/:id', (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = users.find(u => u.id === req.params.id);
      if (!user) {
        const error = new Error('User not found');
        (error as any).status = 404;
        throw error;
      }
      res.json({ status: 'success', data: user });
    } catch (error) {
      next(error);
    }
  });

  // ---------------------------------------------------------
  // Global Exception Handling Implementation
  // ---------------------------------------------------------
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error(`[Error] ${err.message}`);

    // Handle Zod Validation Errors
    if (err instanceof ZodError) {
      const fieldErrors: Record<string, string[]> = {};
      err.issues.forEach(e => {
        const path = e.path.join('.');
        if (!fieldErrors[path]) fieldErrors[path] = [];
        fieldErrors[path].push(e.message);
      });

      return res.status(400).json({
        status: 'error',
        message: 'Validation failed',
        errors: fieldErrors
      } as ApiErrorResponse);
    }

    // Handle JSON syntax errors
    if (err instanceof SyntaxError && 'status' in err && err.status === 400 && 'body' in err) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid JSON payload'
      } as ApiErrorResponse);
    }

    // Default Error Handler
    const statusCode = err.status || 500;
    const message = err.message || 'Internal Server Error';

    res.status(statusCode).json({
      status: 'error',
      message: message
    } as ApiErrorResponse);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
