/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  UserPlus, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  Shield, 
  User as UserIcon, 
  Mail, 
  Calendar,
  X,
  Plus
} from 'lucide-react';
import { User, ApiErrorResponse, ApiSuccessResponse } from './schema';

export default function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string[]>>({});
  const [success, setSuccess] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const [formData, setFormData] = useState<User>({
    name: '',
    email: '',
    age: 18,
    role: 'viewer'
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/users');
      const data: ApiSuccessResponse<User[]> = await res.json();
      setUsers(data.data);
    } catch (err) {
      setError('Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setValidationErrors({});
    setError(null);
    setSuccess(null);

    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (!res.ok) {
        if (data.status === 'error' && data.errors) {
          setValidationErrors(data.errors);
        } else {
          setError(data.message || 'An unexpected error occurred');
        }
        return;
      }

      setUsers([...users, data.data]);
      setSuccess('User created successfully!');
      setShowModal(false);
      setFormData({ name: '', email: '', age: 18, role: 'viewer' });
      
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError('Network error. Please check your connection.');
    } finally {
      setSubmitting(false);
    }
  };

  const getRoleBadge = (role: string) => {
    const styles = {
      admin: 'bg-info/10 text-info border-info/20',
      editor: 'bg-success/10 text-success border-success/20',
      viewer: 'bg-text-dim/10 text-text-dim border-text-dim/20'
    };
    return (
      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-widest border ${styles[role as keyof typeof styles]}`}>
        {role}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-bg text-text-main font-sans p-6 overflow-x-hidden">
      <div className="max-w-[1200px] mx-auto min-h-[calc(100vh-48px)] flex flex-col">
        {/* Header */}
        <header className="flex justify-between items-end pb-4 mb-6 border-b border-border">
          <div>
            <span className="bg-info/10 text-info px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border border-info/20">
              Sprint 4 • Task 13
            </span>
            <h1 className="text-2xl font-bold mt-2 tracking-tight">RESTful Exception & Validation Layer</h1>
          </div>
          <div className="text-right hidden sm:block">
            <div className="text-success text-sm font-semibold flex items-center justify-end gap-2">
              <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
              System Operational
            </div>
            <div className="text-text-dim text-[11px] mt-1 italic opacity-60">Last sync: Just now</div>
          </div>
        </header>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-grow">
          {/* Large: Monitoring/Stats / List */}
          <div className="md:col-span-2 md:row-span-2 bento-card relative overflow-hidden">
            <div className="card-title">User Directory</div>
            
            <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
              {loading ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 py-12">
                  <Loader2 className="animate-spin text-info" size={32} />
                  <p className="text-text-dim text-xs font-mono uppercase tracking-widest">Fetching DB...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <AnimatePresence mode="popLayout">
                    {users.map((user, idx) => (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="flex items-center justify-between p-3 rounded-xl bg-bg/50 border border-border/50 hover:border-info/30 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-info/10 flex items-center justify-center text-info group-hover:bg-info group-hover:text-white transition-all">
                            <UserIcon size={16} />
                          </div>
                          <div>
                            <div className="text-xs font-semibold">{user.name}</div>
                            <div className="text-[10px] text-text-dim lowercase">{user.email}</div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          {getRoleBadge(user.role)}
                          <span className="text-[9px] font-mono text-text-dim/50 italic opacity-0 group-hover:opacity-100 transition-opacity">ID: {user.id}</span>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  
                  {users.length === 0 && !loading && (
                    <div className="flex flex-col items-center justify-center h-full py-12 text-text-dim">
                      <Users size={32} className="opacity-20 mb-2" />
                      <p className="text-xs uppercase tracking-widest font-bold">No Records</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-border flex justify-between items-center text-[11px] text-text-dim uppercase tracking-widest font-bold">
              <span>Total Entries</span>
              <span className="text-info">{users.length}</span>
            </div>
          </div>

          {/* Medium-V: Error History Simulation */}
          <div className="md:col-span-1 md:row-span-2 bento-card">
            <div className="card-title">Exception Log</div>
            <div className="flex-grow flex flex-col gap-1 overflow-hidden">
              <div className="flex justify-between items-center p-2 rounded-lg bg-error/5 border border-error/10 text-[11px]">
                <span className="font-mono text-error font-bold">400</span>
                <span className="text-text-dim truncate px-2">Validation Failed</span>
                <span className="text-text-dim/40 text-[9px]">NOW</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg text-[11px] opacity-60">
                <span className="font-mono text-text-dim">422</span>
                <span className="text-text-dim truncate px-2">Unprocessable</span>
                <span className="text-text-dim/40 text-[9px]">5M</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg text-[11px] opacity-40">
                <span className="font-mono text-text-dim">404</span>
                <span className="text-text-dim truncate px-2">Route Missing</span>
                <span className="text-text-dim/40 text-[9px]">12M</span>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg text-[11px] opacity-20">
                <span className="font-mono text-text-dim">500</span>
                <span className="text-text-dim truncate px-2">Server Error</span>
                <span className="text-text-dim/40 text-[9px]">1H</span>
              </div>
            </div>
            
            <div className="mt-auto pt-4 flex flex-col gap-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-text-dim">Health</span>
                <span className="text-success font-bold tracking-tighter">98.2%</span>
              </div>
              <div className="w-full h-1.5 bg-bg rounded-full overflow-hidden border border-border">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '98.2%' }}
                  className="h-full bg-success"
                />
              </div>
            </div>
          </div>

          {/* Small: Stats */}
          <div className="bento-card">
            <div className="card-title">Global Handler</div>
            <div className="flex-grow flex flex-col justify-center">
              <div className="text-4xl font-bold tracking-tighter">14</div>
              <div className="text-[10px] uppercase font-bold text-text-dim/60 tracking-widest mt-1">Active Mappers</div>
            </div>
          </div>

          {/* Small: Success Rate */}
          <div className="bento-card">
            <div className="card-title">Validation Rate</div>
            <div className="flex-grow flex flex-col justify-center">
              <div className="text-4xl font-bold tracking-tighter">92.4%</div>
              <div className="text-success text-[10px] font-bold flex items-center gap-1 mt-1">
                <span>↑ 0.4%</span>
                <span className="text-text-dim/40 font-normal italic">vs last hour</span>
              </div>
            </div>
          </div>

          {/* Medium-H: Controls */}
          <div className="md:col-span-2 bento-card group">
            <div className="card-title">Command Center</div>
            <div className="flex gap-4 items-center flex-grow">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowModal(true)}
                className="flex h-full items-center justify-center gap-3 bg-info text-white px-6 rounded-xl font-bold transition-all shadow-lg shadow-info/10 text-sm flex-grow"
              >
                <Plus size={18} />
                REGISTER NEW ENTITY
              </motion.button>
              <div className="h-full border-l border-border px-4 flex flex-col justify-center gap-2">
                <div className="flex items-center gap-2 text-[10px] font-bold text-text-dim italic">
                  <div className="w-1.5 h-1.5 rounded-full bg-success"/>
                  DB PERSISTENCE: ON
                </div>
                <div className="flex items-center gap-2 text-[10px] font-bold text-text-dim italic">
                  <div className="w-1.5 h-1.5 rounded-full bg-error"/>
                  LOG SYNC: ERROR
                </div>
              </div>
            </div>
          </div>

          {/* Small: Success */}
          <div className="bento-card">
            <div className="card-title">System Load</div>
            <div className="flex flex-col justify-center flex-grow">
              <div className="text-2xl font-bold font-mono tracking-tighter text-text-main/80">LOW</div>
              <div className="text-[10px] uppercase font-bold text-text-dim/60 mt-1 italic">V14.2 Production</div>
            </div>
          </div>

        </div>

        {/* Global Feedback Banner (Floating bottom) */}
        <AnimatePresence>
          {(error || success) && (
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] w-full max-w-lg px-4"
            >
              {error && (
                <div className="bg-[#1a0b0d] border border-error/30 text-error p-4 rounded-2xl flex items-center gap-3 shadow-2xl glass-effect">
                  <AlertCircle size={20} className="shrink-0" />
                  <p className="text-xs font-bold uppercase tracking-wider">{error}</p>
                  <button onClick={() => setError(null)} className="ml-auto p-1 hover:bg-error/20 rounded-full transition-colors">
                    <X size={16} />
                  </button>
                </div>
              )}
              {success && (
                <div className="bg-[#0b1a13] border border-success/30 text-success p-4 rounded-2xl flex items-center gap-3 shadow-2xl glass-effect">
                  <CheckCircle2 size={20} className="shrink-0" />
                  <p className="text-xs font-bold uppercase tracking-wider">{success}</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <footer className="mt-8 pt-4 border-t border-border flex justify-between items-center text-[11px] text-text-dim opacity-60 font-medium">
          <div>Environment: <strong className="text-text-main">Production-Cluster-A</strong></div>
          <div className="font-mono">v2.4.12-stable • TS 5.x • RESTful</div>
        </footer>
      </div>

      {/* Modal - Theming the form */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-bg/80 backdrop-blur-md"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="relative w-full max-w-md bg-card border border-border rounded-[2.5rem] shadow-2xl p-8"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-text-main">Register Entity</h2>
                  <p className="text-text-dim text-xs font-medium uppercase tracking-[0.2em] mt-1 italic">Validation Layer V4</p>
                </div>
                <button 
                  onClick={() => setShowModal(false)}
                  className="p-2 hover:bg-border rounded-full transition-colors text-text-dim"
                >
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-text-dim mb-2 ml-1">Identity Name</label>
                    <input 
                      type="text"
                      placeholder="Jane Smith"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full bg-bg border-2 px-4 py-3 rounded-2xl outline-none transition-all focus:border-info text-sm ${validationErrors.name ? 'border-error/50 bg-error/5' : 'border-border'}`}
                    />
                    {validationErrors.name && (
                      <p className="mt-2 text-[10px] text-error font-bold uppercase tracking-widest ml-1">{validationErrors.name[0]}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-text-dim mb-2 ml-1">Global Communication UID</label>
                    <input 
                      type="text"
                      placeholder="jane@cluster-a.net"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full bg-bg border-2 px-4 py-3 rounded-2xl outline-none transition-all focus:border-info text-sm ${validationErrors.email ? 'border-error/50 bg-error/5' : 'border-border'}`}
                    />
                    {validationErrors.email && (
                      <p className="mt-2 text-[10px] text-error font-bold uppercase tracking-widest ml-1">{validationErrors.email[0]}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-text-dim mb-2 ml-1">Lifecycle Index (Age)</label>
                      <input 
                        type="number"
                        value={formData.age}
                        onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                        className={`w-full bg-bg border-2 px-4 py-3 rounded-2xl outline-none transition-all focus:border-info text-sm ${validationErrors.age ? 'border-error/50 bg-error/5' : 'border-border'}`}
                      />
                      {validationErrors.age && (
                        <p className="mt-2 text-[10px] text-error font-bold uppercase tracking-widest ml-1">{validationErrors.age[0]}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-text-dim mb-2 ml-1">Permission Tier</label>
                      <select 
                        value={formData.role}
                        onChange={e => setFormData({ ...formData, role: e.target.value as any })}
                        className="w-full bg-bg border-2 border-border px-3 py-3 rounded-2xl outline-none transition-all focus:border-info text-sm appearance-none cursor-pointer"
                      >
                        <option value="admin">ADMINISTRATOR</option>
                        <option value="editor">CONTRIBUTOR</option>
                        <option value="viewer">OBSERVER</option>
                        <option value="guest">GUEST (EXCEPTION TEST)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-4 space-y-3">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-info text-white py-4 rounded-2xl font-bold shadow-lg shadow-info/20 hover:bg-info/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {submitting ? <Loader2 size={18} className="animate-spin" /> : <Plus size={18} />}
                    EXECUTE REGISTRATION
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="w-full text-text-dim font-bold py-2 text-[10px] hover:text-text-main transition-colors uppercase tracking-[0.2em]"
                  >
                    DISCARD OPERATION
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

