import { z } from 'zod';

export const UserSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2, "Name must be at least 2 characters").max(50, "Name too long"),
  email: z.string().email("Invalid email address"),
  age: z.number().min(18, "Must be at least 18 years old").max(120, "Invalid age"),
  role: z.enum(['admin', 'editor', 'viewer'] as const)
});

export type User = z.infer<typeof UserSchema>;

export interface ApiErrorResponse {
  status: 'error';
  message: string;
  errors?: Record<string, string[]>;
}

export interface ApiSuccessResponse<T> {
  status: 'success';
  data: T;
}
