import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cloud, 
  Cpu, 
  Database, 
  HardDrive, 
  Network, 
  CreditCard, 
  ChevronRight, 
  Info,
  Layers,
  Zap,
  Shield,
  BarChart3
} from 'lucide-react';

type ServiceCategory = 'Compute' | 'Storage' | 'Database' | 'Networking';

interface CloudService {
  category: ServiceCategory;
  feature: string;
  aws: { name: string; description: string };
  gcp: { name: string; description: string };
  azure: { name: string; description: string };
}

const cloudData: CloudService[] = [
  // Compute
  {
    category: 'Compute',
    feature: 'Virtual Machines',
    aws: { name: 'EC2', description: 'Elastic Compute Cloud: Scalable VM instances' },
    gcp: { name: 'Compute Engine', description: 'High-performance VMs running on Google infrastructure' },
    azure: { name: 'Virtual Machines', description: 'Scale-out VM capacity in seconds' }
  },
  {
    category: 'Compute',
    feature: 'Serverless Functions',
    aws: { name: 'Lambda', description: 'Run code without provisioning or managing servers' },
    gcp: { name: 'Cloud Functions', description: 'Event-driven serverless compute platform' },
    azure: { name: 'Azure Functions', description: 'On-demand serverless code execution' }
  },
  {
    category: 'Compute',
    feature: 'Kubernetes',
    aws: { name: 'EKS', description: 'Elastic Kubernetes Service' },
    gcp: { name: 'GKE', description: 'Google Kubernetes Engine' },
    azure: { name: 'AKS', description: 'Azure Kubernetes Service' }
  },
  // Storage
  {
    category: 'Storage',
    feature: 'Object Storage',
    aws: { name: 'S3', description: 'Simple Storage Service: Scalable object storage' },
    gcp: { name: 'Cloud Storage', description: 'Unified object storage for developers' },
    azure: { name: 'Blob Storage', description: 'Massively scalable object storage' }
  },
  {
    category: 'Storage',
    feature: 'Block Storage',
    aws: { name: 'EBS', description: 'Elastic Block Store: High-performance block storage' },
    gcp: { name: 'Persistent Disk', description: 'Durable and high-performance block storage' },
    azure: { name: 'Managed Disks', description: 'Durable block storage for Azure VMs' }
  },
  {
    category: 'Storage',
    feature: 'File Storage',
    aws: { name: 'EFS', description: 'Elastic File System: Scalable NFS file storage' },
    gcp: { name: 'Filestore', description: 'High-performance managed NAS' },
    azure: { name: 'Azure Files', description: 'Cloud file shares' }
  },
  // Database
  {
    category: 'Database',
    feature: 'Relational (SQL)',
    aws: { name: 'RDS', description: 'Relational Database Service for MySQL, PostgreSQL, etc.' },
    gcp: { name: 'Cloud SQL', description: 'Fully managed relational database service' },
    azure: { name: 'SQL Database', description: 'Managed SQL server instances' }
  },
  {
    category: 'Database',
    feature: 'NoSQL (Document)',
    aws: { name: 'DynamoDB', description: 'Key-value and document database' },
    gcp: { name: 'Firestore', description: 'Scalable document database' },
    azure: { name: 'Cosmos DB', description: 'Globally distributed multi-model database' }
  },
  {
    category: 'Database',
    feature: 'Data Warehouse',
    aws: { name: 'Redshift', description: 'Fast, simple, cost-effective data warehousing' },
    gcp: { name: 'BigQuery', description: 'Serverless, highly scalable data warehouse' },
    azure: { name: 'Synapse Analytics', description: 'Limitless analytics service' }
  },
  // Networking
  {
    category: 'Networking',
    feature: 'Virtual Network',
    aws: { name: 'VPC', description: 'Virtual Private Cloud: Isolated network environment' },
    gcp: { name: 'VPC', description: 'Virtual Private Cloud: Global virtual network' },
    azure: { name: 'VNet', description: 'Virtual Network: Isolated Azure network' }
  },
  {
    category: 'Networking',
    feature: 'Content Delivery (CDN)',
    aws: { name: 'CloudFront', description: 'Low-latency content delivery network' },
    gcp: { name: 'Cloud CDN', description: 'Global content delivery across Google network' },
    azure: { name: 'Azure CDN', description: 'Global CDN for developers' }
  },
  {
    category: 'Networking',
    feature: 'Load Balancing',
    aws: { name: 'ELB', description: 'Elastic Load Balancing' },
    gcp: { name: 'Cloud Load Balancing', description: 'Global HTTP(S), TCP/SSL load balancing' },
    azure: { name: 'Load Balancer', description: 'Layer 4 load balancing' }
  }
];

const pricingModels = [
  {
    title: "Pay-As-You-Go",
    description: "You only pay for the resources you consume, with no long-term contracts or up-front commitments.",
    tags: ["No Upfront Cost", "Scalable", "Flexible"]
  },
  {
    title: "Reserved Instances",
    description: "Commit to a consistent amount of usage for 1 or 3 years for significant discounts compared to on-demand costs.",
    tags: ["Cost Saving", "Predictable", "Commitment"]
  },
  {
    title: "Spot/Preemptible",
    description: "Use spare cloud capacity for up to 90% savings. Great for fault-tolerant workloads that can be interrupted.",
    tags: ["Maximum Saving", "Interrupted", "Variable"]
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ServiceCategory>('Compute');
  const [hoveredService, setHoveredService] = useState<string | null>(null);

  const categories: { id: ServiceCategory; icon: any }[] = [
    { id: 'Compute', icon: Cpu },
    { id: 'Storage', icon: HardDrive },
    { id: 'Database', icon: Database },
    { id: 'Networking', icon: Network },
  ];

  const filteredServices = cloudData.filter(s => s.category === activeTab);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-[#141414] py-8 px-6 lg:px-12 flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 bg-white">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-[#141414] rounded-full flex items-center justify-center">
              <Cloud className="text-[#E4E3E0] w-6 h-6" />
            </div>
            <span className="font-mono text-xs tracking-widest uppercase opacity-50">Cloud Infrastructure Comparison</span>
          </div>
          <h1 className="text-6xl lg:text-7xl font-sans font-bold tracking-tighter leading-none mb-6">
            THE CLOUD <br />
            <span className="text-[#141414]/30 italic font-display font-medium">EXPLORER</span>
          </h1>
          <p className="text-lg text-[#141414]/70 max-w-lg leading-relaxed">
            A precise mapping of core services across the major cloud providers. 
            Compare AWS, GCP, and Azure capabilities in one unified dashboard.
          </p>
        </div>
        
        <div className="flex flex-col gap-1 items-start lg:items-end">
          <div className="font-mono text-[10px] uppercase tracking-tighter opacity-40">System Status</div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="font-mono text-sm font-medium uppercase">All Regions Operational</span>
          </div>
        </div>
      </header>

      <main className="flex-1 lg:grid lg:grid-cols-[300px_1fr] min-h-0 bg-white">
        {/* Sidebar Controls */}
        <aside className="border-r border-[#141414] p-6 lg:p-10 flex flex-col gap-8 bg-[#f8f7f4]">
          <div>
            <h3 className="font-display italic text-sm mb-6 opacity-60">Service Categories</h3>
            <nav className="flex flex-col gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveTab(cat.id)}
                  className={`
                    flex items-center justify-between p-4 border transition-all duration-300 group
                    ${activeTab === cat.id 
                      ? 'bg-[#141414] border-[#141414] text-[#E4E3E0]' 
                      : 'bg-white border-[#141414]/10 text-[#141414] hover:border-[#141414]'}
                  `}
                >
                  <div className="flex items-center gap-3">
                    <cat.icon size={18} className={activeTab === cat.id ? 'opacity-100' : 'opacity-40 group-hover:opacity-100'} />
                    <span className="font-sans font-semibold tracking-tight uppercase text-xs">{cat.id}</span>
                  </div>
                  <ChevronRight size={14} className={activeTab === cat.id ? 'opacity-50' : 'opacity-20 group-hover:opacity-100'} />
                </button>
              ))}
            </nav>
          </div>

          <div className="mt-auto">
            <div className="p-5 border border-[#141414] bg-[#141414] text-[#E4E3E0] rounded-none">
              <div className="flex items-center gap-2 mb-3">
                <CreditCard size={14} className="opacity-70" />
                <span className="font-mono text-[10px] uppercase tracking-wider">Pricing Insight</span>
              </div>
              <p className="text-[11px] leading-relaxed opacity-80 font-mono">
                "Cloud services leverage economies of scale to provide high-performance 
                infrastructure with flexible, execution-based billing models."
              </p>
            </div>
          </div>
        </aside>

        {/* Content Area */}
        <section className="overflow-auto bg-white">
          {/* Comparison Grid */}
          <div className="min-w-[800px]">
            <div className="grid grid-cols-4 sticky top-0 bg-white z-10 border-b border-[#141414]">
              <div className="col-header">Component</div>
              <div className="col-header">Amazon Web Services (AWS)</div>
              <div className="col-header">Google Cloud (GCP)</div>
              <div className="col-header">Microsoft Azure</div>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
              >
                {filteredServices.map((service, idx) => (
                  <div 
                    key={idx} 
                    className="data-row group"
                    onMouseEnter={() => setHoveredService(`${service.feature}`)}
                    onMouseLeave={() => setHoveredService(null)}
                  >
                    <div className="data-cell font-sans font-bold flex flex-col justify-center">
                      <span className="text-xs uppercase tracking-tight mb-1 opacity-50 group-hover:opacity-100">Feature</span>
                      {service.feature}
                    </div>
                    <div className="data-cell flex flex-col gap-1 justify-center relative overflow-hidden">
                      <span className="font-bold text-xs uppercase tracking-widest text-[#FF9900] group-hover:text-white transition-colors">
                        {service.aws.name}
                      </span>
                      <p className="text-[10px] leading-tight opacity-60 group-hover:opacity-90">{service.aws.description}</p>
                    </div>
                    <div className="data-cell flex flex-col gap-1 justify-center">
                      <span className="font-bold text-xs uppercase tracking-widest text-[#4285F4] group-hover:text-white transition-colors">
                        {service.gcp.name}
                      </span>
                      <p className="text-[10px] leading-tight opacity-60 group-hover:opacity-90">{service.gcp.description}</p>
                    </div>
                    <div className="data-cell flex flex-col gap-1 justify-center">
                      <span className="font-bold text-xs uppercase tracking-widest text-[#0089D6] group-hover:text-white transition-colors">
                        {service.azure.name}
                      </span>
                      <p className="text-[10px] leading-tight opacity-60 group-hover:opacity-90">{service.azure.description}</p>
                    </div>
                  </div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Pricing Section */}
          <div className="p-12 border-t border-[#141414] bg-[#f8f7f4]">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-12">
                <BarChart3 className="w-8 h-8" />
                <h2 className="text-4xl font-bold tracking-tighter uppercase">The Economic Model</h2>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8">
                {pricingModels.map((model, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex flex-col gap-4"
                  >
                    <div className="flex gap-2">
                      {model.tags.map((tag, tIdx) => (
                        <span key={tIdx} className="text-[8px] font-mono border border-[#141414]/20 px-2 py-0.5 uppercase">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <h4 className="font-display italic text-2xl border-b border-[#141414] pb-2">{model.title}</h4>
                    <p className="text-sm opacity-70 leading-relaxed font-sans">{model.description}</p>
                  </motion.div>
                ))}
              </div>

              <div className="mt-20 p-8 border-2 border-[#141414] relative bg-white">
                <div className="absolute -top-4 -left-4 bg-[#141414] text-[#E4E3E0] p-2 flex items-center gap-2">
                  <Info size={16} />
                  <span className="font-mono text-[10px] uppercase font-bold tracking-widest">Key Takeaway</span>
                </div>
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                  <div>
                    <h3 className="text-3xl font-bold mb-4 tracking-tight leading-none uppercase">Why Pay-As-You-Use?</h3>
                    <p className="text-gray-600 leading-relaxed">
                      The core value proposition of cloud computing is turning **Capital Expenditure (CapEx)**—buying physical servers—into **Operating Expenditure (OpEx)**. 
                      Pay-as-you-use models enable startups and enterprises alike to experiment quickly without financial risk.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 group">
                        <Zap size={20} className="text-yellow-500 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Speed to Market</span>
                      </div>
                      <div className="flex items-center gap-2 group">
                        <Layers size={20} className="text-blue-500 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Elastic Scaling</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 group">
                        <Shield size={20} className="text-green-500 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Global Security</span>
                      </div>
                      <div className="flex items-center gap-2 group">
                        <BarChart3 size={20} className="text-purple-500 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold uppercase tracking-tighter">Granular Logs</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#141414] p-6 lg:p-12 flex flex-col md:flex-row justify-between items-center gap-12 bg-white">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 border border-[#141414] flex items-center justify-center">
            <span className="font-mono text-xs font-bold">CX</span>
          </div>
          <p className="font-mono text-[10px] tracking-wider opacity-40 uppercase">
            © 2026 CLOUD EXPLORER SYSTEM // ALL DATA ACCURATE AT RUNTIME
          </p>
        </div>
        
        <div className="flex gap-8">
           <div className="flex flex-col gap-1 items-end">
             <span className="font-display italic text-[10px] opacity-40 uppercase">Architecture</span>
             <span className="font-mono text-xs uppercase font-medium">Multi-Cloud Strategy</span>
           </div>
           <div className="flex flex-col gap-1 items-end">
             <span className="font-display italic text-[10px] opacity-40 uppercase">Data Source</span>
             <span className="font-mono text-xs uppercase font-medium">Provider Docs API</span>
           </div>
        </div>
      </footer>
    </div>
  );
}
