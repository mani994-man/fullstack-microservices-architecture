/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Calendar, 
  MapPin, 
  Users, 
  Search, 
  Plus, 
  Trash2,
  ChevronRight, 
  LayoutDashboard, 
  Bell, 
  User, 
  PlusCircle, 
  BarChart3, 
  ArrowLeft,
  Sparkles,
  Loader2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { GoogleGenAI } from "@google/genai";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Types
interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  location: string;
  type: string;
  department: string;
  capacity: number;
}

interface Stats {
  totalEvents: number;
  totalRegistrations: number;
  registrationsByEvent: { title: string; registrations: number }[];
}

// AI Integration
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function App() {
  const [view, setView] = useState<"home" | "event-details" | "admin" | "register">("home");
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState({ department: "", type: "" });
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminStats, setAdminStats] = useState<Stats | null>(null);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Auth helper for admin commands
  const getAuthHeader = () => {
    return { 'Authorization': 'Basic ' + btoa('admin:password123') };
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const resp = await fetch("/api/events");
      const data = await resp.json();
      setEvents(data);
    } catch (err) {
      console.error("Failed to fetch events", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const resp = await fetch("/api/admin/stats", { headers: getAuthHeader() });
      const data = await resp.json();
      setAdminStats(data);
    } catch (err) {
      console.error("Failed to fetch stats", err);
    }
  };

  const generateAiRecommendation = async () => {
    if (events.length === 0) return;
    setAiLoading(true);
    try {
      const prompt = `Based on these campus events: ${events.map(e => `${e.title} (${e.type} in ${e.department})`).join(", ")}, give a 2-sentence highly engaging summary of the top must-attend workshops for engineering students this month.`;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      setAiInsight(response.text || "Explore diverse events happening across campus.");
    } catch (err) {
      setAiInsight("Register for workshops today to boost your skills!");
    } finally {
      setAiLoading(false);
    }
  };

  const handleAdminAction = () => {
    if (!isAdmin) {
      const pass = prompt("Enter Admin Password:");
      if (pass === "password123") {
        setIsAdmin(true);
        fetchStats();
        setView("admin");
      } else {
        alert("Incorrect password");
      }
    } else {
      setView("admin");
      fetchStats();
    }
  };

  return (
    <div className="flex min-h-screen bg-bg text-ink font-sans selection:bg-accent selection:text-white">
      {/* Sidebar Navigation */}
      <aside className="w-[280px] bg-ink text-white p-10 flex flex-col justify-between border-r border-border fixed h-full z-50">
        <div>
          <div className="text-2xl font-extrabold leading-tight tracking-tighter mb-16 cursor-pointer" onClick={() => setView("home")}>
            SMART<br />CAMPUS
          </div>
          <nav>
            <ul className="space-y-6">
              {[
                { id: "home", label: "Events Feed" },
                { id: "registrations", label: "My Registrations" },
                { id: "workshops", label: "Workshops" },
                { id: "seminars", label: "Seminar Series" },
                { id: "feedback", label: "Feedback Hub" }
              ].map((item) => (
                <li 
                  key={item.id}
                  onClick={() => item.id === "home" && setView("home")}
                  className={cn(
                    "text-sm font-bold uppercase tracking-[0.1em] cursor-pointer transition-all hover:opacity-100 hover:text-accent",
                    view === item.id || (view === "home" && item.id === "home") ? "opacity-100 text-accent" : "opacity-60"
                  )}
                >
                  {item.label}
                </li>
              ))}
            </ul>
          </nav>
        </div>
        
        <div 
          onClick={handleAdminAction}
          className="border border-white/20 p-4 text-[10px] font-bold text-center uppercase tracking-[0.2em] rounded cursor-pointer hover:bg-white hover:text-ink transition-colors"
        >
          SECURE ADMIN ACCESS
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 ml-[280px] p-16 grid grid-rows-[auto_1fr_auto] gap-10">
        <header className="flex justify-between items-end">
          <div className="heading-giant">
            Campus<br />Events
          </div>
          <div className="text-right text-sm font-bold uppercase tracking-wider max-w-[200px] opacity-60">
            {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}<br />
            CENTRAL CAMPUS<br />
            UNIV. SYSTEMS
          </div>
        </header>

        <AnimatePresence mode="wait">
          {view === "home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-12"
            >
              {/* AI Pulse Header */}
              <div className="border-2 border-ink p-8 flex flex-col md:flex-row items-center gap-8 group">
                <div className="bg-accent p-4 text-white">
                  <Sparkles className="w-8 h-8" />
                </div>
                <div className="flex-1">
                  <h3 className="label-caps text-accent mb-2">Pulse AI Advisor</h3>
                  <div className="text-xl font-bold leading-snug">
                    {aiLoading ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="w-5 h-5 animate-spin" /> Analyzing campus pulses...
                      </span>
                    ) : (
                      aiInsight || "Want personalized recommendations? Let AI scan your campus calendar."
                    )}
                  </div>
                </div>
                {!aiInsight && !aiLoading && (
                  <button 
                    onClick={generateAiRecommendation}
                    className="border-2 border-ink px-6 py-3 font-bold uppercase tracking-widest hover:bg-ink hover:text-white transition-colors"
                  >
                    Generate Insights
                  </button>
                )}
              </div>

              {/* Grid with Filters */}
              <div className="space-y-8">
                <div className="flex items-center justify-between border-b-2 border-ink pb-4">
                  <div className="flex items-center gap-4 flex-1 max-w-md">
                    <Search className="w-5 h-5 opacity-40" />
                    <input 
                      type="text" 
                      placeholder="SEARCH..." 
                      className="bg-transparent border-none font-bold uppercase tracking-widest focus:ring-0 w-full"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-4">
                    <select 
                      className="bg-transparent border-none font-bold uppercase tracking-widest text-xs focus:ring-0 cursor-pointer"
                      onChange={(e) => setFilters({ ...filters, department: e.target.value })}
                    >
                      <option value="">DEPARTMENTS</option>
                      <option value="CS">CS</option>
                      <option value="Mechanical">Mechanical</option>
                      <option value="Arts">ARTS</option>
                    </select>
                    <select 
                      className="bg-transparent border-none font-bold uppercase tracking-widest text-xs focus:ring-0 cursor-pointer"
                      onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                    >
                      <option value="">EVENT TYPE</option>
                      <option value="Workshop">WORKSHOP</option>
                      <option value="Seminar">SEMINAR</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {events
                    .filter(e => e.title.toLowerCase().includes(search.toLowerCase()))
                    .filter(e => !filters.department || e.department === filters.department)
                    .filter(e => !filters.type || e.type === filters.type)
                    .map((event) => (
                      <div key={event.id} className="bg-white border border-border p-6 flex flex-col justify-between h-[280px] hover:border-ink transition-colors group">
                        <div>
                          <span className="label-caps bg-ink text-white px-2 py-1 inline-block mb-4">
                            {event.type}
                          </span>
                          <h3 className="text-xl font-bold leading-tight mb-2 group-hover:text-accent transition-colors">{event.title}</h3>
                          <div className="text-[12px] font-medium text-gray-500 uppercase tracking-wider">
                            {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} • {event.location}
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            setSelectedEvent(event);
                            setView("event-details");
                          }}
                          className="border border-ink py-3 font-bold text-xs uppercase tracking-widest hover:bg-ink hover:text-white transition-colors mt-6"
                        >
                          View Details
                        </button>
                      </div>
                    ))}
                </div>
              </div>
            </motion.div>
          )}

          {view === "event-details" && selectedEvent && (
            <motion.div
              key="details"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-4xl space-y-12"
            >
              <button onClick={() => setView("home")} className="label-caps flex items-center gap-2 hover:text-accent transition-colors font-black">
                <ArrowLeft className="w-4 h-4" /> Back to Feed
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                <div className="space-y-8">
                  <span className="label-caps bg-accent text-white px-3 py-1 inline-block">{selectedEvent.type}</span>
                  <h2 className="text-6xl font-black uppercase leading-[0.9] tracking-tighter">{selectedEvent.title}</h2>
                  <p className="text-lg font-medium leading-relaxed opacity-70 italic">{selectedEvent.description}</p>
                </div>

                <div className="border-t-4 border-ink pt-8 space-y-8">
                  <div className="grid grid-cols-2 gap-8">
                    <div>
                      <span className="label-caps opacity-40 block mb-2">Location</span>
                      <span className="font-bold uppercase tracking-tight text-xl">{selectedEvent.location}</span>
                    </div>
                    <div>
                      <span className="label-caps opacity-40 block mb-2">Department</span>
                      <span className="font-bold uppercase tracking-tight text-xl">{selectedEvent.department}</span>
                    </div>
                    <div>
                      <span className="label-caps opacity-40 block mb-2">Capacity</span>
                      <span className="font-bold uppercase tracking-tight text-xl">{selectedEvent.capacity} SPOTS</span>
                    </div>
                    <div>
                      <span className="label-caps opacity-40 block mb-2">Date</span>
                      <span className="font-bold uppercase tracking-tight text-xl">{new Date(selectedEvent.date).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => setView("register")}
                    className="w-full bg-ink text-white py-6 font-black uppercase tracking-[0.2em] hover:bg-accent transition-colors"
                  >
                    Secure Registration
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === "register" && selectedEvent && (
            <motion.div
              key="register"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-2xl"
            >
               <RegistrationForm theme="bold" event={selectedEvent} onBack={() => setView("event-details")} />
            </motion.div>
          )}

          {view === "admin" && (
            <motion.div
              key="admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-12"
            >
              <div className="flex justify-between items-end">
                <h1 className="text-5xl font-black uppercase tracking-tighter italic">Console</h1>
                <div className="label-caps bg-accent text-white px-4 py-2">System Administrator</div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-0 border-2 border-ink">
                <div className="p-8 border-r-2 border-ink">
                  <span className="label-caps opacity-60">Live Events</span>
                  <div className="text-6xl font-black mt-2 tracking-tighter">{adminStats?.totalEvents || 0}</div>
                </div>
                <div className="p-8 border-r-2 border-ink">
                  <span className="label-caps opacity-60">Registrations</span>
                  <div className="text-6xl font-black mt-2 tracking-tighter">{adminStats?.totalRegistrations || 0}</div>
                </div>
                <div className="p-8 bg-accent text-white">
                  <span className="label-caps opacity-80">Health</span>
                  <div className="text-3xl font-black mt-4 uppercase">Operational</div>
                </div>
              </div>

              <div className="border-2 border-ink">
                <table className="w-full text-left">
                  <thead className="border-b-2 border-ink bg-white">
                    <tr>
                      <th className="p-6 label-caps">Event Entity</th>
                      <th className="p-6 label-caps text-center">Load</th>
                      <th className="p-6 label-caps text-right">Interrupt</th>
                    </tr>
                  </thead>
                  <tbody>
                    {adminStats?.registrationsByEvent.map((stat) => (
                      <tr key={stat.title} className="border-b border-border hover:bg-indigo-50/10 transition-colors">
                        <td className="p-6 font-bold uppercase">{stat.title}</td>
                        <td className="p-6 font-black text-2xl text-center">{stat.registrations}</td>
                        <td className="p-6 text-right">
                          <button className="border border-ink p-2 hover:bg-black hover:text-white transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Stats Bar */}
        <footer className="border-t-4 border-ink pt-10 grid grid-cols-4 gap-8">
          {[
            { label: "Active Pulse", value: events.length },
            { label: "Engagement", value: adminStats?.totalRegistrations || "1402" },
            { label: "Sectors", value: "08" },
            { label: "Protocol", value: "Operational", accent: true }
          ].map((stat, i) => (
            <div key={i}>
              <span className="label-caps text-gray-400 block mb-2">{stat.label}</span>
              <span className={cn("text-4xl font-black tracking-tighter", stat.accent ? "text-accent" : "text-ink")}>
                {stat.value}
              </span>
            </div>
          ))}
        </footer>
      </main>
    </div>
  );
}

function EventCard({ event, onClick, ...props }: { event: Event; onClick: () => void; [key: string]: any }) {
  // Logic inside main App for consistency, this component can be simplified or used as is above.
  return null;
}

function RegistrationForm({ event, onBack, theme }: { event: Event; onBack: () => void; theme?: string }) {
  const [formData, setFormData] = useState({ studentName: "", studentEmail: "", studentId: "" });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const resp = await fetch(`/api/events/${event.id}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (resp.ok) setSuccess(true);
      else alert("Registration failed. Please try again.");
    } catch (err) {
      alert("Error submitting registration.");
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="border-4 border-ink p-12 text-center space-y-8 bg-white shadow-[20px_20px_0px_0px_rgba(0,0,0,1)]">
        <div className="bg-accent w-20 h-20 flex items-center justify-center mx-auto text-white">
          <Bell className="w-10 h-10" />
        </div>
        <h2 className="text-4xl font-black uppercase tracking-tighter">Registration Confirmed</h2>
        <p className="text-xl font-bold opacity-60">
          Entity access granted for <span className="text-accent underline underline-offset-4">{event.title}</span>.
        </p>
        <button 
          onClick={onBack}
          className="bg-ink text-white px-10 py-4 font-black uppercase tracking-widest hover:bg-accent transition-colors"
        >
          Return to Feed
        </button>
      </div>
    );
  }

  return (
    <div className="border-4 border-ink p-10 bg-white shadow-[20px_20px_0px_0px_rgba(0,0,0,1)] space-y-10">
      <div>
        <h2 className="text-5xl font-black uppercase tracking-tighter mb-2 italic">Register</h2>
        <div className="label-caps text-accent">Securing entity: {event.title}</div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-2">
          <label className="label-caps opacity-40">Ident Identity</label>
          <input 
            required
            className="w-full border-2 border-ink p-4 font-bold uppercase placeholder:opacity-20 focus:ring-accent focus:border-accent"
            placeholder="FULL NAME"
            value={formData.studentName}
            onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <label className="label-caps opacity-40">Comm Channel</label>
          <input 
            required
            type="email"
            className="w-full border-2 border-ink p-4 font-bold uppercase placeholder:opacity-20 focus:ring-accent focus:border-accent"
            placeholder="EMAIL@UNIVERSITY.EDU"
            value={formData.studentEmail}
            onChange={(e) => setFormData({ ...formData, studentEmail: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <label className="label-caps opacity-40">Pulse Index</label>
          <input 
            required
            className="w-full border-2 border-ink p-4 font-bold uppercase placeholder:opacity-20 focus:ring-accent focus:border-accent"
            placeholder="STUDENT ID [ST-XXXX]"
            value={formData.studentId}
            onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
          />
        </div>

        <div className="flex gap-4 pt-4">
          <button 
            type="button" 
            onClick={onBack}
            className="flex-1 border-2 border-ink p-4 font-black uppercase tracking-widest hover:bg-gray-100 transition-colors"
          >
            Abort
          </button>
          <button 
            type="submit"
            disabled={submitting}
            className="flex-[2] bg-ink text-white p-4 font-black uppercase tracking-widest hover:bg-accent transition-colors disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Commit Registration"}
          </button>
        </div>
      </form>
    </div>
  );
}

